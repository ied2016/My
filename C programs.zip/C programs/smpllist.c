#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct Node{
int data;
struct Node *next,*prev;
}*start;
struct Node* head=NULL;
void Insert(int x)
{

	struct Node *temp=(struct Node*)malloc(sizeof(struct Node));
	temp=start;
	while(temp)
	{
		if(temp->data==x)
		{
			printf("%d\n",-1);
			return;
		}
		temp=temp->next;
	}
	if(head==NULL)
	{
		temp->data=x;
		temp->prev=NULL;
		head=temp;
		start=temp;
		return;
	}
	else
	{
			temp=start;
	while(temp)
	{
		if(temp->data>x&&temp->prev!=NULL)
		{
			struct Node *n=(struct Node*)malloc(sizeof(struct Node));
			n->data=x;
			n->next=temp;
			n->prev=temp->prev;
			temp->prev=n;
			temp->prev->next=n;
			printf("Here");
			return;
		}
		else if(temp->data>x&&temp->prev==NULL)
		{
			struct Node *n=(struct Node*)malloc(sizeof(struct Node));
			n->data=x;
			n->prev=NULL;
			n->next=temp;
			start=n;
		}
		else if(temp->next==NULL)
		{
			struct Node *n=(struct Node*)malloc(sizeof(struct Node));
			n->data=x;
			head=n;
			temp->next=n;
			n->prev=temp;
			n->next=NULL;
			return;
		}
		temp=temp->next;
	}
	}
}


void I(int x)
{
	struct Node *temp=(struct Node*)malloc(sizeof(struct Node));
	if(head==NULL)
	{
		temp->data=x;
		temp->prev=NULL;
		head=temp;
		start=temp;
		return;
	}
	temp->data=x;
	temp->prev=head;
	temp->prev->next=temp;
	temp->next=NULL;
	head=temp;
}
// void Insert(int x,struct Node* head1)
// {
// 	struct Node *temp=(struct Node*)malloc(sizeof(struct Node));
// 	if(head1==NULL)
// 	{
// 		temp->data=x;
// 		temp->
// 	}
// }
void deleteDuplicate(int v)
{
	struct Node *temp=(struct Node*)malloc(sizeof(struct Node));
	temp=start;
	while(temp!=NULL)
	{
		printf("\ntemp=%d  temp->next->data=%d ",temp->data,temp->next->data);
		if(temp->data==v)
		{
			// if(temp->next->next==NULL)
			// {
			// 	free(temp->next);
			// 	temp->next=NULL;
			// }
			
		
			struct Node *temp1=(struct Node*)malloc(sizeof(struct Node));
			//printf("\n delete=%lld ",temp->next->data);
			//temp1=temp->next;
			if(temp->next==NULL)
			{
				temp->prev->next=NULL;
				head=temp;
				return ;
			}
			else if(temp->prev==NULL)
			{
				start=temp->next;
				free(temp);
				return;
			}
			else
			{
			temp->prev->next=temp->next;
			free(temp);
			return;
			}
			//temp->next=temp1->next;
			//temp1->next->prev=temp;
			//free(temp1);
		
		}
		temp=temp->next;
	}
}
void removeDuplicates()
{
  struct Node *ptr1, *ptr2, *dup;
  ptr1 = start;
 int c=0;
  while(ptr1 != NULL && ptr1->next != NULL)
  {
     ptr2 = ptr1;
 
     while(ptr2->next != NULL)
     {
   
       if(ptr1->data == ptr2->next->data)
       {

          dup = ptr2->next;
          ptr2->next = ptr2->next->next;
          printf("%d ",dup->data);
          c++;
          free(dup);
       }
       else 
       {
          ptr2 = ptr2->next;
       }
     }
     ptr1 = ptr1->next;
  }
if(c==0)
	printf("%d",-1);
}

void Print(int index)
{
	struct Node *temp=(struct Node*)malloc(sizeof(struct Node));
	temp=start;
	//index++;
	int count=0;
	while(temp!=NULL)
	{
	
		if(count==index-1)
		{printf("%d\n",temp->data);
		return;}
	
	count++;
		temp=temp->next;
	}
	printf("%d\n",-1);
}

void p()
{
	struct Node *temp=(struct Node*)malloc(sizeof(struct Node));
	temp=start;
	//index++;
	//int count=0;
	while(temp!=NULL)
	{
	
		printf(" %d ",temp->data);

		temp=temp->next;
	}
	//printf("%d\n",-1);
}




int main()
{
	int t,n,index,x,i,j;
	char s[80];
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
		scanf("%d",&x);
		I(x);
		while(x!=0)
		{
			scanf("%d",&x);
			if(x!=0)
			I(x);
		}
		//display1();
		//p();
		scanf("%d",&n);
		for(j=0;j<n;j++)
		{
			//p();
		scanf("%s",s);
		if(strcmp(s,"Insert")==0)
		{
			scanf("%d",&x);
			Insert(x);
			printf("%d\n",x);
			//p();
		}
		else if(strcmp(s,"Delete")==0)
		{
			//display1();
			//removeDuplicates();
			p();
			int v;
			scanf("%d",&v);
			deleteDuplicate(v);
			printf("\n");
			p();
			//display1();
		}
		else if(strcmp(s,"Print")==0)
		{
			scanf("%d",&index);
			Print(index);
		}
		}
	}
return 0;
}