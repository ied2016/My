#include <stdio.h>
#define MAX 10005
int id[MAX], nodes, edges;
struct edge{
	int x,y;
	long long weight;
};
struct edge p[MAX];

void m(struct edge A[],int p,int q,int r)
{	int n1,n2;
	n1=q-p+1;
	n2=r-q;
	int i,j,k;
	struct edge tmp,L[n1+1],R[n2+1];
	for(i=1;i<=n1;i++)
	{
	//L[i]=A[p+i-1].weight;
		L[i].x=A[p+i-1].x;
		L[i].y=A[p+i-1].y;
		L[i].weight=A[p+i-1].weight;

	}
	for(j=1;j<=n2;j++)
		{
	//R[j]=A[q+j].weight;
		R[j].x=A[q+j].x;
		R[j].y=A[q+j].y;
		R[j].weight=A[q+j].weight;

	}
	//R[j]=A[q+j].weight;
	L[n1+1].weight=9999999;
	R[n2+1].weight=9999999;
	i=1;
	j=1;
	for(k=p;k<=r;k++)
	{
	if(L[i].weight<=R[j].weight)
	{
	A[k].x=L[i].x;
	A[k].y=L[i].y;
	A[k].weight=L[i].weight;
	i=i+1;
	}
	else
	{
	//A[k]=R[j];
	A[k].x=R[j].x;
	A[k].y=R[j].y;
	A[k].weight=R[j].weight;
	j=j+1;
	}
	}
	//printf("\n");
	// for(i=1;i<=top;i++)
	// 	{
	// 		printf(" %d ",A[i]);
	// 	}
}

void vs(struct edge A[],int p,int r)
{
	int q;
	if(p<r)
	{
	q=(p+r)/2;
	vs(A,p,q);
	vs(A,q+1,r);
	m(A,p,q,r);
	}
}

void initialize() {
	for(int i = 0;i < MAX;++i)
		id[i] = i;
}

int root(int x) {
	while(id[x] != x)
	{
		id[x] = id[id[x]];
		x = id[x];
	}
	return x;
}

	//scanf("%d %d",&nodes,&edges);

void union1(int x, int y) {
	int xx = root(x);
	int yy = root(y);
	id[xx] = id[yy];
}

long long kruskal(struct edge e[]) {
	int x, y;
	long long cost, maximumCost = 0;
	for(int i = 1;i < edges;++i) {
		// Selecting edges one by one in increasing order from the beginning
		x = e[i].x;
		y = e[i].y;
		cost = e[i].weight;
		// Check if the selected edge is creating a cycle or not
		if(root(x) != root(y)) {
			maximumCost += cost;
			union1(x, y);
		}    
	}
	return maximumCost;
}

int main() {
	long long maximumCost;
	initialize();
	int r1,r2,i;
	scanf("%d %d %d",&nodes,&r1,&r2);
	scanf("%d %d",&nodes,&edges);

	for(i = 1;i <= r1;++i) {
		scanf("%d %d %lld",&p[i].x,&p[i].y,&p[i].weight);
	}
	for()
	/*
	for(int i = 0;i < edges;++i) {
		printf("%d %d %lld\n",p[i].x,p[i].y,p[i].weight);
	}
	*/
	// Sort the edges in the ascending order
	//sort(p,edges);
	vs(p,0,edges);
	/*
	for(int i = 0;i < edges;++i) {
		printf("%d %d %lld\n",p[i].x,p[i].y,p[i].weight);
	}
	*/

	maximumCost = kruskal(p);
	printf("%lld\n",maximumCost);
	return 0;
}