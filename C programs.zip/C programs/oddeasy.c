#include <stdio.h>
void is(int size, int arr[]) {
	int i,j,k,shift=0,tmp;
	for(i=1;i<size ;i++)
	{tmp=arr[i];
	j=i-1;
	while(tmp < arr[j])
	{shift++;
		arr[j+1]=arr[j];
		j--;
	}
	arr[j+1]=tmp;
}}

int main()
{
	int i,k=0,j=0,n,t,a[1111],odd[1111],even[1111];
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{
		if(a[i]%2==0)
			even[j++]=a[i];
		else
			odd[k++]=a[i];
	}
	int md1,md2;
	md1=j/2;
	md2=k/2;
	is(k,odd);
	is(j,even);
	printf("\n");
	for(i=0;i<j;i++)
		printf(" %d ",even[i]);
	for(i=k-1;i>=0;i--)
		printf(" %d ",odd[i]);
	printf("\n");
	return 0;
}