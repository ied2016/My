#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>


struct node
    {
    long int par;
    long int size;
};
long int find (struct node*,long int);


int main() {
long int n,i,j,k,par_i,par_j;
    struct node set[100002]={{0,0}};
    long q;
    char ch;
       scanf("%ld %ld",&n,&q);
    for(k=0;k<=n;k++)
        {
        set[k].size=1;
        set[k].par=k;
    }
   while(scanf("%c",&ch)!=EOF)
       {
         scanf("%c %d",&ch,&i);
       
      if(ch=='\n')
           continue;
       printf("%c",ch);
       if(ch=='Q')
           {      
           scanf("%ld",&i);
           par_i=find(set,i);
           printf("%ld\n",set[par_i].size);
           printf("%d\n",i);
          
       }
       else if(ch=='M')
           {
          scanf("%ld %ld",&i,&j);
          printf("%d %d\n",i,j);
           par_i=find(set,i);
           par_j=find(set,j);
           if(par_i!=par_j)
               {
           set[par_j].par=set[par_i].par;
           set[par_i].size+=set[par_j].size;
           }
       }
                      }  
    return 0;
}

long int find (struct node *set,long int i)
    {
    long int parent=set[i].par;
    if(set[i].par!=i)
        parent=find(set,set[i].par);
    
    return parent;
}