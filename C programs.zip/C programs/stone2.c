#include <stdio.h>
int main()
{
        long long int n,k,max=-1,max2=-1,i;
        scanf("%lld %lld",&n,&k);
        long long int a[n];
        for(i=0;i<n;i++)
        {
        scanf("%lld",&a[i]);
        if(a[i]>max)
            max=a[i];
        }
        if(k==0)
            {
            for(i=0;i<n;i++)
                printf("%lld ",a[i]);
            printf("\n");
            return 0;
            }
        if(k%2!=0)
        {
        for(i=0;i<n;i++)
        {
        a[i]=max-a[i];
        }
        }
        else if(k%2==0&&k!=0)
        {
        k=2;
        while(k--)
        {
        max2=-1;
        for(i=0;i<n;i++)
        {
        a[i]=max-a[i];
        if(a[i]>max2)
            max2=a[i];
        }
        max=max2;
        }
        }
        for(i=0;i<n;i++)
            printf("%lld ",a[i]);
        printf("\n");
        return 0;
} 