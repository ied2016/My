#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
	char a,b;
	scanf("%c %c",&a,&b);
	if(a<=b) printf("left");
	else printf("right");
}