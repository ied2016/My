#include <stdio.h>
int main()
{
	int t,n,i,k=0,f,num;
	scanf("%d",&t);
	while(t--)
	{
	f=0;
	int count=0;
	k=0;
	scanf("%d %d",&n,&num);
	int a[n];
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{
	if(a[i]%2==0)
	{
		count++;
	}
	}
	if(num==0)
	{
		if(count==n)
			printf("NO\n");
		else
			printf("YES\n");
	}
	else if(count>=num)
		printf("YES\n");
	else
		printf("NO\n");
	}
return 0;
}