#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char XOR(char a,char b)
{
	if(a=='1'&&b=='1')
		return '0';
	if(a=='1'&&b=='0')
		return '1';
	if(a=='0'&&b=='1')
		return '1';
	if(a=='0'&&b=='0')
		return '0';
}

char OR(char a,char b)
{
	if(a=='1'&&b=='1')
		return '1';
	if(a=='1'&&b=='0')
		return '1';
	if(a=='0'&&b=='1')
		return '1';
	if(a=='0'&&b=='0')
		return '0';
}

char AND(char a,char b)
{
	if(a=='1'&&b=='1')
		return '1';
	if(a=='1'&&b=='0')
		return '0';
	if(a=='0'&&b=='1')
		return '0';
	if(a=='0'&&b=='0')
		return '0';
}

int main()
{
	int i,j,n,t,f=1;
	scanf("%d",&t);
	while(t--)
	{
	int count=0,count1=0,flag=0;
	//lucky(count1,count0);
	char A[1000002],B[1000002],result;
	int i;
	if(f==1)
	{
		gets(A);
		f++;
	}
	//int count1=0,count0=0;				
	gets(A);
	gets(B);
	printf("A=%s\nB=%s\n",A,B);
	for(i=0;i<strlen(A);i++)
	{
		if(A[i]=='1')
			count1++;
		else
			count0++;
	}
	//printf("A=%s\n",A);
	// printf("1=%d 0=%d\n",count1,count0);
	// strcpy(A,"");
	for(i=0;i<strlen(A);i++)
	{
		printf("A[%d]=%c\n",i,A[i]);
		if(A[i]!=B[i])
		{
			printf("B[%d]=%c\n",i,B[i]);
			if(B[i]=='1')
			{	printf("IN B\n");
				if(A[i]=='0')
					{	printf("IN A\n");
						for(j=i+1;j<strlen(A);j++)
						{	printf("IN FOR\n");
							if(A[j]=='1')
							{
								printf("in OR A[%d]=%c  A[%d]=%c\n",i,A[i],j,A[j]);
								result=OR(A[i],A[j]);
								A[i]=OR(result,A[j]);
								A[j]=OR(result,A[i]);
								count++;
							}
							else
							{
								result=XOR(A[i],A[j]);
								A[i]=XOR(result,A[j]);
								A[j]=XOR(result,A[i]);
								count++;
							}
						}
					}
				}
				if(B[i]=='0')
				if(A[i]=='1')
					{
							for(j=i+1;j<strlen(A);j++)
							{
							if(A[j]=='0')
							{
								result=AND(A[i],A[j]);
								A[i]=AND(result,A[j]);
								A[j]=AND(result,A[i]);
								count++;
							}
							else
							{
								flag=1;
								break;
							}
							}
					}		
			}
	}
	if(flag==1)
		printf("Unlucky Chef\n");
	else
		printf("Lucky Chef\n%d",count);
	}
	printf("A=%s\nB=%s\n",A,B);
	}
return 0;
}