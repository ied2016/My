#include <stdio.h>
int main(){
 long long int i,t,n;
 scanf("%lld",&t);
 while(t--)
 {
  scanf("%lld",&n);
  long long int a[n],count=0;
  for(i=0;i<n;i++)
    scanf("%lld",&a[i]);
  quicksort(a,0,n-1);
    int m=-1;
    for(i=n-1;i>=0;i--)
    {
      if(m==-1)
      {
      count+=a[i];
      }
      m*=-1;
    }
    printf("%lld\n",count);
 }
  return 0;
}

void quicksort(long long int x[],long long int first,long long int last){
    long long int pivot,j,temp,i;

     if(first<last){
         pivot=first;
         i=first;
         j=last;

         while(i<j){
             while(x[i]<=x[pivot]&&i<last)
                 i++;
             while(x[j]>x[pivot])
                 j--;
             if(i<j){
                 temp=x[i];
                  x[i]=x[j];
                  x[j]=temp;
             }
         }

         temp=x[pivot];
         x[pivot]=x[j];
         x[j]=temp;
         quicksort(x,first,j-1);
         quicksort(x,j+1,last);

    }
}