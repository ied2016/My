#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct node
{
    int key;
    struct node *left;
    struct node *right;
};
struct node *root1=NULL;


void removeb(struct node *root, int min, int max)
{
  if(root!=NULL)
 {
  removeb(root->left,min,max);
  if(min<root->key&&root->key<max)
  {
   
  if(root->left==NULL)
  {
    root->right->left=NULL;
    root1=root->right;
    free(root);
  }
  else if(root->right==NULL)
  {
    root->left->right=NULL;
    root1=root->left;
    free(root);
  }
  else{
    root->left->right=root->right;
    root->right->left=root->left;
    root1=root->right;
    free(root);
  }
  
  }
  removeb(root->right,min,max);
}
 
}
 
struct node* insert(struct node* root, int k)
{
     if(root==NULL)
  {
    struct node *temp=(struct node*)malloc(sizeof(struct node));
    temp->key=k;
    temp->left=temp->right=NULL;
    return temp;
  }
    if (root->key >= k)
       root->left = insert(root->left, k);
    else
       root->right = insert(root->right, k);
    return root;
}
 
void inorder(struct node* root)
{
    if (root)
    {
        inorder( root->left );
        printf("%d ",root->key);
        inorder( root->right );
    }
}

void preorder(struct node* root)
{
    if (root)
    {
        printf("%d ",root->key);
        preorder( root->left );
        preorder( root->right );
    }
}

void postorder(struct node* root)
{
    if (root)
    {
        postorder( root->left );
        postorder( root->right );
        printf("%d ",root->key);
    }
}
 
int main()
{
  int t,n,num,i,j,MAX,MIN;
  char s[80]="";
  struct node *root=NULL;
  scanf("%s",&s);
    if(strcmp(s,"INSERT")==0)
      {scanf("%d",&num);
        root=insert(root,num);
        root1=root;
      }
      else if(strcmp(s,"PRINT")==0)
      {
        scanf("%d",&num);
        if(num==1)
          inorder(root);
        else if(num==2)
          preorder(root1);
        else if(num==3)
          postorder(root1);
      }
  while(strcmp(s,"END")!=0)
  {
    scanf("%s",&s);
    if(strcmp(s,"INSERT")==0)
      {scanf("%d",&num);
        insert(root,num);
      }

    else if(strcmp(s,"PRINT")==0)
      {
        scanf("%d",&num);
        if(num==1)
          inorder(root1);
        else if(num==2)
          preorder(root1);
        else if(num==3)
          postorder(root1);
      }
      else if(strcmp(s,"DELETE")==0)
      {
        scanf("%d %d",&MIN,&MAX);
      }
  }

  return 0;
}