#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct node{
    int key;
    struct node *prev,*next;
}*sv,*sn,*start;
// struct node
// {
//     int data;
//     struct node *next, *prev;
// };
 
struct node *split(struct node *head);
 
// Function to merge two linked lists
struct node *merge(struct node *first, struct node *second)
{
    // If first linked list is empty
    if (!first)
        return second;
 
    // If second linked list is empty
    if (!second)
        return first;
 
    // Pick the smaller value
    if (first->data < second->data)
    {
        first->next = merge(first->next,second);
        first->next->prev = first;
        first->prev = NULL;
        return first;
    }
    else
    {
        second->next = merge(first,second->next);
        second->next->prev = second;
        second->prev = NULL;
        return second;
    }
}
 
// Function to do merge sort
struct node *mergeSort(struct node *head)
{
    if (!head || !head->next)
        return head;
    struct node *second = split(head);
 
    // Recur for left and right halves
    head = mergeSort(head);
    second = mergeSort(second);
 
    // Merge the two sorted halves
    return merge(head,second);
}
 
// A utility function to insert a new node at the
// beginning of doubly linked list
void insert(struct node **head, int data)
{
    struct node *temp =
        (struct node *)malloc(sizeof(struct node));
    temp->data = data;
    temp->next = temp->prev = NULL;
    if (!(*head))
        (*head) = temp;
    else
    {
        temp->next = *head;
        (*head)->prev = temp;
        (*head) = temp;
    }
}
 
// A utility function to print a doubly linked list in
// both forward and backward directions
void print(struct node *head)
{
    struct node *temp = head;
    printf("Forward Traversal using next poitner\n");
    while (head)
    {
        printf("%d ",head->data);
        temp = head;
        head = head->next;
    }
    printf("\nBackword Traversal using prev pointer\n");
    while (temp)
    {
        printf("%d ", temp->data);
        temp = temp->prev;
    }
}
 
// Utility function to swap two integers
void swap(int *A, int *B)
{
    int temp = *A;
    *A = *B;
    *B = temp;
}
 
// Split a doubly linked list (node) into 2 DLLs of
// half sizes
struct node *split(struct node *head)
{
    struct node *fast = head,*slow = head;
    while (fast->next && fast->next->next)
    {
        fast = fast->next->next;
        slow = slow->next;
    }
    struct node *temp = slow->next;
    slow->next = NULL;
    return temp;
}



struct node *head=NULL;

void insertbeg(int v)
{
    struct node *temp=(struct node*)malloc(sizeof(struct node));
    temp->key=v;
    if(head==NULL)
    {
    temp->prev=temp->next=NULL;
    start=temp;
    head=temp;
    return;
    }
    start->prev=temp;
    temp->next=start;
    temp->prev=NULL;
    start=temp;
}

void insertend(int v)
{
    struct node *temp=(struct node*)malloc(sizeof(struct node));
    temp->key=v;
    if(head==NULL)
    {
    temp->prev=temp->next=NULL;
    start=temp;
    head=temp;
    return;
    }
    head->next=temp;
    temp->prev=head;
    temp->next=NULL;
    head=temp;
}

void delete(int i, int m)
{
    if(start==NULL)
        return ;
    struct node *temp=(struct node*)malloc(sizeof(struct node));
    temp=start;
    while(i!=1)
    {
        temp=temp->next;
        i--;
    }
    sn=temp;
    temp=temp->next;
    while(m!=1)
    {
        //sp=temp;
        //free(sp);
        temp=temp->next;
        m--;
    }
    if(temp->next==NULL)
    {
        sn->next=NULL;
        head=sn;
        free(temp);
        return ;
    }
    else{
    sn->next=temp->next;
    temp->next->prev=sn;
    free(temp);
    }
}

void print()
{
    struct node *temp=(struct node*)malloc(sizeof(struct node));
    temp=start;
    while(temp)
    {
        printf("%d ",temp->key);
        temp=temp->next;
    }
}

int main()
{
    int t,num,i,j,m;
    char s[80];
    scanf("%d",&t);
    for(j=0;j<t;j++)
    {
        scanf("%s",s);
        if(strcmp(s,"INSERTBEG")==0)
            {
            scanf("%d",&num);
            insertbeg(num);
            }
        if(strcmp(s,"INSERTEND")==0)
            {
            scanf("%d",&num);
            insertend(num);
            }
        if(strcmp(s,"PRINT")==0)
            print();
        if(strcmp(s,"DELETENEXT")==0)
        {
            scanf("%d %d",&i,&m);
            delete(i,m);
        }
        print();
        printf("\n");
    }
    return 0;
}