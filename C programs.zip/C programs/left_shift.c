#include <stdio.h>
int main()
{
	int r=3;
	r=r<<2;
	printf("r=%d\n",r);
}