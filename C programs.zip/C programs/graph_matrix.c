#include <stdio.h>
int v,a[100][100],visited[100];
void bfs(int source)
{
	    printf("v=%d",v);
    int queue[v];
    int i, front, rear, root;
    front = rear = 0;
    visited[source] = 1;
    queue[rear++] = source;
    printf("%d   ",source);
    while (front != rear)
    {
        root = queue[front++];
        for (i = 1; i <= v; i++)
        {
            if (a[root][i] && !visited[i])
            {
                visited[i] = 1;
                queue[rear++] = i;
                printf("  >>%d  ",i);
            }
        front++;
    }
}
}
int main()
{
	int n,i,j,k,num,a1,a2;
	scanf("%d",&v);
	//int a[v][v],visited[v];
	for(i=1;i<=v;i++)
			for(j=1;j<=v;j++)
				a[i][j]=0;
	printf("how many=");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
	scanf("%d %d",&a1,&a2);
	a[a1][a2]=1;
	a[a2][a1]=1;
	}
	for(i=1;i<=v;i++)
	{
		for(j=1;j<=v;j++)
			if(a[i][j]==1)
				printf("\nedge %d & %d are connected",i,j);
	}
	  for (i = 1; i <= v; i++)
        visited[i] = 0;
    printf("add=%d",&visited[2]);
    printf("v=%d",v);
	bfs(1);
	return 0;
}