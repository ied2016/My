#include <stdio.h>

int sort(char s[][],int size,char s2[])
{
	int i,j,k
	for(i=0;i<size;i++)
	{
		for(j=0;j<)
	}


}




int main()
{
	char s[100][100];
	int i,j ,k ,t;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
		scanf("%s",s2);
		scanf("%d",&n);
		for(j=0;j<n;j++)
			scanf("%s",s[j][]);	

	}	
}