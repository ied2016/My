#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct node
{
    int key;
    struct node *left;
    struct node *right;
};

struct node *root=NULL; 

struct node* removeOutsideRange(struct node *root, int min, int max)
{
   if (root == NULL)
      return NULL;
    
   root->left =  removeOutsideRange(root->left, min, max);
   //printf("\nroot->left=%d  ",root->left->key);
   root->right = removeOutsideRange(root->right, min, max);
   //printf("\nroot->right=%d  ",root->right->key);
 
   if (min<root->key < max)
   {
       struct node *rChild = root->left;
       printf("\nDELETE=%d",root->key);
       free(root);
       return rChild;
   }
   // if (root->key > max)
   // {
   //     struct node *lChild = root->left;
   //     printf("\nDELETE=%d",root->key);
   //     free(root);
   //     return lChild;
   // }

   return root;
}
 
struct node* insert(struct node* root, int k)
{
     if(root==NULL)
  {
    struct node *temp=(struct node*)malloc(sizeof(struct node));
    temp->key=k;
    temp->left=temp->right=NULL;
    return temp;
  }
    if (root->key >= k)
       root->left = insert(root->left, k);
    else
       root->right = insert(root->right, k);
    return root;
}
 
// void inorderTraversal(struct node* root)
// {
//     if (root)
//     {
//         inorderTraversal( root->left );
//         printf("\nkey=%d ",root->key);
//         inorderTraversal( root->right );
//     }
// }

void inorder(struct node* root)
{
    if (root)
    {
        inorder( root->left );
        printf("%d ",root->key);
        inorder( root->right );
    }
}

void preorder(struct node* root)
{
    if (root)
    {
        printf("%d ",root->key);
        preorder( root->left );
        preorder( root->right );
    }
}

void postorder(struct node* root)
{
    if (root)
    {
        postorder( root->left );
        postorder( root->right );
        printf("%d ",root->key);
    }
}
 
int main()
{
  int t,n,num,i,j,min,max;
  char s[80];
  scanf("%s",s);
  while(strcmp(s,"END")!=0)
  {
  if(strcmp(s,"INSERT")==0)
  {
  scanf("%d",&num);
  if(root==NULL)
    root=insert(root,num);
  else
    insert(root,num);
  }
  else if(strcmp(s,"PRINT")==0)
  {
    scanf("%d",&num);
    if(num==1)
      inorder(root);
    if(num==2)
      preorder(root);
    if(num==3)
      postorder(root);
    printf("\n");
  }
  else if(strcmp(s,"DELETE")==0)
  {
    scanf("%d %d",&min,&max);
    removeOutsideRange(root,min,max);
    printf("root==%d",root->key);
  }
  scanf("%s",s);
  }
  return 0;
}