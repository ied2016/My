#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
	int t;
	scanf("%d",&t);
	char s[11];
	getchar();
	while(t--)
	{
	gets(s);
	if(strlen(s)==5&&(s[0]>='a'&&s[0]<='h')&&(s[3]>='a'&&s[3]<='h')&&(s[1]>='1'&&s[1]<='8')&&(s[4]>='1'&&s[4]<='8')&&s[2]=='-')
            {
            if(abs(s[0]-s[3])==2&&abs(s[1]-s[4])==1)
            	printf("Yes\n");
            else if(abs(s[0]-s[3])==1&&abs(s[1]-s[4])==2)
            	printf("Yes\n");
            else
            	printf("No\n");
            }
            else
            	printf("Error\n"); 
	}
	return 0;
}