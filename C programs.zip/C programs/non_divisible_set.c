#include <stdio.h>
void quicksort(long long int x[],long long int first,long long int last){
    long long int pivot,j,temp,i;

     if(first<last){
         pivot=first;
         i=first;
         j=last;

         while(i<j){
             while(x[i]<=x[pivot]&&i<last)
                 i++;
             while(x[j]>x[pivot])
                 j--;
             if(i<j){
                 temp=x[i];
                  x[i]=x[j];
                  x[j]=temp;
             }
         }

         temp=x[pivot];
         x[pivot]=x[j];
         x[j]=temp;
         quicksort(x,first,j-1);
         quicksort(x,j+1,last);

    }
}
int main()
{
	int n,k,num,max=-1,j,i,c=0,index=0;
	scanf("%d %d",&n,&k);
	long long int a[n],b[n];
	for(i=0;i<n;i++)
	{
	scanf("%lld",&a[i]);
	}
	for(i=0;i<n-1;i++)
	{
	for(j=i+1;j<n;j++)
	{
		if(a[i]!=a[j])
		{
		if((a[i]+a[j])%k!=0)
		{
			b[index++]=a[i];
			b[index++]=a[j];
		}
		}
	}
	}
	quicksort(b,0,index-1);
	long long int prev=b[0];
	for(i=0;i<index;i++)
	{
		// if(b[i]!=0)
		// if(b[i+1]==b[i])
		// {
		// 	key=b[i];
		// 	b[i+1]=0;
		// 	j=i+2;
		// 	while(b[j]==b[i])
		// 	{
		// 		b[j]=0;
		// 		j++;
		// 	}
		// }
		//printf("b[i]=%lld\n",b[i]);
		if(prev!=b[i])
			c++;
	}
	printf("%d\n",c-1);
}