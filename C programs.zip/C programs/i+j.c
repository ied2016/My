#include <stdio.h>
int main()
{
	int i,j=0,sum=0;
	for(i=0;i<5;i++,j++)
	{
	printf("\nsum=%d",i+j);
	}
	return 0;
}