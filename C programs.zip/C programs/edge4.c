#include <stdio.h>
#include <stdbool.h>
int a[100000],b[100000],w[100000];
 
void quicksort(long int low , long int high){
    long int temp,i,j;
    
    if(low<high){
        i=low;
        j=high;
        while(i<j){
            while(w[low]>=w[i]&&i<high)
            i++;
            while(w[low]<w[j])
            j--;
            if(i<j){
                temp = w[i];
                w[i] = w[j];
                w[j] = temp;
                temp = a[i];
                a[i] = a[j];
                a[j] = temp;
                temp = b[i];
                b[i] = b[j];
                b[j] = temp;
            }
        }
        temp = w[low];
        w[low] = w[j];
        w[j] = temp;
        temp = a[low];
        a[low] = a[j];
        a[j] = temp;
        temp = b[low];
        b[low] = b[j];
        b[j] = temp;
        
        quicksort(low,j-1);
        quicksort(j+1,high);
    }
}
 
int main()
{
	int t,v,j,k,se;
    
    long int i,e,maxcost;
    
    scanf("%d",&t);
    while(t--){
    scanf("%d %ld",&v,&e);
    
    bool path[v+1][v+1];
    for(i=0;i<=v;i++){
    	for(j=0;j<=v;j++)
    	path[i][j]=0;
    }
    
    for(i=0;i<e;i++)
    scanf("%d %d %d",&a[i],&b[i],&w[i]);
    
    quicksort(0,e-1);
    
    se=1;
    i=e-1;
    maxcost =0;
    while(se<v){
        if(path[a[i]][b[i]]==0){
            
            for(j=1;j<=v;j++){
                if(path[a[i]][j]==1){
                path[j][b[i]]=1;
                path[b[i]][j]=1;
                for(k=1;k<=v;k++){
                    if(path[b[i]][k]==1){
                        path[j][k]=1;
                        path[k][j]=1;
                    }
                }
                }
            }
            path[a[i]][b[i]]=1;
            path[b[i]][a[i]]=1;
            for(j=1;j<=v;j++){
                    if(path[b[i]][j]==1){
                        path[a[i]][j]=1;
                        path[j][a[i]]=1;
                    }
            }
                
            maxcost += w[i];
            se++;
        }
        i--;
    }
    printf("%ld\n",maxcost);
    }
    return 0;
}