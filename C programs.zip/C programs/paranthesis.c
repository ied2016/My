#include <stdio.h>
#include <string.h>
int main()
{
	int i,j,l,t,count=0;
	char s[11111],p;
	scanf("%d",&t);

	for(j=0;j<t;j++)
	{
			scanf("%s",&s);
				l=strlen(s);
				char st[11111];
				int top=-1;
	count=0;
	for(i=0;i<l;i++)
	{
	//if(s[i]=='{'||s[i]=='('||s[i]=='[')
	st[++top]=s[i];

	
		p=st[top];
	//top--;
	
	if(p=='{'&&s[i]=='}')
	{count+=2;
		printf("\n %c {=%d ",p,count);
	}
	else if(p=='('&&s[i]==')')
		{count+=2;		printf("\n %c (=%d ",p,count);
}
	else if(p=='['&&s[i]==']')
	{count+=2;
		printf("\n %c [=%d ",p,count);

	}
	else
		count+=0;
}
	printf("%d\n",count);

	}
}
	

//{{{{{{{{{}}}
//{{{{{{{{{{{{{{}}}{{{()
//{{{{{{{{{{{}{{{{{{{()))}}
