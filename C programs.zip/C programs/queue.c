#include <stdio.h>
#define size 10000
int a[size],front=-1,rear=-1;

void insert(int x)
{
	if(rear==size-1)
	printf("queue is  full!!!");
	else
	{
		if(front==-1)
		front=0;
	rear++;
	a[rear]=x;
	}
}

void pop()
{
	if(rear==-1)
	printf("Queue is already empty!!!");
	else
	{
	front++;
	}
}

void display()
{
	int i;
	for(i=front;i<=rear;i++)
	printf(" %d ",a[i]);
}

int main()
{
	int i,cont=1,j,e,n;

	while(cont==1)
	{

	printf("enter choice =");
	scanf("%d",&n);

	if(n==1)
	{
	printf("Enter element to be inserted=");
	scanf("%d",&e);
	insert(e);
	}

	else if(n==2)
	pop();

	else
	display();

	printf("\nDo you want to continue=");
	scanf("%d",&cont);
	}
	return 0;
}