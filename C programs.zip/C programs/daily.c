#include <stdio.h>
#include <string.h>
int main()
{
	int i,t,x,n,m,place,comp,c=0,count=0;
	char s[80];
	scanf("%d %d",&x,&n);
	while(n--)
	{
	scanf("%s",s);
	for(i=0;i<strlen(s);i++)
	{
	if(s[i]=='1')
	c=0;
	else
	{
		c++;
		if(c==x)
		{
			c=0;
			printf("done!!!\n");
			count++;
		}
	}
	}
	}
	printf("count=%d\n",count);
}