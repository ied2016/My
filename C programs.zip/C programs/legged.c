#include <stdio.h>
int main()
{
	int t,n,i,num;
	scanf("%d",&t);
	while(t--)
	{
	long long int count=0;
	scanf("%d",&n);
	int a[1002]={0};
	// for(i=0;i<1001;i++)
	// 	a[i]+=i;
	for(i=0;i<n;i++)
	{
	scanf("%d",&num);
	a[num]+=num;
	}
	for(i=1;i<=1000;i++)
	{
		count+=a[i]/3;
	}
	printf("%lld\n",count);
	}
return 0;
}