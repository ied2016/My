#include <stdio.h>
void is(int size, int arr[]) {
	int i,j,k,shift=0,tmp;
	for(i=1;i<size ;i++)
	{tmp=arr[i];
	j=i-1;
	while(tmp < arr[j])
	{shift++;
		arr[j+1]=arr[j];
		j--;
	}
	arr[j+1]=tmp;
}}
int main()
{int i,j,k,boys[111],girl[111],T,m,n,flag=1,*p1,*p2,t,f=0,a[5]={1,2,3,4,5};
	scanf("%d",&t);
	for(T=0;T<t;T++)
	{	f=0;
		flag=1;
		scanf("%d %d",&m,&n);
		printf("\n m=%d n=%d",m,n);
		for(j=0;j<m;j++)
			scanf("%d",&boys[j]);
			for(k=0;k<n;k++)
			scanf("%d",&girl[k]);
				printf("\ngirl=%d",girl[0]);

		is(m,boys);
		is(n,girl);
		is(5,a);
		for(j=0;j<5;j++)
			printf(" %d ",a[j]);
		printf("\ngirl=%d",girl[0]);

		p2=&girl[0];
printf("\ngirl=%d",girl[0]);
	for(j=0;j<m;j++)
			printf(" %d ",boys[j]);
			for(k=0;k<n;k++)
			printf(" %d ",girl[k]);


		for(i=0;i<m;i++)
		{
			p1=&boys[i];
			while(((*p1-*p2)<0)||((p2)!=&girl[n]))
			{
				p2++;
			}
			if(f==0)
		{
			*p1=0;
			if(p2==&girl[n])
			f=1;
		}
		}
		for(i=0;i<m;i++)
			if(boys[i]!=0)
				flag=0;
			if(flag==1)
				printf("YES\n");
			else
				printf("NO\n");
	}
	return 0;
}
