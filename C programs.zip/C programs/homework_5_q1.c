#include <stdio.h>
int n,top1=-1,top2=-1,size;

void push1(int st1[], int x)
{
	if(top1==size)
		printf("Stack1 is overflown!!!");
	else
		st1[++top1]=x;
}

void push2(int st2[], int x)
{
	if(top2==size)
		printf("Stack2 is overflown!!!");
	else
		st2[++top2]=x;
}

int main()
{
	int i,x,m=-1,st1[0],st2[0];
	scanf("%d",&n);
	if(n%2==0)
	{int st1[n/2], st2[n/2];	size=n/2;}
	else
	{int st1[n/2+1], st2[n/2+1];	size=n/2+1;}
	for(i=0;i<n;i++)
	{
	scanf("%d",&x);
	if(m==-1)
	{push1(st1,x);	m*=-1;}
	else
	{push2(st2,x);	m*=-1;}
	}
		printf("\nst1=%d st2=%d",st1[0],st1[1]);
}