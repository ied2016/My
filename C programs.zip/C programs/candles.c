#include <stdio.h>
int main()
{
	int a,b,can,m,j,rem,count;
	scanf("%d %d",&a,&b);
	can=a;
	j=a;
	while(j>=b)
	{
		count=j/b;
		rem=a%b;
		can+=count;
		j=rem+count;
	}
	printf("%d",can);
	return 0;
}