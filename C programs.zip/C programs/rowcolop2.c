#include <stdio.h>
#include <string.h> 
int main()
{
	int n,q,x,i,j,maxr=-1,maxc=-1;
	char s[10];
	scanf("%d %d",&n,&q);
	int r[314160]={0},c[314160]={0};
	while(q--)
	{
	scanf("%s",s);
	if(strcmp(s,"RowAdd")==0)
	{
	scanf("%d %d",&i,&x);
	r[i]+=x;
	if(maxr<r[i])
		maxr=r[i];
	}
	else
	{
	scanf("%d %d",&j,&x);
	c[j]+=x;
	if(maxc<c[j])
		maxc=c[j];
	}
	}
	printf("%d",maxr+maxc);
	return 0;
}