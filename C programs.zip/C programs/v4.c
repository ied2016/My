#include <stdio.h>

int n;
int part(int A[], int p, int r)
{
	int x,tmp,i,j;
	x=A[r];
	i=p-1;
	for(j=p;j<=r-1;j++)
	{
	if(A[j]>=x)
	{
	i++;
	tmp=A[i];
	A[i]=A[j];
	A[j]=tmp;
	}
	}
	tmp=A[i+1];
	A[i+1]=A[r];
	A[r]=tmp;
	return i+1;
}

void Qwk(int A[], int p, int r)
{
	int i;
	if(p<r)
	{
	int q=part(A,p,r);
	printf("OnCall p=%d  r=%d  q=%d\n",p,r,q);
	for(i=0;i<n;i++)
		printf(" =%d ",A[i]);
	printf("\n");
	Qwk(A,p,q-1);
		printf("1 OnCall p=%d  r=%d  q=%d\n",p,r,q);
		for(i=0;i<n;i++)
		printf(" ==%d ",A[i]);
		printf("\n");
	Qwk(A,q+1,r);
		printf("2 OnCall p=%d  r=%d  q=%d\n",p,r,q);
		for(i=0;i<n;i++)
		printf(" ===%d ",A[i]);
		printf("\n");
	}
	else
			printf("else OnCall p=%d  r=%d  \n",p,r);

}

int main()
{
	scanf("%d",&n);
	int i,j,a[n];
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	Qwk(a,0,n-1);
	//for(i=0;i<n;i++)
	//	printf(" %d ",a[i]);
}