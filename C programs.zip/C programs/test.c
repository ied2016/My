#include <stdio.h>
struct ar{
	int key;
	struct ar* next;
};

struct arr{
	struct ar* a[5];
};

int main()
{
	int i,j,n,v;
	scanf('%d',&v);
	printf("how many=");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
	scanf("%d %d",&a1,&a2);
	a[a1]->next=&a[a2];
	a[a1]->head=&a[a2];
	a[a2]->next=&a[a1];
	a[a2]->head=&a[a1];
	}
	

}