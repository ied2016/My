#include <stdio.h>
int main()
{
	int k,n,i,x,count,a,b;
	printf("Enter the values for k and n : ");
	scanf("%d %d",&k,&n);
	int arr[k],B[k];
	for(i=0;i<k;i++)							
		arr[i]=0;								//declearing each element of array to zero
	printf("Enter your n numbers : ");
	for(i=0;i<n;i++)
	{
	scanf("%d",&x);								//scanning the number 
	arr[x]+=1;									//increasing that position of the array by 1 to get the count of that number 
	}
	int c=0;
	for(i=0;i<k;i++)
	{
		c+=arr[i];						
		B[i]=c;									//taking count of all previous elements and putting in a new array B[]		
	}
	printf("Enter the range [a,b] : ");
	scanf("%d %d",&a,&b);
	if(a>0)										//subtracting the count of all the values less than a from count till b
		count=B[b]-B[a-1];						//and that gives the count of all values in range [a,b] 
	else
		count=B[b]-B[a];
	printf("Output :%d\n",count);
}