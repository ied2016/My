#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*void  swap(long long int *a,long long int *b){
 int temp;
 temp=*a;
 *a=*b;
 *b=temp;
}
*/
void maxheapify(long long int  *a,long long int i,long long int n)
	{
	 long long int l=(2*i)+1,temp;
	 long long int r=(2*i)+2;
	 long long  int largest,temp;
	 if(l<n && a[l]>=a[i])
	 	{
		 largest=l;
		}
	 else
	
		{
		 largest=i;
		}
	if(r<n && a[r]>=a[largest])
	 	{
		 largest=r;
		}
	if(largest!=i)
	 	{
		 //swap(&a[largest],&a[i]);
		 temp=a[largest];
		 a[largest]=a[i];
		 a[i]=temp;
		 maxheapify(a,largest,n);
		}
	}
void buildheap(long long  int *a,long long int n)
 {
  long long int  i;
  for(i=((n/2)-1);i>=0;i--)
	{
	 maxheapify(a,i,n);
	}
	
 }

int main(){
  int t,i;
 scanf("%d",&t);
 for(i=0;i<t;i++)
 	{
	 long  long int N,M,j,k,num,count=0,m;
	 scanf("%lld",&N);
	 scanf("%lld",&M);
	 long  long int *p=(long long int*)malloc(N*sizeof(long long int));
	 for(j=0;j<N;j++)
	 	{
	 	 scanf("%lld",&p[j]);
		}
	 for(k=0;k<M;k++)
	 	{
	 	 maxheapify(p, 0 , N);
		 count+=(p[0]-(p[0]/2));
		 p[0]/=2;
		
		}
	 printf("%lld\n",count);
	}
 return 0;
}
	 
	 
	 
 
