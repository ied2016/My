#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct facebook
{
int friends;  
struct facebook *next,*prev;
}*head1=NULL,*start;

struct facebook *spli(struct facebook *head)
{
    struct facebook *fast = head,*slow = head;
    while (fast->next && fast->next->next)
    {
        fast = fast->next->next;
        slow = slow->next;
    }
    struct facebook *temp = slow->next;
    slow->next = NULL;
    return temp;
}
// Function to merge two linked lists
struct facebook *mergeo(struct facebook *first, struct facebook *second)
{
    // If first linked list is empty
    if (!first)
        return second;
 
    // If second linked list is empty
    if (!second)
        return first;
 
    // Pick the smaller value
    if (first->friends<second->friends)
    {
    	    	printf("up1");
        first->next = mergeo(first->next,second);
        first->next->prev = first;
        first->prev = NULL;
        return first;
    }
    else
    {    	printf("down1");

        second->next = mergeo(first,second->next);
        second->next->prev = second;
        second->prev = NULL;
        return second;
    }
}
 
struct facebook *mergeSort(struct facebook *head)
{
    if (!head || !head->next)
        return head;
    struct facebook *second=spli(head) ;
 
    // Recur for left and right halves
    head = mergeSort(head);
    second = mergeSort(second);
 
    // Merge the two sorted halves
    return mergeo(head,second);
}

void insert(int x)
{
    struct facebook *temp=(struct facebook*)malloc(sizeof(struct facebook));
    if(head1==NULL)
    {
    temp->next=NULL;
    temp->prev=NULL;
    temp->friends=x;
    head1=temp;
    start=temp;
    return;
    }
    temp->friends=x;
    temp->prev=head1;
    temp->prev->next=temp;
    temp->next=NULL;
    head1=temp;
    return;
    // else if(x==1)
    // {
    // temp->next=start;
    // temp->prev=NULL;
    // scanf("%s",&temp->name);
    // scanf("%d",&temp->friends);
    // start=temp;
    // return;
    // }
}

void display()
{
    struct facebook *temp=(struct facebook*)malloc(sizeof(struct facebook));
    temp=start;
    printf("\n");
    while(temp!=NULL)
    {
        printf(" %d ",temp->friends);
        temp=temp->next;
    }
}

int main()
{
    int n,num,i;
    scanf("%d",&num);
    for(i=0;i<num;i++)
    {
        scanf("%d",&n);
        insert(n);
    }
    display();
    start=mergeSort(start);
    display();
    return 0;
}