#include <stdio.h>
#include <stdlib.h>
struct ll{
	int key;
	struct ll *next;
}*start,*end;
struct ll* head=NULL;

void insert(int x,int pos)
{
	struct ll *temp=(struct ll*)malloc(sizeof(struct ll));
	if(pos==-1)
	{
	if(head==NULL)
	{//printf("herer");
		temp->key=x;
		temp->next=head;
		head=temp;
		start=temp;
		return;
	}
	temp->key=x;
	//printf("\nst=%d",start->key);
	temp->next=start;
	//start->next=NULL;
	start=temp;
	}

	if(pos==1)
	{
		if(head==NULL)
		{
		temp->key=x;
		temp->next=head;
		head=temp;
		start=temp;
		return;
		}
	//	printf("haer");
		head->next=temp;
		temp->key=x;
		temp->next=NULL;
		head=temp;

	}
}

void display1()
{
	struct ll *temp=(struct ll*)malloc(sizeof(struct ll));
	temp=start;	//printf("1=%d 2=%d 3=%d",start->key,start->next->key,start->next->next->next);

	while(temp!=NULL)
	{
		printf("%d ",temp->key);
		temp=temp->next;
	}
}

void reversell()
{
	struct ll *temp=(struct ll*)malloc(sizeof(struct ll));
	struct ll *prev=NULL,*save;
	
	temp=start;
	while(temp!=NULL)
	{
	save=temp->next;
	temp->next=prev;
	prev=temp;
	temp=save;
	}
	start=prev;
}

int main()
{
	int t,i,num ,pos=1;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
		head=NULL;
	scanf("%d",&pos);
	while(pos!=0)
	{
	scanf("%d",&num);
	insert(num,pos);
	scanf("%d",&pos);
	}
	//display1();
	reversell();
	display1();
	printf("\n");
	free(head);
	}
	return 0;
}