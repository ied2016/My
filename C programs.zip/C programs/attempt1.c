l#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int cmpfunc (const void * a, const void * b)
{
   return ( *(char*)a - *(char*)b );
}

char c[26]={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'}; 			
void please(char ss1[],char ss2[])
{
	int a[26]={0},b[26]={0},i,j,k;
	for(j=0;j<strlen(ss2);j++)
	{
	a[ss1[j]-'a']+=1;
	b[ss2[j]-'a']+=1;
	}

	for(i=0;i<26;i++)
	{
	if(a[i]!=0&&b[i]!=0)
	{
	if(a[i]<=b[i])
		k=a[i];
	else
		k=b[i];
	for(j=0;j<k;j++)
	{
	printf("%c",c[i]);
	}
	}
	} 
}
int main()
{
	//int a[26]={0},b[26]={0},i,t,j,k;
	int t,i;
	char s1[110000],s2[110000];
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
	scanf("%s",s1);
	scanf("%s",s2);
	qsort(s1,strlen(s1),sizeof(char),cmpfunc);
	qsort(s2,strlen(s2),sizeof(char),cmpfunc);	
	please(s1,s2);
	// for(j=0;j<strlen(s2);j++)
	// {
	// a[s1[j]-'a']+=1;
	// b[s2[j]-'a']+=1;
	// }

	// for(i=0;i<26;i++)
	// {
	// if(a[i]!=0&&b[i]!=0)
	// {
	// if(a[i]<=b[i])
	// 	k=a[i];
	// else
	// 	k=b[i];
	// for(j=0;j<k;j++)
	// {
	// printf("%c",c[i]);
	// }
	// }
	// } 
	printf("\n");
	 }
	return 0;
}