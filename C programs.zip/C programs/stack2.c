#include <stdio.h>
int front=-1,rear=-1,a[1111],top=-1;

int frnt()
{
	printf("%d",a[front]);
	if(front==rear)
		printf("%d",-1);
}

int dequeue()
{
	if(rear==-1)
	printf("%d",-1);
	else
	{
	printf("%d",a[front]);
	front++;
	}
}

int enqueue(int x)
{
	printf("%d",x);
	a[rear++]=x;
}

int isempty()
{
	if(front==rear)
	printf("%d",1);
	else
		printf("%d",0);
}

int main()
{
	int n,t,e,i,j,ch;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
	scanf("%s",&ch);
	if(ch=="front")
	{frnt();
	printf(" %d",0);
	}
	else if(ch=="dequeue")
	{
	dequeue();
	printf(" %d",0);
	}
	else if(ch=="enqueue")
	{
	scanf("%d",&e);
	enqueue(e);
	}
	else
	{isempty();
	printf(" %d",0);
	}
	}
}