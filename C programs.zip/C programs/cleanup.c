#include <stdio.h>
int main()
{
	int t,n,m,num,i,j;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
	int a[1002]={0};
	scanf("%d %d",&n,&m);
	for(j=0;j<m;j++)
	{
	scanf("%d",&num);
	a[num]=2;
	}
	for(j=1;j<=n;j++)
	{
	if(a[j]!=2)
	a[j]=1;
	}
	int m=-1;
	for(j=1;j<=n;j++)
	{
		if((m==-1)&&a[j]==1)
		printf("%d ",j);
		if(a[j]==1)
		m*=-1;
	}
	printf("\n");
	m=-1;
	for(j=1;j<=n;j++)
	{
		if((m==1)&&a[j]==1)
		printf("%d ",j);
		if(a[j]==1)
		m*=-1;
	}
	printf("\n");
	}
}