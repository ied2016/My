#include<stdio.h>
#include<stdlib.h>
#include<limits.h>

void swap(int *a,int *b)
{
    int temp;
    temp=*a;
    *a=*b;
    *b=temp;
}
int randition(int a[],int p,int r)
{   time_t t;
    srand(t);
    int pivot1=rand()%(r-p+1)+p;
    int pivot2=rand()%(r-p+1)+p;
    int pivot3=rand()%(r-p+1)+p;
    int max1=a[pivot1];
    int max2=a[pivot2];
    int max3=a[pivot3];
    if(a[pivot1]>a[pivot2]>a[pivot3] || a[pivot1]<a[pivot2]<a[pivot3])
        swap(&a[pivot2],&a[r]);
    if(a[pivot1]>a[pivot3]>a[pivot2] || a[pivot1]<a[pivot3]<a[pivot2])
        swap(&a[pivot3],&a[r]);
    if(a[pivot2]>a[pivot1]>a[pivot3] || a[pivot2]<a[pivot1]<a[pivot3])
        swap(&a[pivot1],&a[r]);
    int x=a[r];
    int i=p-1;
    int j;
    for(j=p; j<=r-1; j++)
    {
        if(a[j]<=a[r])
        {
            i++;
            swap(&a[j],&a[i]);
        }
    }

    swap(&a[i+1],&a[r]);

    return (i+1);
}
void ran_quick(int a[],int p,int r)
{
    if(p<=r)
    {
        int w=randition(a,p,r);
        ran_quick(a,p,w-1);
        ran_quick(a,w+1,r);
    }
}
int main()
{
    int size;
    printf("enter the size");
    scanf("%d",&size);
    int a[size];
    int i;
    for(i=0; i<size; i++)
    {
        scanf("%d",&a[i]);
    }
    ran_quick(a,0,size-1);
    for(i=0; i<size; i++)
    {
        printf("%d ",a[i]);
    }
}
