#include <stdio.h>
#include <string.h>
char st[10000];
int top=-1;
void push(char ch)
{
st[++top]=ch;
}

char pop()
{
	if(st[top]==-1)
		return -1;
	top--;
	return st[top+1];
}

int main()
{
	int n,i,j,l,f=0,t;
	char s[80],p;
	scanf("%d",&t);
	for(j=0;j<t;j++)
	{
	scanf("%s",&s);
	l=strlen(s);
	for(i=0;i<l;i++)
	{
	if(s[i]=='{'||s[i]=='('||s[i]=='[')
	push(s[i]);	
	else
	{
	p=pop();
	if(p=='{'&&s[i]=='}')
	continue;
	else if(p=='('&&s[i]==')')
	continue;
	else if(p=='['&&s[i]==']')
	continue;
	else 
	{
	printf("NO\n");
	break;
	}
	}
	}
	printf("YES\n");
	}
	return 0;
}