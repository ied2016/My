#include <stdio.h>
#include <stdlib.h>
void H(long long int heap[],long long int n)
{long long int i,j,c,root,temp;
  for(i=0;i<n;i++)
    {
       c=i;
		 do
        {
            root=(c-1)/2;             
            if (heap[root]<heap[c])   
            {
                temp=heap[root];
                heap[root]=heap[c];
                heap[c]=temp;
            }
          c=root;
        }while(c!=0);
    }
for(j=n-1;j>=0;j--)
    {
        temp=heap[0];
        heap[0]=heap[j];   
        heap[j]=temp;
        root=0;
        do 
        {
            c=2*root+1;   
            if((heap[c]<heap[c+1])&&c<j-1)
             c++;
            if(heap[root]<heap[c]&&c<j)    
            {
                temp=heap[root];
                heap[root]=heap[c];
                heap[c]=temp;
            }
            root=c;
        }while(c<j);
    } 
}

int main()
{
	long int i,j,n,t,d,bacteria=0,m;
	scanf("%lld",&t);
	for(i=0;i<t;i++)
	{
	bacteria=0;
	scanf("%lld %lld",&n,&m);
	long int a[1000000];
	for(j=0;j<n;j++)
	scanf("%lld",&a[j]);
	for(j=0;j<m;j++)
	{	

		H(a,n);
		d=a[n-1]/2;
		bacteria+=a[n-1]-d;
		a[n-1]=d;

	}
	printf("\n%lld",bacteria);
	}
	return 0;
}
