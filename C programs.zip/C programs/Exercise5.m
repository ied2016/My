x=zeros(1,200)
a=[8 6 4 2 10]
for i=1:1:5
	x(1,i)=a(1,i)