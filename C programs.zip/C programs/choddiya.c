#include <stdio.h>
int main()
{
	char feed[100006];
	int i,t,f=0;
	scanf("%d\n",&t);
	while(t--)
	{
	f=0;
	gets(feed);
	for(i=0;feed[i]!='\0';i++)
	{
	if((feed[i]='1'&&feed[i+1]=='0'&&feed[i+2]=='1')||(feed[i]=='0'&&feed[i+1]=='1'&&feed[i+2]=='0'))
	{
	f=1;
	break;
	}
	} 
	if(f==1)
		printf("Good\n");
	else 
		printf("Bad\n");
	}
}