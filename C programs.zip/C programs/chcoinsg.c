#include <stdio.h>
int main()
{
	long long int t,num,i,n;
	scanf("%lld",&t);
	for(i=0;i<t;i++)
	{
	scanf("%lld",&n);
	if(n==6)
	printf("Misha\n");
	else
		printf("Chef\n");
	}
return 0;
}