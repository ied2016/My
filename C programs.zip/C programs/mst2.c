#include<stdlib.h>
#include<stdio.h>
#define MAX 5001
struct point{int weight,int vetex};
struct point{
	long long weight;
	int vetex;
};
struct point queue[MAX];
int length;
int marked[MAX];
struct node {
	int weight;
	int vetex;
	struct node* next;
};
struct node* adj[MAX];

void swap(struct point *a,struct point *b){
	struct point tmp=*a;
	(*a).weight=(*b).weight;
	(*a).vetex=(*b).vetex;
	(*b).weight=tmp.weight;
	(*b).vetex=tmp.vetex;
}
void print(){
	int i;
	for(i=1;i<=length;i++){
		printf(" (%lld,%d)",queue[i].weight,queue[i].vetex);
	}
	printf("\n");
}
void max_heapify (int i) {
	int left = 2*i;
	int right = 2*i +1;
	int largest;
	if(left<= length && queue[left].weight > queue[i].weight )
		largest = left;
	else
		largest = i;
	if(right <= length && queue[right].weight > queue[largest].weight )
		largest = right;
	if(largest != i ) {
		swap (&queue[i] , &queue[largest]);
		max_heapify (largest);
	} 
}
void build_maxheap() {
	for(int i = length/2 ; i >= 1 ; i-- ) {
		max_heapify (i);
	}
}
struct point maximum(){
	return queue[1];
}
struct point extract_maximum () {
	if(length == 0) {
		printf("Can’t remove element as queue is empty\n");
		struct point a;
		a.vetex=-1;
		a.weight=-1;
		return a;
	}
	struct point max = queue[1];
	queue[1].weight = queue[length].weight;
	queue[1].vetex = queue[length].vetex;
	length = length -1;
	max_heapify(1);
	return max;
}
void increase_value (int i, struct point p) {
	if(p.weight < queue[i].weight) {

		printf("New value is greater than current value, can’t be inserted\n");
		return;
	}
	queue[i].weight = p.weight;
	queue[i].vetex = p.vetex;
	while( i > 1 && queue[i/2].weight < queue[i].weight) {
		swap(&queue[i/2], &queue[i]);
		i = i/2;
	}
}
void insert_value (struct point p) {
	length = length + 1;
	queue[length].weight = -1;
	queue[length].vetex = p.vetex;
	increase_value (length,p);
}
long long prim(int x) {
	long long maximumCost = 0;
	struct point first;
	first.weight=0;
	first.vetex=x;
	insert_value(first);
	while(length>0) {
		struct point p=extract_maximum ();
		x = p.vetex;
		//printf("+(%d,%lld)->",x,p.weight);
		if(marked[x] == 1) continue;//这一个代码的作用也很重要！
		//直接过滤掉不合格的顶点！
		maximumCost += p.weight;
		marked[x] = 1;
		struct node *current=adj[x];
		while (current != NULL) {
			int y=current->vetex;
			if(marked[y] == 0){
				struct point near;
				near.weight=current->weight;
				near.vetex=current->vetex;
				//printf(" (%d,%d)",current->vetex,current->weight);
				insert_value(near);
			}
			current = current->next;
		}
		//printf("\n");
	}
	return maximumCost;
}

int main() {
	int t;
	scanf("%d",&t);
	while(t--){
		int nodes, edges;
		scanf("%d%d",&nodes,&edges);
		//printf("%d个点，%d个边\n",nodes,edges);
		int i;
		for(i=1; i<=nodes; i++) {
			adj[i]=NULL;
		}
		for(i = 0;i < edges;++i) {
			int x,y;
			long long weight;
			scanf("%d%d%lld",&x,&y,&weight);
			struct node *a=malloc(sizeof(struct node));
			a->weight=weight;
			a->vetex=x;
			a->next=NULL;

			if(adj[y]==NULL){
				adj[y]=a;
			}else{
				struct node *last=adj[y];
				while (last->next != NULL) {
					last = last->next;
				}
				last->next=a;
			}

			a=malloc(sizeof(struct node));
			a->weight=weight;
			a->vetex=y;
			a->next=NULL;

			if(adj[x]==NULL){
				adj[x]=a;
			}else{
				struct node *last=adj[x];
				while (last->next != NULL) {
					last = last->next;
				}
				last->next=a;
			}

		}
		/*
		for(i = 1;i <= nodes;++i) {
			printf("%d: ",i);
			struct node *last=adj[i];
			while (last != NULL) {
				printf(" %d",last->vetex);
				last = last->next;
			}
			printf("\n");

		}
		*/
		length=0;
		long long maximumCost = prim(1);
		printf("%lld\n",maximumCost);
	}
	return 0;
}
