#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int size;

void push(int stack[], int * top, int data)
{
	if(*top==-1)
		{	*top=*top+1;
			stack[*top]=data;
			printf("%d\n",data);
		}
	else if(*top==size-1)
		printf("OVERFLOW\n");
	else if(stack[*top]%2==0)
	{	if(data%2==0)
		{	*top=*top+1;
			stack[*top]=data;
			printf("%d\n",data);
		}
		else
		printf("NA\n");		
	}
	else if(stack[*top]%2==1)
	{	if(data%2==1)
		{	*top=*top+1;
			stack[*top]=data;
			printf("%d\n",data);
		}
		else
		printf("NA\n");		
	}
			

}

void pop(int stack[],int *top)
{
	if(*top==-1)
		printf("UNDERFLOW\n");
	else
	{
		printf("%d\n",stack[*top]);
		*top=*top-1;
	}
}

int main()
{
	int n,q;
	scanf("%d%d",&n,&q);
	size=n;
	int stack[size];
	int top=-1;
	int i;
	for(i=0;i<q;i++)
	{
		int data;
		char qry[20];
		scanf("%s",qry);
		if(strcmp(qry,"PUSH")==0)
		{
			scanf("%d",&data);
			push(stack,&top,data);
		}
		else if(strcmp("POP",qry)==0)
			pop(stack,&top);
	}
return 0;
}