#include <stdio.h>
int main()
{	
    	int maxr=0,maxc=0;		
    	int n,q;
    	scanf("%d",&n);
    	scanf("%d",&q);
        int r[314170]={0},c[314170]={0};
    	char str[15];
    	while(q--)
    	{
    		scanf("%s",str);
    		int i,x;
    		scanf("%d",&i);
    		scanf("%d",&x);
    		if(str[0]=='R')
    		{
    			r[i]+=x;
    			if(r[i]>maxr) 
                    maxr=r[i];
    		}
    		else if(str[0]=='C')
    		{
    			c[i]+=x;
    			if(c[i]>maxc) 
                    maxc=c[i];
    		}
    	}
    	printf("%d",maxr+maxc);
    	return 0;
} 
 