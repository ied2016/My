#include <stdio.h>
void swap( int a[], int i, int j)	
{
	int t = a[i];
	a[i] = a[j];
	a[j] = t;
}
 
int partition( int a[], int s, int e)	
{
	int l;
	int i;
 
	swap(a, s, (s + e) / 2);
	l = s;	
 
	for (i = s + 1; i <= e; i++)
		if (a[i] < a[s])	
		{
			l++;	
			swap(a, l, i);	
		}
 
	swap(a, s, l);	
 
	return l;
}
 
void quicksort( int a[], int s, int e)	
{
	int l;
 
	if (s >= e)
		return;	
 
	l = partition(a, s, e);
 
	quicksort(a, s, l - 1);	
	quicksort(a, l + 1, e);	
}

int main()
{
	int t,i,n,k;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		int a[n],pos;
		for(i=0;i<n;i++)
			scanf("%d",&a[i]);
		scanf("%d",&k);
		int song=a[k-1];
		quicksort(a,0,n-1);
		int l=0,u=n-1,mid;
		while(l<=u)
		{
			mid=(l+u)/2;
			if(song==a[mid])
			{
				pos=mid;
				break;
			}
			else if(song<a[mid])
				u=mid-1;
			else
				l=mid+1;
		}
		printf("%d\n",pos+1);
	}
}