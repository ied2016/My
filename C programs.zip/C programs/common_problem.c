#include <stdio.h>
#include <stdlib.h>
struct node{
	int key;
	struct node *next,*head;
};

struct graph
{
	int v;
	struct node* array;
};

struct node* createnode(int x)
{
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->key=x;
	temp->next=NULL;
	return temp;
}

struct graph* creategraph(int v)
{
	struct graph* g=(struct graph*)malloc(sizeof(struct graph));
	g->v=v;
	g->array=(struct node*)malloc((v+1)*sizeof(struct node));
	int i;
	for(i=1;i<=v;i++)
		g->array[i].head=NULL;
	return g;
}

void addedge(struct graph* g,int a1,int a2)
{
	struct node* temp=createnode(a2);
	temp->next=g->array[a1].head;
	g->array[a1].head=temp;
	temp=createnode(a1);
	temp->next=g->array[a2].head;
	g->array[a2].head=temp;
}

int bfs(int s,int v,struct graph* g)
{
	int i,visited[v];
	for(i=0;i<v;i++)
	{
		visited[i]=0;
	}
	visited[s]=1;
	int a[v],rear=-1,front=-1;
	a[++rear]=s;
	int count=0;
	struct node* temp;
	while(front!=rear)
	{
		int u=a[++front];
		for(temp=g->array[u].head;temp!=NULL;temp=temp->next)
		{
			if(visited[temp->key]==0)
			{
				count++;
				//printf("\nnum=%d",temp->key);
				visited[temp->key]=1;
				a[++rear]=temp->key;
			}
		}
	}
	return count;
}

int main()
{
	int v,e,q,i,s;
	scanf("%d %d %d",&v,&e,&q);
	struct graph* g=creategraph(v);
	for(i=0;i<e;i++)
	{
		int a1,a2;
		scanf("%d %d",&a1,&a2);
		addedge(g,a1,a2);
	}
	for(i=0;i<q;i++)
	{
	scanf("%d",&s);
	int c=bfs(s,v,g);	
	printf("%d\n",c);
	}
	return 0;
}