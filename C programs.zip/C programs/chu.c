#include <stdio.h>
#include <stdlib.h>
int main()
{
    printf("2\n1");
    fflush(stdout);
}