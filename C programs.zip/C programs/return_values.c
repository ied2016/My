# include <stdio.h>
# include <stdlib.h>
int main()
{
	int i,j,k,a[100];
	int n;
	i=scanf("%d",&n);
	j=MB_CUR_MAX;
	printf("return value of scanf=%d 	max bytes=%d\n",i,j);
}