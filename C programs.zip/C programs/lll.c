#include <stdio.h>
#include <stdlib.h>

struct ll
{
	int data;
	struct ll *next;
};

struct ll* head=NULL;


void swap(struct ll *xp, struct ll *yp)
{
    int temp = xp->data;
    xp->data = yp->data;
    yp->data = temp;
}

void bubbleSort(struct ll *head1)
{
    int swapped, i;
    struct ll *ptr1, *lptr = NULL;

    if (ptr1 == NULL)
        return;
 
    do
    {
        swapped = 0;
        ptr1 = head1;
 
        while (ptr1->next != lptr)
        {
            if (ptr1->data > ptr1->next->data)
            { 
                swap(ptr1, ptr1->next);
                swapped = 1;
            }
            ptr1 = ptr1->next;
        }
        lptr = ptr1;
    }
    while (swapped);
}

void b(struct ll *head2)
{
	struct ll *tmp=(struct ll*)malloc(sizeof(struct ll)),*i;
	tmp=head2;
	for(tmp=head2;tmp->next!=NULL;tmp=tmp->next)
	{
		for(i=tmp->next;i!=NULL;i=i->next)
		{
			if(tmp->data>i->data)
				swap(tmp->data,i->data);
		}
	}
}

void input(int x)
{
	struct ll* nnn=(struct ll*)malloc(sizeof(struct ll));
	nnn->data=x;
	nnn->next=head;
	head=nnn;
}

void display()
{
	struct ll* temp=(struct ll*)malloc(sizeof(struct ll));
	temp=head;
	while(temp!=NULL)
	{
	printf(" %d ",temp->data);
	temp=temp->next;
	}
}

void delete(int x)
{
	struct ll* temp=(struct ll*)malloc(sizeof(struct ll));
	while(temp!=NULL)
	{
		if(temp->data==x)
		{
			saveaddr=

		}
	}
}

int main()
{
	int i,j,t,n,x;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
	scanf("%d",&x);
	input(x);
	}
	struct ll *h=head;
	bubbleSort(h);
	printf("\nll is=");
	display();
	return 0;
}