#include <stdio.h>
int main()
{
	int i,j,k,t,n,
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
		scanf("%d %d",size,q);
		int a[size];
		for(j=0;j<size;j++)
			scanf("%d",&a[j]);

		for(j=0;j<q;j++)
		{
		scanf("%d %d %d",&l,&r,&k);
		


		}
	}
}