#include <stdio.h>
int n;
bool check()
{
	return 5<n<45;
}
int main()
{
scanf("%d",&n);
int a=check();
	printf("ans=%d",a);
}