#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static int myCompare (const void * a, const void * b)
{
    return strcmp (*(const char **) a, *(const char **) b);
}
int main()
{
char a[3][80];int i;
for(i=0;i<3;i++)
scanf("%s",&a[i]);
qsort(a,3,sizeof(const char *),myCompare);
for(i=0;i<3;i++)
printf(" =%s ",a[i]);
}