#include <stdio.h>
//#define max 1000000;
struct edge
{
	int x,y,weight;
};
struct edge e[666666],e1[666666];
int id[666666];
void m(struct edge A[],int p,int q,int r)
{	int n1,n2;
	n1=q-p+1;
	n2=r-q;
	int i,j,k;
	struct edge tmp,L[n1+1],R[n2+1];
	for(i=1;i<=n1;i++)
	{
	//L[i]=A[p+i-1].weight;
		L[i].x=A[p+i-1].x;
		L[i].y=A[p+i-1].y;
		L[i].weight=A[p+i-1].weight;

	}
	for(j=1;j<=n2;j++)
		{
	//R[j]=A[q+j].weight;
		R[j].x=A[q+j].x;
		R[j].y=A[q+j].y;
		R[j].weight=A[q+j].weight;

	}
	//R[j]=A[q+j].weight;
	L[n1+1].weight=9999999;
	R[n2+1].weight=9999999;
	i=1;
	j=1;
	for(k=p;k<=r;k++)
	{
	if(L[i].weight<=R[j].weight)
	{
	A[k].x=L[i].x;
	A[k].y=L[i].y;
	A[k].weight=L[i].weight;
	i=i+1;
	}
	else
	{
	//A[k]=R[j];
	A[k].x=R[j].x;
	A[k].y=R[j].y;
	A[k].weight=R[j].weight;
	j=j+1;
	}
	}
	//printf("\n");
	// for(i=1;i<=top;i++)
	// 	{
	// 		printf(" %d ",A[i]);
	// 	}
}

void vs(struct edge A[],int p,int r)
{
	int q;
	if(p<r)
	{
	q=(p+r)/2;
	vs(A,p,q);
	vs(A,q+1,r);
	m(A,p,q,r);
	}
}

void sort(struct edge e[],int r,int size){
	int i,j;
	for(i=r;i<size;i++)
	{
		int max=i;
		for(j=i+1;j<size;j++)
		{
			if(e[j].weight<=e[max].weight)
			{
				max=j;
			}
		}
		struct edge tmp;
		tmp.x=e[i].x;
		tmp.y=e[i].y;
		tmp.weight=e[i].weight;

		e[i].x=e[max].x;
		e[i].y=e[max].y;
		e[i].weight=e[max].weight;

		e[max].x=tmp.x;
		e[max].y=tmp.y;
		e[max].weight=tmp.weight;
	}
}

void initial()
{
	int i;
	for(i=0;i<666666;i++)
	 id[i]=i;
}

int root(int r)
{
	//printf("r=%d\n",r);
	while(id[r]!=r)
	{
	//printf("r=%d 	id[r]=%d id[id[r]]=%d\n",r,id[r],id[id[r]]);
	id[r]=id[id[r]];
	r=id[r];
	}
	return r;
}

void u(int a,int b)
{
	int aa=root(a);
	int bb=root(b);
	//printf("a=%d b=%d aa=%d bb=%d id[aa]=%d id[bb]=%d\n",a,b,aa,bb,id[aa],id[bb]);
	id[aa]=id[bb];
}

long long k(struct edge e2[],int r,int r1)
{
	int a,b,i;
	long long maxcost=0,cost;
	for(i=r;i<r1;i++)
	{//printf("here\n");
//printf("\nhere=  %d %d weight=%d\n",e2[i].x,e2[i].y,e2[i].weight);
		a=e2[i].x;
		b=e2[i].y;
		cost=e2[i].weight;
		if(root(a)!=root(b))
		{//printf("in cost here\n");
			maxcost+=cost;
			u(a,b);
		}
	}
return maxcost;
}

int main()
{
	int i,r1,r2,nodes,k1=0;
	long long mcost;
	initial();
	scanf("%d %d %d",&nodes,&r1,&r2);
	int r=r1+r2;
	for(i=0;i<r;i++)
	{
		scanf("%d %d %d",&e[i].x,&e[i].y,&e[i].weight);
		if(i>=r1)
					{	//printf("\nk1=%d  %d %d weight=%d\n",k1,e[i].x,e[i].y,e[i].weight);
						e1[k1].x=e[i].x;
						e1[k1].y=e[i].y;
						e1[k1++].weight=e[i].weight;
					}
	}
	//vs(e,0,r1);
	sort(e,0,r);
	mcost=k(e,0,r);
	printf("%lld",mcost);
	//printf("\nfor e2= \n");
    initial();
	sort(e1,0,r2);
	//vs(e1,r1,r2-1);
	mcost=k(e1,0,r2);
	printf(" %lld",mcost);
	return 0;
}