#include <stdio.h>
#include <string.h>

char order[26];

struct s{
char s[80];
};
void M(struct s arr[],int low,int high){

    int mid;

    if(low<high){
         mid=(low+high)/2;
         M(arr,low,mid);
         M(arr,mid+1,high);
         merge(arr,low,mid,high);
    }
}

void merge(struct s arr[],int low,int mid,int high)
{  
    int i,m,k,l,temp[11111];
    l=low;
    i=low;
    m=mid+1;
    while((l<=mid)&&(m<=high)){

         if(stcmpv(arr[])){
             temp[i]=arr[l];
             l++;
         }
         else{
             temp[i]=arr[m];
             m++;
         }
         i++;
    }

    if(l>mid){
         for(k=m;k<=high;k++){
             temp[i]=arr[k];
             i++;
         }
    }
    else{
         for(k=l;k<=mid;k++){
             temp[i]=arr[k];
             i++;
         }
    }
   
    for(k=low;k<=high;k++){
         arr[k]=temp[k];
    }
}






int strcmpv(char s1[],char s2[])
{	
	int l1,l2,i1,i2,j,i;
	char fi,sec;
	l1=strlen(s1);
	l2=strlen(s2);
	if(l1<l2)
	{
	for(i=0;i<l1;i++)
	{
	fi=s1[i];
	sec=s2[i];
	for(j=0;j<strlen(order);j++)
	{
	if(order[j]==fi)
	i1=j;
	if(order[j]==sec)
	i2=j;
	}
	if(i1>i2)
	return -1;
	}
	}
	else if(l1>l2)
	{
	for(i=0;i<l2;i++)
	{
	fi=s1[i];
	sec=s2[i];
	for(j=0;j<strlen(order);j++)
	{
	if(order[j]==fi)
	i1=j;
	if(order[j]==sec)
	i2=j;
	}
	if(i1>i2)
	return -1;
	}
	}
	return 0;
}

int main()
{
	int i,j,k,n,r,t;
	char tmp[10000];
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
	scanf("%s",order);
	scanf("%d",&n);
	struct st[n];
	//char s[n][10000];
	for(j=0;j<n;j++)
	scanf("%s",st[j].s);
	M(st,0,n-1);

	for(j=0;j<n;j++)
	{
	for(k=1;k<n;k++)
	{
	r=strcmpv(order,s[j],s[k]);
	if(r==-1)
	{
	strcpy(tmp,s[j]);
	strcpy(s[j],s[k]);
	strcpy(s[k],tmp);
	}
	}
	}
	for(j=0;j<n;j++)
	{
		printf("\n%s",s[j]);
	}
	}
	return 0;
}