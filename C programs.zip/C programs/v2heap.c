#include <stdio.h>
void max_heapify(char *a, int i, int n)
{
    int j;
    char temp;
    temp = a[i];
    j = 2 * i;
    while (j <= n)
    {
        if (j < n && a[j+1] > a[j])
            j = j + 1;
        if (temp < a[j])
            break;
        else if (temp >= a[j])
        {
            a[j / 2] = a[j];
            j = 2 * j;
        }
    }
    a[j/2] = temp;
    return;
}
void build_maxheap(int *a,int n)
{
    int i;
    for(i = n/2; i >= 1; i--)
    {
        max_heapify(a,i,n);
    }
}
int main()
{
    int n, i, x;
    char s[123];
    printf("enter no of elements of array\n");
    scanf("%d",&n);
    int a[n][123];
    for (i = 1; i <= n; i++)
    {
       scanf("%d",&s);
       strcpy(a[i],s);
    }
    build_maxheap(a,n);
    printf("Max Heap\n");
    for (i = 1; i <= n; i++)
    {
        printf("%d",a[i]);
    }
    }