#include <stdio.h>
#include <stdlib.h>
int main()
{
	int i,n,max=-1,sum=0;
	scanf("%d",&n);
	int a[n],*p1,*p2;
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	p1=&a[0];
	p2=p1;
	while(p1!=&a[n])
	{	
		sum=0;
		while(*p2!=0&&p2!=&a[n])
		{
			sum+=*p2;
			p2++;
		}
		if(p2!=&a[n])
		{	
			p1=p2+1;
			p2++;
		}
		p1=p2;
		if(max<sum)
			max=sum;
		if(p2==&a[n])
			break;
	}
	printf("%d",max);
}