#include <stdio.h>
#include <stdlib.h>

void swap(int *a,int *b)
{
    int temp;
    temp=*a;
    *a=*b;
    *b=temp;
}

int part(int a[], int p, int r)
{
	int x,i=p-1,j,p1=rand()%(r-p+1)+p,p2=rand()%(r-p+1)+p,p3=rand()%(r-p+1)+p,B[3],k;
    if (a[p1] > a[p2] && a[p1] > a[p3]) {
        swap(&a[p1],&a[r]);
    }
    else if (a[p2] > a[p1] && a[p2] > a[p3]) {
     swap(&a[p2],&a[r]);
    }
    else if (a[p3] > a[p1] && a[p3] > a[p2]) {
    	    swap(&a[p3],&a[r]);
    }
    for(j=p;j<=r-1;j++)
    {
        if(a[j]<=a[r])
        {
            i++;
            swap(&a[j],&a[i]);
        }
    }
    swap(&a[i+1],&a[r]);
	return i+1;
}

void Qwk(int A[], int p, int r)
{
	if(p<r)
	{
	int q=part(A,p,r);
	Qwk(A,p,q-1);
	Qwk(A,q+1,r);
	}
}

int main()
{
	int i,j,n,a[100];
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	Qwk(a,0,n-1);
	for(i=0;i<n;i++)
		printf(" %d ",a[i]);
}