#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int cmpfunc (const void * a, const void * b)
{
   return ( *(char*)a - *(char*)b );
}
int please(char ss1[],char ss2[])
{
	int a[26]={0},b[26]={0},i,j,k;
	for(j=0;j<strlen(ss1);j++)
	{
	a[ss1[j]-'a']+=1;
	
	}
for(j=0;j<strlen(ss2);j++)
	{
	b[ss2[j]-'a']+=1;
	
	}
	for(i=0;i<26;i++)
	{
	if(a[i]!=0&&b[i]!=0)
	{
		return 1;
	}
	} 
	return 0;
}
int main()
{
	int t,i,j,k;
	char s1[110000],s2[110000];
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
		int a[256]={0};
	scanf("%s",s1);
	scanf("%s",s2);
	qsort(s1,strlen(s1),sizeof(char),cmpfunc);
	qsort(s2,strlen(s2),sizeof(char),cmpfunc);	
	int ans=0;
	for(j=0;j<strlen(s1);j++)
	{
		a[s1[j]-'a']+=1;
	}
	for(k=0;k<strlen(s2);k++)
	{
		if(a[s2[k]-'a']!=0)
		{
			printf("%c",s2[k]);
			a[s2[k]-'a']--;
		}
	}
	printf("\n");
	 }
	return 0;
}