#include <stdio.h>
#include <stdlib.h>
int cmpfunc (const void * a, const void * b)
{
   return ( *(int*)b - *(int*)a );
}
int main()
{
	int t,n,i;
	scanf("%d",&t);
	while(t--)
	{
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
    qsort(a, n, sizeof(int), cmpfunc);
   	// for(i=0;i<n;i++)
   	// 	printf(" %d ",a[i]);
   	i=0;
   	//n--;
   	while(n--)
   		{//printf("n=%d\n",n);
   			if(n>0)
   			{
   				if(a[n]-a[n-1]<0)
   					i++;
   			}
   		}
   	printf("%d\n",i+1);
   }
return 0;
}