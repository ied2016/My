// // // #include <stdio.h>
 
// // // /* Function for bucket sort */
// // // void Bucket_Sort(int array[], int n)
// // // {  
// // //     int i, j;  
// // //     int count[n]; 
// // //     for (i = 0; i < n; i++)
// // //         count[i] = 0;
 
// // //     for (i = 0; i < n; i++)
// // //         (count[array[i]])++;
 
// // //     for (i = 0, j = 0; i < n; i++)  
// // //         for(; count[i] > 0; (count[i])--)
// // //             array[j++] = i;
// // // }   
// // // /* End of Bucket_Sort() */
 
// // // /* The main() begins */
// // // int main()
// // // {
// // //     int array[100], i, num; 
 
// // //     printf("Enter the size of array : ");   
// // //     scanf("%d", &num);   
// // //     printf("Enter the %d elements to be sorted:\n",num); 
// // //     for (i = 0; i < num; i++)
// // //         scanf("%d", &array[i]); 
// // //     printf("\nThe array of elements before sorting : \n");
// // //     for (i = 0; i < num; i++)
// // //         printf("%d ", array[i]);  
// // //     printf("\nThe array of elements after sorting : \n"); 
// // //     Bucket_Sort(array, num); 
// // //     for (i = 0; i < num; i++)
// // //         printf("%d ", array[i]);   
// // //     printf("\n");     
// // //     return 0;
// // // }
// // #include<stdio.h>
// // void Bucket_Sort(int array[], int n)
// // {   
// //  int i, j;   
// //  int count[n];  
// //  for(i=0; i < n; i++)
// //  {   
// //   count[i] = 0;   
// //  }     
// //  for(i=0; i < n; i++)
// //  {    
// //   (count[array[i]])++; 
// //  }     
// //  for(i=0,j=0; i < n; i++)
// //  {   
// //   for(; count[i]>0;(count[i])--) 
// //   {       
// //    array[j++] = i; 
// //   }  
// //  }   
// // }    
// // int main() 
// // { 
// //  int array[100];   
// //  int num;   
// //  int i;  
// //  printf("Enter How many Numbers : ");    
// //  scanf("%d",&num);    
// //  printf("Enter the %d elements to be sorted:\n",num);  
// //  for(i = 0; i < num; i++ )
// //  {   
// //   scanf("%d",&array[i]);  
// //  }   
// //  printf("\nThe array of elements before sorting : \n"); 
// //  for (i = 0;i < num;i++) 
// //  {    
// //   printf("%d ", array[i]);   
// //  }    
// //  printf("\nThe array of elements after sorting : \n");  
// //  Bucket_Sort(array, num);  
// //  for (i = 0;i < num;i++) 
// //  {     
// //   printf("%d ", array[i]);  
// //  }   
// //  printf("\n");      
// //  }
// #include <stdio.h>
// #include <iostream>
// #include <algorithm>
// #include <vector>
// using namespace std;
 
// // Function to sort arr[] of size n using bucket sort
// void bucketSort(float arr[], int n)
// {
//     // 1) Create n empty buckets
//     vector<float> b[n];
    
//     // 2) Put array elements in different buckets
//     for (int i=0; i<n; i++)
//     {
//        int bi = n*arr[i]; // Index in bucket
//        b[bi].push_back(arr[i]);
//     }
 
//     // 3) Sort individual buckets
//     for (int i=0; i<n; i++)
//        sort(b[i].begin(), b[i].end());
 
//     // 4) Concatenate all buckets into arr[]
//     int index = 0;
//     for (int i = 0; i < n; i++)
//         for (int j = 0; j < b[i].size(); j++)
//           arr[index++] = b[i][j];
// }
 
// /* Driver program to test above funtion */
// int main()
// {
//     float arr[] = {0.897, 0.565, 0.656, 0.1234, 0.665, 0.3434};
//     int n = sizeof(arr)/sizeof(arr[0]);
//     bucketSort(arr, n);
 
//     cout << "Sorted array is \n";
//     for (int i=0; i<n; i++)
//        cout << arr[i] << " ";
//     return 0;
// }
//#include <conio.h>
#include <stdio.h>
 
int main()
{
int unsorted[50] , bucket[10][50]={{0}} , sorted[50] ;
int j , k , m , p , flag = 0, num, N;
printf("\nEnter the number of elements to be sorted :");
scanf("%d",&N);
printf("\nEnter the elements to be sorted :\n");
for(k=0 ;  k < N ; k++){
scanf("\n%d",&num);
sorted[k] = unsorted[k] = num;
}
 
for(p=1; flag != N ; p*=10){
 
flag = 0;
 
for(k=0;k<N;k++){
bucket[(sorted[k]/p)%10][k] = sorted[k];
if( (sorted[k]/p)%10  == 0 ){
   
flag++;
   
}
}
 
if(flag == N){
   
printf("\nSorted List: \n");
   
for(j=0 ;  j < N ; j++){
   
printf("%d\t", sorted[j]);
   
}
   
printf("\n");
    
return 0;
   
}
 
for(j=0,m=0;j<10;j++){
for(k=0;k<N;k++){
if( bucket[j][k] > 0 ){
  
sorted[m] = bucket[j][k];
  
bucket[j][k] = 0 ;
  
m++;
  
}
}
}
 
}
 
return 0 ;
}