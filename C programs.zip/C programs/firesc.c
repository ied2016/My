#include <stdio.h>
int main()
{
	int n,m,i,k=0,j=0,t,prev,New,n1,n2;
	scanf("%d",&t);
	while(t--)
	{
	scanf("%d %d",&n,&m);
	int a[100002]={0};
	while(m--)
	{
	scanf("%d %d",&n1,&n2);
	if(a[n1]==0&&a[n2]==0)
	{
	//if(n1<n2)
		a[n1]=a[n2]=n1;
	// else
	// 	a[n1]=a[n2]=n2;		
	}
	else
	{
	if(a[n1]!=0&&a[n2]==0)
		a[n2]=a[n1];
	else if(a[n1]==0&&a[n2]!=0)
		a[n1]=a[n2];
	else
		{
		// if(a[n1]<a[n2])
		// {
			prev=a[n2];
			a[n2]=a[n1];
			New=a[n2];
			for(i=0;i<=n;i++)
			{
			if(prev==a[i])
				a[i]=New;
			}
		//}
		// else
		// {
		// 	prev=a[n1];
		// 	a[n1]=a[n2];
		// 	New=a[n1];
		// 	for(i=0;i<=n;i++)
		// 	{
		// 	if(prev==a[i])
		// 		a[i]=New;
		// 	}
		// }
		}
	}
	}
	int com=0;
	long long int captain=1;
	int count[100002]={0};
	for(i=1;i<=n;i++)
	{
		if(a[i]!=0)
		count[a[i]]+=1;
		else
			com++;
	}
	for(i=0;i<=n;i++)
	{
		if(count[i]!=0)
			{
				com++;
				captain*=count[i];
				//printf("count[%d]=%d\n",i,count[i]);
			}
	}
	printf("%d %lld\n",com,captain);
	}
return 0;
}