#include <stdio.h>
int main()
{
	int n,w,l,i,start,wood=0,month=0,max=-1;
	scanf("%d %d %d",&n,&w,&l);
	int h[n],r[n];
	for(i=0;i<n;i++)
	{
		scanf("%d %d",&h[i],&r[i]);
		if(max<r[i])
			max=r[i];
	}
	start=l/max;
	//printf("max=%d	start=%d\n",max,start);
	if(wood<w)
	{
		for(i=0;i<n;i++)
		{
			h[i]+=start*r[i];
			if(h[i]>=l)
				wood+=h[i];
		}
		month+=start;
	}
	//printf("wood=%d\n",wood);
	while(wood<w)
	{
		wood=0;
		for(i=0;i<n;i++)
		{
			h[i]+=r[i];
			if(h[i]>=l)
				wood+=h[i];
		}
		month++;
	}
	//printf("wood=%d\n",wood);
	printf("%d",month);
	return 0;
}