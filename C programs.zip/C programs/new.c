#include <stdio.h>
#include <string.h>
int main()
{
	char s[100006];
	int t,i,f=0;
	scanf("%d\n",&t);
	while(t--)
	{
	f=0;
	gets(s);
	for(i=0;i<strlen(s);i++)
	{
	if((s[i]=='0'&&s[i+1]=='1'&&s[i+2]=='0')||(s[i]=='1'&&s[i+1]=='0'&&s[i+2]=='1'))
	{
	f=1;
	break;
	}
	}
	if(f==1)
	printf("Good\n");
	else
	printf("Bad\n");
	}
}