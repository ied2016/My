#include <stdio.h>
int main()
{
	int b[1000],a[1000],c[1000],i,j,k,n;
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	printf("Enter value for k :");
	scanf("%d",&k);
	for(i=0;i<=k;i++)
		c[i]=0;
	for(j=0;j<n;j++)
		c[a[j]]=c[a[j]]+1;
	for(i=0;i<=k;i++)
		c[i]=c[i]+c[i-1];
	for(j=n-1;j>=1;j++)
		{
		b[c[a[j]]]=a[j];
		c[a[j]]=c[a[j]]-1;
		}
	for(i=0;i<n;i++)
		printf(" %d ",b[i]);
}