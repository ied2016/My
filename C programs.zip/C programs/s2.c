#include <stdio.h>
#include <stdlib.h>
void mheap(int a[],int i,int n)
	{
	 int l=(2*i)+1,r=(2*i)+2,large,temp;
	if(l<n && a[l]>=a[i])
		 large=l;
	else
		 large=i;
	if(r<n && a[r]>=a[large])
		 large=r;
	if(large!=i)
	 	{
		 temp=a[large];
		 a[large]=a[i];
		 a[i]=temp;
		 mheap(a,large,n);
		}
}
void bh(int a[],int n)
 {
  int i;
  for(i=(n/2);i>=0;i--)
	 mheap(a,i,n);
}

int main()
{
int t,i;
scanf("%d",&t);
for(i=0;i<t;i++)
{
	int n,m,j,k,num,count=0;
	 scanf("%d %d",&n,&m);
	 int a[n];
	 for(j=0;j<n;j++)
	 scanf("%d",&a[j]);
	 bh(a,n);
	 for(k=0;k<m;k++)
	 	{
	 	 mheap(a,0,n);
		 count+=(a[0]-(a[0]/2));
		 a[0]/=2;
		}
	 printf("%d\n",count);
	}
 return 0;
}