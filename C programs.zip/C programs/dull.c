#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct Node{
int data;
struct Node *next,*prev;
}*start;
//struct Node* head=NULL;
void Insert(int x)
{
	struct Node *temp=(struct Node*)malloc(sizeof(struct Node));
	if(head==NULL)
	{
		temp->data=x;
		temp->prev=NULL;
		head=temp;
		start=temp;
		return;
	}
	temp->data=x;
	temp->prev=head;
	temp->prev->next=temp;
	temp->next=NULL;
	head=temp;
}

// void Insert(int x,struct Node* head1)
// {
// 	struct Node *temp=(struct Node*)malloc(sizeof(struct Node));
// 	if(head1==NULL)
// 	{
// 		temp->data=x;
// 		temp->
// 	}
// }

struct Node* deleteDuplicate(struct Node* head1)
{
	struct Node *temp=(struct Node*)malloc(sizeof(struct Node));
	temp=start;
	while(temp!=NULL)
	{
		printf("\ntemp=%lld  temp->next->data=%lld ",temp->data,temp->next->data);
		if(temp->data==temp->next->data&&temp->next!=NULL)
		{
			// if(temp->next->next==NULL)
			// {
			// 	free(temp->next);
			// 	temp->next=NULL;
			// }
			
		
			struct Node *temp1=(struct Node*)malloc(sizeof(struct Node));
			printf("\n delete=%lld ",temp->next->data);
			temp1=temp->next;
			free(temp->next);
			temp->next=temp1->next;
			temp1->next->prev=temp;
			//free(temp1);
		
		}
		temp=temp->next;
	}
	return head1;
}
void removeDuplicates()
{
  struct Node *ptr1, *ptr2, *dup;
  ptr1 = start;
 int c=0;
  while(ptr1 != NULL && ptr1->next != NULL)
  {
     ptr2 = ptr1;
 
     while(ptr2->next != NULL)
     {
   
       if(ptr1->data == ptr2->next->data)
       {

          dup = ptr2->next;
          ptr2->next = ptr2->next->next;
          printf("%d ",dup->data);
          c++;
          free(dup);
       }
       else 
       {
          ptr2 = ptr2->next;
       }
     }
     ptr1 = ptr1->next;
  }
if(c==0)
	printf("%d",-1);
}

void Print(int index)
{
	struct Node *temp=(struct Node*)malloc(sizeof(struct Node));
	temp=start;
	//index++;
	int count=0;
	while(temp!=NULL)
	{
	
		if(count==index-1)
		{printf("%d\n",temp->data);
		return;}
	
	count++;
		temp=temp->next;
	}
	printf("%d\n",-1);
}




int main()
{
	int t,n,index,x,i,j;
	char s[80];
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
		scanf("%d",&x);
		Insert(x);
		while(x!=0)
		{
			scanf("%d",&x);
			if(x!=0)
			Insert(x);
		}
		//display1();
		scanf("%d",&n);
		for(j=0;j<n;j++)
		{
		scanf("%s",&s);
		if(strcmp(s,"Insert")==0)
		{
			scanf("%d",&x);
			Insert(x);
			printf("%d\n",x);
		}
		else if(strcmp(s,"Delete")==0)
		{
			//display1();
			//removeDuplicates();
			head=deleteDuplicate(head);
			printf("\n");
			//display1();
		}
		else if(strcmp(s,"Print")==0)
		{
			scanf("%d",&index);
			Print(index);
		}
		}
	}
return 0;
}