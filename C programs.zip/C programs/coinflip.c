#include <stdio.h>
int main()
{
	int i,j,g,n,l,t,q,first,ans;
	scanf("%d",&t);
	while(t--)
	{
	scanf("%d",&g);
	while(g--)
	{
	scanf("%d %d %d",&l,&n,&q);
	if(l==1)
	{
		if(n%2==0)
			first=1;
		else 
			first=-1;
		if(n%2==0)
			ans=n/2;
		if(q==1&&n%2!=0)
		{
			if(first==1)
				ans=n/2+1;
			else if(first==-1)
				ans=n/2;
		}
		if(q==2&&n%2!=0)
		{
			if(first==1)
				ans=n/2;
			else if(first==-1)
				ans=n/2+1;
		}
	}
	if(l==2)
	{
		if(n%2==0)
			first=-1;
		else
			first=1;
		if(n%2==0)
			ans=n/2;
		if(q==1&&n%2!=0)
		{
			if(first==1)
				ans=n/2+1;
			else if(first==-1)
				ans=n/2;
		}
		if(q==2&&n%2!=0)
			{
				if(first==1)
					ans=n/2;
				else if(first==-1)
					ans=n/2+1;
			}
	}
	printf("%d\n",ans);
	}
	}
}