#include<stdio.h>
#include<string.h>
int st1[1111],st2[1111],top1=-1,top2=-1,save=0;

void enqueue(int x)
{
	top1++;
	st1[top1]=x;
}

void dequeue()
{
	int t1,t2,i;
	top2=-1;
	t1=top1;
	while(top2!=top1)
	{
	top2++;
	st2[top2]=st1[t1];
	t1--;
	}
	printf("%d ",st1[--t1]);
	t2=0;
	for(i=0;i<top1;i++)
{
	st1[t2++]=st2[top2++];
}
}

void isempty()
{
	if(top1==-1)
		printf("%d %d",0,1);
	else
		printf("%d %d",1,1);

}

void front()
{
	printf("%d %d",st1[0],0);
}

int main()
{
	int d=0,t,i,j,e;
	char s;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
	scanf("%s",&s);
	if(strcmp(s,"dequeue"))
	{d++;
	dequeue();
	}
	else if(strcmp(s,"isempty"))
	{
		isempty();
	}
	else if(strcmp(s,"enqueue"))
	{
		scanf("%d",e);
		enqueue(e);
	}
}


}