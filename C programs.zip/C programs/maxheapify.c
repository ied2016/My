#include <stdio.h>
#include <stdlib.h>
int n;
void swap(int *a,int *b)
{
	int tmp;
	tmp=*a;	*a=*b;	*b=tmp;
}
void maxh(int a[],int ind)
{
	int l=ind*2 ,r=ind*2+1,lrg=ind;
	//if(l<n&&r<n)
	//	return;
	if(l<=n&&a[ind]<a[l])
		lrg=l;
	if(r<=n&&a[ind]<a[r])
		lrg=r;
	if(lrg!=ind)
		{
		swap(&a[lrg],&a[ind]);
		maxh(a,lrg);
		}
}

void build(int a[],int size)
{
	int i;
	for(i=(size)/2;i>=0;i--)
		{//printf("a[0]=%d",a[0]);
		maxh(a,i);
	}
}

void hs(int a[])
{
	build(a,n);
	int i;
	for(i=n;i>=1;i--)
	{
		swap(&a[i],&a[1]);
		n--;
		maxh(a,1);
	}
}

int main()
{
	int a[10000],i;
	scanf("%d",&n);
	int size=n;
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	//build(a,n);
	hs(a);
	//printf("max=%d",a[0]);
	for(i=0;i<size;i++)
		printf(" %d ",a[i]);
}