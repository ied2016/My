#include <stdio.h>
long long int decimal_binary(long long int n) 
{
    long long int rem, i=1, binary=0;
    while (n!=0)
    {
        rem=n%10;
        n/=10;
        binary+=rem*i;
        i*=10;
        printf("i=%lld rem=%lld n=%lld binary=%lld\n",i,rem,n,binary);
    }
    return binary;
}
int main()
{
   long long int n;
      // printf("Enter a decimal number: ");
       scanf("%lld",&n);
       printf("%lld in binary",decimal_binary(n));
   return 0;
}