#include <stdio.h>
#include <stdlib.h>
struct bst
{
int key;
struct bst *left,*right;
};

struct bst *insert(struct bst* node,int x)
{
	if(node==NULL)
	{
		struct bst *temp=(struct bst*)malloc(sizeof(struct bst));
		temp->key=x;
		temp->left=temp->right=NULL;
		return temp;
	}

	if(x<=node->key) 
		node->left=insert(node->left,x);
	else if(x>node->key)
		node->right=insert(node->right,x);
	return node;
}

void inorder(struct bst* root)
{
	if(root!=NULL)
	{
			printf("%d ",root->key);

		inorder(root->left);
		inorder(root->right);
	}
}

int main()
{
	int i,j,n,t,num;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
	struct bst *root=NULL;
	scanf("%d",&n);
	scanf("%d",&num);
	root=insert(root,num);
	for(j=0;j<n-1;j++)
	{scanf("%d",&num);
    insert(root, num);} 
    inorder(root);
    free(root);
    printf("\n");
   }
   return 0;
}