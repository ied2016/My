#include <stdio.h>
#include <string.h>
int main()
{
	int i,t,f=0;
	scanf("%d",&t);
	char s[1002];
	while(t--)
	{
		int a[26]={0},b[26]={0};
		f=0;
		scanf("%s",&s);
		if(strlen(s)%2==0)
		{
			//printf("even\n");
			for(i=0;i<strlen(s)/2;i++)
			{
				a[s[i]-'a']+=1;
				//printf("ind=%d\n",s[i]-'a');
			}
			for(i=strlen(s)/2;i<strlen(s);i++)
				b[s[i]-'a']+=1;
			for(i=0;i<26;i++)
				{if(a[i]!=b[i])
					f=1;
					//printf("a=%d b=%d\n",a[i],b[i]);
				}
		}
		if(strlen(s)%2!=0)
		{
			//printf("odd\n");
			for(i=0;i<strlen(s)/2;i++)
			{
				a[s[i]-'a']+=1;
				//printf("ind=%d\n",s[i]-'a');
			}
			for(i=strlen(s)/2+1;i<strlen(s);i++)
				{
				b[s[i]-'a']+=1;
				//printf("c=%c\n",s[i]);
				}
			for(i=0;i<26;i++)
				{if(a[i]!=b[i])
					f=1;
					//printf("a=%d b=%d\n",a[i],b[i]);
				}
		}
	if(f==0)
		printf("YES\n");
	else if(f==1)
		printf("NO\n");
	}

}