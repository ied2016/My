#include <stdio.h>
int main()
{
	int i,j,t,n,k,c;
	long long int min=1000000000;
	long s[6000];
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
	min=1000000000;				//risky point : Don't forget to reset this!!!
	scanf("%d",&n);
	for(j=0;j<n;j++)
	scanf("%d",&s[j]);
	for(j=0;j<n;j++)
		for(k=j+1;k<n;k++)
		{
			c=abs(s[j]-s[k]);
			//printf("c=%d\n",c);
			if(min>c)
			{
				min=c;
				//printf("min=%d",min);
			}
		}
	printf("%d\n",min);
	}
}