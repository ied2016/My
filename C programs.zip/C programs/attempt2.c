#include <stdio.h>
int main()
{
	int t,n,pinc,i,j,c=0,e,num,a,b;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
		scanf("%d %d",&a,&b);
		int A[a],B[b];
		for(j=0;j<a;j++)
		{
			scanf("%d",&A[j]);
			//printf(" \n%d ",A[j]);
		}
		for(j=0;j<b;j++)
		{
			scanf("%d",&B[j]);
					//	printf(" \n%d ",B[j]);

		}
		if(A[0]>=B[b])
			printf("%d\n",0);
		else
			{int m=abs(A[0]-B[b]);
			printf("%d\n",m);
		}
	}
	return 0;
}