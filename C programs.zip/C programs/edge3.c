#include <stdio.h>
#include <stdlib.h>
//long int a[10001][3];
//long int e[10001][3];
struct node{
	long int data;
	//long int k;
	long int n;
	struct node *next;
	struct node *head;
};
struct edge{
	long int s;
	long int f;
	long int w;
};
struct node *v[100001][2];
int sort(struct edge **l, long int n){
	if (n==1 || n==0){
		return 0;
	}
	
	struct edge *a[n/2];
	struct edge *b[n-(n/2)];
	long int i,j;
	struct edge **p=&l[0];
	//printf("%ld\n", (*p)->w);
	for (i=0; i<n/2; i++){
		// a[i][0]=*p++;
		//printf("um %ld\n",a[i][0] );
		// a[i][1]=*p++;
		// a[i][2]=*p++;
		a[i] = *p++;
	}
	for (i=0; i<n-n/2; i++){
		// b[i][0]=*p++;
		// b[i][1]=*p++;
		// b[i][2]=*p++;
		b[i] = *p++;
	}
	//printf("here %ld\n",n);
	//printf("here %ld\n",(a[0])->w );
	sort(a, n/2);
	sort(b,n-n/2);
	i=0;
	j=0;
	struct edge **q=&l[0];
 
	while ((i<n/2)&&(j<n-n/2)){
		if (a[i]->w > b[j]->w){
			//printf("this %ld over %ld\n",b[j][0],a[i][0] );
			// *q++=a[i][0];
			// *q++=a[i][1];
			// *q++=a[i][2];
			*q++=a[i];
			i++;
		}
		else{
			//*q++=b[j];
			// *q++=b[j][0];
			// *q++=b[j][1];
			// *q++=b[j][2];
			*q++=b[j];
			j++;
		}
	}
	for (;i<(n/2); i++){
		//*q++=a[i];
		// *q++=a[i][0];
		// *q++=a[i][1];
		// *q++=a[i][2];
		*q++=a[i];
	}
	for (;j<(n-n/2); j++){
		//*q++=b[j];
		// *q++=b[j][0];
		// *q++=b[j][1];
		// *q++=b[j][2];
		*q++=b[j];
	}
	return 0;
}
int main(void){
	long int n,e,t;
	scanf("%ld",&t);
	while (t--){
		scanf("%ld",&n);
		scanf("%ld",&e);
		struct edge *x[e];
		//struct edge *a[e];
		long int top=0;
		long int i,wt=0;
		for(i=0; i<e; i++){
			struct edge *e = (struct edge *) malloc(sizeof(struct edge));
			
			scanf("%ld",&(e->s));
			scanf("%ld",&(e->f));
			scanf("%ld",&(e->w));
			x[i] = e;
			//a[i][1]=(i%2);
		}
		for(i=1; i<=n; i++){
			struct node *next = (struct node*)malloc(sizeof(struct node));
			next->data = i;
			//n->k = i;
			next->next = NULL;
			next->n = 1;
			v[i][0] = next;
			v[i][1] = next;
			next->head = v[i][0];
		}
		//printf("here %ld\n",n);
		sort(x, e);
		//printf("here %ld\n", v[x[1]->s][0]->head->data);
		for (i=0; i<e; i++){
			//printf("umm %ld\n", v[x[i]->f][0]->head->data);
			//printf("here %ld\n",i );
			if (v[x[i]->s][0]->head->data != v[x[i]->f][0]->head->data){
				//printf("in\n");
				wt+=x[i]->w;
				// a[top][0] = x[i][0];
				// a[top][1] = x[i][1];
				// a[top][2] = x[i][2];
				// top++;
				//printf("reaching here\n");
				if (v[x[i]->s][0]->head->n > v[x[i]->f][0]->head->n){
					//printf("heres\n");
					v[x[i]->s][0]->head->n = v[x[i]->s][0]->head->n + v[x[i]->f][0]->head->n;
					v[v[x[i]->s][0]->head->data][1]->next=v[x[i]->f][0]->head;
					v[v[x[i]->s][0]->head->data][1] = v[v[x[i]->f][0]->head->data][1];
					//printf("here\n");
					struct node *ptr = v[x[i]->f][0]->head;
					//printf("ptr in\n");
					while (ptr!=NULL){
						(ptr)->head = v[x[i]->s][0]->head;
						ptr = ((ptr)->next);
					}
					//printf("ptr out\n");
				}
				else{
					//printf("heres\n");
					v[x[i]->f][0]->head->n = v[x[i]->f][0]->head->n + v[x[i]->s][0]->head->n;
					v[v[x[i]->f][0]->head->data][1]->next=v[x[i]->s][0]->head;
					v[v[x[i]->f][0]->head->data][1] = v[v[x[i]->s][0]->head->data][1];
					//printf("here\n");
					struct node *ptr = v[x[i]->s][0]->head;
					//printf("here?\n");
					while (ptr!=NULL){
						//printf("%ld\n",v[x[i]->f][0]->head->data );
						(ptr)->head = v[x[i]->f][0]->head;
						ptr = ((ptr)->next);
					}
					//printf("final\n");
				}
			}
		}
		// for (i=0; i<top; i++){
		// 	printf("%ld %ld %ld\n",a[i][0],a[i][1],a[i][2] );
		// }
		printf("%ld\n",wt );
		//printf("%ld %ld %ld\n",a[0][0],a[1][0],a[2][0] );
	}
	return 0;
}