// #include <stdio.h>
// int part(int a[],int p, int q)
// {
// 	int r=a[q],j,i,tmp;
// 	j=p;
// 	i=p-1;
// 	for(j=p;j<=q-1;j++)
// 	{
// 	if(a[j]<=r)
// 	{
// 	i++;
// 	tmp=a[i];
// 	a[i]=a[j];
// 	a[j]=tmp;
// 	}
// 	}
// 	tmp=a[q];
// 	a[q]=a[i+1];
// 	a[i+1]=tmp;
// 	return i+1;
// }

// void fun(int a[],int b,int c,int k)
// {
// 	int l=k,n;
// 	n=part(a,b,c);
// 	if(l<n)
// 	return fun(a,b,n-1,k);
// 	else if(l>n)
// 	return fun(a,b,n+1,k);
// 	else if(n==l)
// 	printf("%d\n",a[l]);
// }

// int main()
// {
// 	int t,i,j,k,size,q,l,r,o=0;
// 	scanf("%d",&t);
// 	for(i=0;i<t;i++)
// 	{
// 	scanf("%d %d",&size,&q);
// 	int a[size];
// 	for(j=0;j<size;j++)
// 	scanf("%d",&a[j]);
// 	for(j=0;j<q;j++)
// 	{
// 	scanf("%d %d %d",&l,&r,&k);
// 	int arr[r-l+1],h=l;
// 	while(h<=r)
// 	{
// 	arr[o]=a[h];
// 	h++;
// 	o++;
// 	}
// //	for(o=0;o<r-l+1;o++)
// //	printf("%d ",arr[o]);
// 	fun(arr,0,r-l,k-1);
// 	}
// 	}
// //	return 0;
// }
#include <stdio.h>
#include <stdlib.h>
long long int partition(long long int *a,long long int p,long long int q){
long long int r=a[q],j,i,tmp;
  j=p;
  i=p-1;
 for(j=p;j<=q-1;j++)
 	{
	 if(a[j]<=r)
	 	{
		 i=i+1;
		 tmp=a[i];
		 a[i]=a[j];
		 a[j]=tmp;
		}
	}
	tmp=a[q];
	a[q]=a[i+1];
	a[i+1]=tmp;
	return i+1;
}
void fun(long long int a[],long long int b,long long int c,long long int k)
	{
	 long long int l=k,n;
	 n=partition(a,b,c);
	 //printf("\n n=%d part(a,%d,%d)",n,b,c);
	 if(n==l)
		 printf("%lld\n",a[l]);
	 else if(l<n)
		 return fun(a,b,n-1,k);
	 else if(l>n)
		 return fun(a,n+1,c,k);
	}

int main(){
 long long int t,i,q,k,n,j,o=0,l,r,size;
 scanf("%lld",&t);
 for(i=0;i<t;i++)
 	{
	 scanf("%lld %lld",&size,&q);
	 long long int *a=(long long int*)malloc(size*sizeof(long long int));
	 for(j=0;j<size;j++)
	 	scanf("%lld",&a[j]);
	 for(j=0;j<q;j++)
	 	{
		 scanf("%lld %lld %lld",&l,&r,&k);
		 int arr[r-l+1],h=l;
		 while(h<=r)
		 	{
			 arr[o]=a[h];
			 o++;
			 h++;
			}
		 // for(m=0;o<(R-L)+1;o++)
			//  printf("%d ",arr[o]);
		 //printf("\n");
		 fun(arr,0,r-l,k-1);
		}
	}
 return 0;
}

