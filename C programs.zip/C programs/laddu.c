#include <stdio.h>
#include <string.h>
int main()
{
	int t,i,buggs,rank,m,count=0;
 	int laddu=0;
	char s[100],nationality[100];
	scanf("%d",&t);
	while(t--)
	{
		count=0;
		laddu=0;
		scanf("%d %s",&m,&nationality);
		while(m--)
		{
			scanf("%s",&s);
			if(strcmp(s,"CONTEST_WON")==0)
			{
				scanf("%d",&rank);
				if(rank<20)
					laddu+=300+(20-rank);
				else
					laddu+=300;
			}
			if(strcmp(s,"TOP_CONTRIBUTOR")==0)
				laddu+=300;
			if(strcmp(s,"BUG_FOUND")==0)
			{
				scanf("%d",&buggs);
				laddu+=buggs;
			}
			if(strcmp(s,"CONTEST_HOSTED")==0)
				laddu+=50;
		}
		if(strcmp(nationality,"INDIAN")==0)
		{
			while(laddu>=200)
			{
				laddu-=200;
				count++;
			}
		}
		if(strcmp(nationality,"NON_INDIAN")==0)
		{
			while(laddu>=400)
			{
				laddu-=400;
				count++;
			}
		}
		printf("%d\n",count);
	}	
}