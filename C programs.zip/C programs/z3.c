#include <stdio.h>
struct st {
	int ID;
	int arrival;
	int duration;

};

void M(int arr[],int arr2[],int arr3[],int low,int high){

    int mid;

    if(low<high){
         mid=(low+high)/2;
         M(arr,arr2,arr3,low,mid);
         M(arr,arr2,arr3,mid+1,high);
         merge(arr,arr2,arr3,low,mid,high);
    }
}

void merge(int arr[],int arr2[],int arr3[],int low,int mid,int high)
{  
    int i,m,k,l,temp[11111],temp2[11111],temp3[11111];
    l=low;
    i=low;
    m=mid+1;
    while((l<=mid)&&(m<=high)){

         if(arr[l]<=arr[m]){
             temp[i]=arr[l];	temp2[i]=arr2[l];	temp3[i]=arr3[l];
             l++;
         }
         else{
             temp[i]=arr[m];	temp2[i]=arr2[m];	temp3[i]=arr3[m];
             m++;
         }
         i++;
    }

    if(l>mid){
         for(k=m;k<=high;k++){
             temp[i]=arr[k];	temp2[i]=arr2[k];	temp3[i]=arr3[k];
             i++;
         }
    }
    else{
         for(k=l;k<=mid;k++){
             temp[i]=arr[k];	temp2[i]=arr2[k];	temp3[i]=arr3[k];
             i++;
         }
    }
   
    for(k=low;k<=high;k++){
         arr[k]=temp[k];	arr2[k]=temp2[k];	arr3[k]=temp3[k];
    }
}


int main()
{int i,j,k,n,t,T,arrive[10000],dur[10000],Id[10000];
	scanf("%d",&t);
	for(T=0;T<t;T++)
	{
	scanf("%d",&n);
	struct st s[n];
	for(i=0;i<n;i++)
	{scanf("%d %d %d",&s[i].ID,&s[i].arrival,&s[i].duration);
	arrive[i]=s[i].arrival;
	dur[i]=s[i].duration;
	Id[i]=s[i].ID;
	}
	M(arrive,/*dur,Id,*/0,n);

	for(i=0;i<n;i++)
	{
		printf("\n ID=%d arrive=%d duration=%d ",Id[i],arrive[i],dur[i]);
	}


}
return 0;
}