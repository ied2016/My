import csv
f=open('v.txt')
#of=open('output.txt','w')
l=[]
read=csv.reader(f,delimiter=',')
#Writer=csv.writer(of,delimiter=',');
#Writer.write(l)
l2=[]
l2=csvwriter.writerow(read)
for r in read:
	print r