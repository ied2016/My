#include <stdio.h>
#include <stdlib.h>

int partition(int a[],int p,int q){
 int r=a[q],j=p,i=p-1,temp;
 for(j=p;j<=q-1;j++)
 	{
	 if(a[j]<=r)
	 	{
		 i=i+1;
		 temp=a[i];
		 a[i]=a[j];
		 a[j]=temp;
		}
	}
	temp=a[q];
	a[q]=a[i+1];
	a[i+1]=temp;
	return i+1;
}

void fun(int a[],int b,int c,int k)
	{
	 int l=k,n;
	 n=partition(a,b,c);
	 if(n==l)
		 printf("%d\n",a[l]);
	 else if(l<n)
		 return fun(a,b,n-1,k);
	 else if(l>n)
		 return fun(a,n+1,c,k);
	}

int main(){
 int t,i,q,k,n,j,l,r;
 scanf("%d",&t);
 for(i=0;i<t;i++)
 	{
	 scanf("%d %d",&n,&q);
	 long long int *a=(long long int*)malloc(n*sizeof(long long int));
	 	  for(j=0;j<n;j++)
		 	scanf("%lld",&a[j]);
	 for(j=1;j<=q;j++)
	 	{
		 int o=0;
		 scanf("%d %d %d",&l,&r,&k);
		 int arr[(r-l)+1],h=l;
		 while(h<=r)
		 	{
			 arr[o]=a[h];
			 o++;
			 h++;
			}
		 fun(arr,0,r-l,k-1);
		}
	}
 return 0;
}