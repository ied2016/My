#include <stdio.h> 
#include <string.h>
int main()
{
	int i,j;
	string str1="FUCK ",str2="YOU!!!";
	string concat_str=str1+str2;
	}