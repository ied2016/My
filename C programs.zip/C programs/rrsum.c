#include <stdio.h>
int main()
{
	long long int q,n,i,middle,m,sum,num,ans;
	scanf("%lld %lld",&n,&m);
	middle=2*n+1;
	while(m--)
	{
		scanf("%lld",&q);
		if(n+1<=q<=(2*n+n))
		{
			if(q<=middle)
				ans=q-n-1;
			else if(q>middle)
				ans=(q-((n+2*n)+1))*-1;
		}
		if(q>(n+2*n)||q<(n+2))
				ans=0;
		printf("%lld\n",ans);
	}
return 0;
}