#include <stdio.h>
#include <stdlib.h>
struct bst
{
int key;
struct bst *left,*right;
};

struct bst *insert(struct bst* node,int x)
{
	if(node==NULL)
	{
		struct bst *temp=(struct bst*)malloc(sizeof(struct bst));
		temp->key=x;
		temp->left=temp->right=NULL;
		return temp;
	}

	if(x<=node->key) 
		node->left=insert(node->left,x);
	else if(x>node->key)
		node->right=insert(node->right,x);
	return node;
}


int minDepth(struct bst* root)
{
    if (root == NULL)
        return 0; 
    if (root->left == NULL && root->right == NULL)
       return 1;
     if (!root->left)
       return minDepth(root->right) + 1;
     if (!root->right)
       return minDepth(root->left) + 1;
    return min(minDepth(root->left), minDepth(root->right)) + 1;
}

struct node *lca(struct bst* root, int n1, int n2)
{
    if (root == NULL) return NULL;
     if (root->key > n1 && root->key > n2)
        return lca(root->left, n1, n2);
     if (root->key < n1 && root->key < n2)
        return lca(root->right, n1, n2);
 
    return root;
}

int min(int a,int b)
{
	if(a<b)
		return a;
	else
		return b;
}

int main()
{
	int t,j,i,num,n1,n2,q,n;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
	struct bst *root=NULL;
	scanf("%d",&n);
	scanf("%d",&num);
	root=insert(root,num);
	for(j=0;j<n-1;j++)
	{
	scanf("%d",&num);
    insert(root,num);
    }
    int m=minDepth(root);
    printf("%d\n",m);
    scanf("%d",&q);
    for(j=0;j<q;j++)
    {
    scanf("%d %d",&n1,&n2);
    root=lca(root,n1,n2);
    printf("%d\n",root->key );
    }
    free(root);
   // printf("\n");
}
return 0;
}