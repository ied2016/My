#include <stdio.h>

int part(int a[],int p,int r)
{
	int tmp,i,j,x;
	x=a[r];
	i=p-1;
	for(j=0;j<r;j++)
	{
		if(a[j]>=x)
		{
			i++;
			tmp=a[j];
			a[j]=a[i];
			a[i]=tmp;
		}
	}
	tmp=a[i+1];
	a[i+1]=a[r];
	a[r]=tmp;
	return i+1;
}

int Quick(int a[],int p,int r)
{	
	int q;
	if(p<r)
	{
		q=part(a,p,r);
		printf("q=%d\n",q);
		printf("part(a,%d,%d)",p,r);
		Quick(a,p,q-1);
		printf("Quick(a,%d,%d)",p,q-1);
		Quick(a,q+1,r);
		printf("Quick(a,%d,%d)",q+1,r);		
	}
}

int main()
{
	int i,j,n;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	Quick(a,0,n-1);
	printf("\nThe new array is =");
	for(i=0;i<n;i++)
		printf(" %d ",a[i]);
	return 0;
}

// #include <stdio.h>

// void quickSort( int[], int, int);
// int partition( int[], int, int);


// void main() 
// {
// 	int a[] = { 7, 12, 1, -2, 0, 15, 4, 11, 9};

// 	int i;
// 	printf("\n\nUnsorted array is:  ");
// 	for(i = 0; i < 9; ++i)
// 		printf(" %d ", a[i]);

// 	quickSort( a, 0, 8);

// 	printf("\n\nSorted array is:  ");
// 	for(i = 0; i < 9; ++i)
// 		printf(" %d ", a[i]);

// }



// void quickSort( int a[], int l, int r)
// {
//    int j;

//    if( l < r ) 
//    {
//    	// divide and conquer
//         j = partition( a, l, r);
//        quickSort( a, l, j-1);
//        quickSort( a, j+1, r);
//    }
	
// }



// int partition( int a[], int l, int r) {
//    int pivot, i, j, t;
//    pivot = a[l];
//    i = l; j = r+1;
		
//    while( 1)
//    {
//    	do ++i; while( a[i] <= pivot && i <= r );
//    	do --j; while( a[j] > pivot );
//    	if( i >= j ) break;
//    	t = a[i]; a[i] = a[j]; a[j] = t;
//    }
//    t = a[l]; a[l] = a[j]; a[j] = t;
//    return j;
// }

// #include<stdio.h>
// #include<stdlib.h>
// int partition(int *a,int p,int q){
//  int r=a[q];
//  int j=p;
//  int i=p-1,temp;
//  for(j=p;j<=q-1;j++)
//  	{
// 	 if(a[j]<=r)
// 	 	{
// 		 i=i+1;
// 		 temp=a[i];
// 		 a[i]=a[j];
// 		 a[j]=temp;
// 		}
// 	}
// 	temp=a[q];
// 	a[q]=a[i+1];
// 	a[i+1]=temp;
// 	return i+1;
// }
// void num(int *a,int b,int c,int k)
// 	{
// 	 int l=k;
// 	 int n=partition(a,b,c);
// 	 if(n==l)
// 	 	{
// 		 printf("%d\n",a[l]);
// 		}
// 	 else if(l<n)
// 	 	{
// 		 return num(a,b,n-1,k);
// 		}
// 	 else if(l>n)
// 		{
// 		 return num(a,n+1,c,k);
// 		}
// 	}
// int main(){
//  int T,i;
//  scanf("%d",&T);
//  for(i=0;i<T;i++)
//  	{
// 	 int Q,K,N,j;
// 	 scanf("%d",&N);
// 	 scanf("%d",&Q);
// 	 long long int *p=(long long int*)malloc(N*sizeof(long long int));
// 	 	  for(j=0;j<N;j++)
// 	 		{
// 		 	scanf("%lld",&p[j]);
// 			}
// 	 for(K=1;K<=Q;K++)
// 	 	{
// 		 int L,R,k,m=0;
// 		 scanf("%d",&L);
// 		 scanf("%d",&R);
// 		 scanf("%d",&k);
// 		 int pa[((R-L)+1)];
// 		 int h=L;
// 		 while(h<=R)
// 		 	{
// 			 pa[m]=p[h];
// 			 m++;
// 			 h++;
// 			}
// 		 for(m=0;m<(R-L)+1;m++)
// 		 	{
// 			 printf("%d ",pa[m]);
// 			}
// 		 printf("\n");
// 		 num(pa,0,(R-L),k-1);
// 		}
// 	}
//  return 0;
// }







