#include <stdio.h>
#include <stdlib.h>

int cmpfunc (const void * a, const void * b)
{
   return ( *(int*)a - *(int*)b );
}


void M(int arr[],int low,int high){

    int mid;

    if(low<high){
         mid=(low+high)/2;
         M(arr,low,mid);
         M(arr,mid+1,high);
         merge(arr,low,mid,high);
    }
}

void merge(int arr[],int low,int mid,int high)
{  
    int i,m,k,l,temp[11111];
    l=low;
    i=low;
    m=mid+1;
    while((l<=mid)&&(m<=high)){

         if(arr[l]<=arr[m]){
             temp[i]=arr[l];
             l++;
         }
         else{
             temp[i]=arr[m];
             m++;
         }
         i++;
    }

    if(l>mid){
         for(k=m;k<=high;k++){
             temp[i]=arr[k];
             i++;
         }
    }
    else{
         for(k=l;k<=mid;k++){
             temp[i]=arr[k];
             i++;
         }
    }
   
    for(k=low;k<=high;k++){
         arr[k]=temp[k];
    }
}

int main()
{int i,j,k,T,m,n,flag=1,*p1,*p2,t,f=0,temp,count=0;
	scanf("%d",&t);
	for(T=0;T<t;T++)
	{	f=0;
		flag=1;
		scanf("%d %d",&m,&n);
		int boys[m],girl[n];
		for(j=0;j<m;j++)
			scanf("%d",&boys[j]);
		for(k=0;k<n;k++)
			scanf("%d",&girl[k]);
		
	M(boys,0,m-1);
	M(girl,0,n-1);
     	
     	// qsort(boys, m, sizeof(int), cmpfunc);
    	// qsort(girl, n, sizeof(int), cmpfunc);

		p2=&girl[0];

			/*for(j=0;j<m;j++)
			printf(" %d ",boys[j]);
		for(k=0;k<n;k++)
			printf(" %d ",girl[k]);*/

		if(m<=n){
		for(i=0;i<m;i++)
		{
			// p1=&boys[i];
			// if(*p2>=*p1)
			// 	flag=0;
			// else
			// {
			// 	p2++;
			// 	count++;

			// }
			if(girl[i]>=boys[i]){
				flag=0;
				break;
			}
					
		
		}
	}
	else 
		flag=0;

		//if(count!=m)
		//	flag=0;
			if(flag==1)
				printf("YES\n");
			else
				printf("NO\n");
	}
	return 0;
}