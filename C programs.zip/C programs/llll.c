#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct node{
int key;
char name[80];
struct node *prev,*next;
}startA,startB,headA,headB;

void insertbeg(struct node **head,struct node **start,char linkedin,int data)
{
		struct node *temp=(struct node*)malloc(sizeof(struct node));
		if(*head==NULL)
		{
			strcpy(temp->name,linkedin);
			temp->key=data;
			*head=temp;
			*start=temp;
			return;
		}
		strcpy(temp->name,linkedin);
		temp->key=data;
		temp->next=*start;
		temp->prev=NULL;
		*start->prev=temp;
		*start=temp;
}

void insertend(struct node **head,struct node **start,char facebook,int data)
{
		struct node *temp=(struct node*)malloc(sizeof(struct node));
		strcpy(temp->name,linkedin);
		temp->key=data;
		temp->next=NULL;
		temp->prev=*head;
		*head->next=NULL;
		*head=temp;
}

void display(struct node **head,struct node **start)
{
		struct node *temp=(struct node*)malloc(sizeof(struct node));
		temp=*start;
		while(temp!=NULL)
		{
			printf("\nname=%s key=%d",temp->name,temp->key);
			temp=temp->next;
		}
}

int main()
{
	struct headA=(struct node*)malloc(sizeof(struct node));
	struct headB=(struct node*)malloc(sizeof(struct node));

	struct startA=(struct node*)malloc(sizeof(struct node));
	struct startB=(struct node*)malloc(sizeof(struct node));

	headA=NULL;
	headB=NULL;
	startA=NULL;
	startB=NULL;

	int num,link,friends;
	char linkedin[80],facebook[80];
	scanf("%d",&num);
		if(num==1)
		{
		scanf("%s %d",&linkedin,&link);
			insertbeg(&headA,&startA,linkedin,link);
		}
		else if(num==2)
		{
			scanf("%s %d",&linkedin,&link);
			insertend(&headA,&startA,linkedin,link);
		}
	while(num!=0)
	{
	scanf("%d",&num);
		if(num==1)
		{
		scanf("%s %d",&linkedin,&link);
			insertbeg(&headA,&startA,linkedin,link);
		}
		else if(num==2)
		{
			scanf("%s %d",&linkedin,&link);
			insertend(&headA,&startA,linkedin,link);
		}
	}
	display(headA,startA);
	scanf("%d",&num);
		if(num==1)
		{
		scanf("%s %d",&facebook,&friends);
			insertbeg(&headB,&startB,facebook,friends);
		}
		else if(num==2)
		{
			scanf("%s %d",&facebook,&friends);
			insertend(&headB,&startB,facebook,friends);
		}
	while(num!=0)
	{
	scanf("%d",&num);
		if(num==1)
		{
		scanf("%s %d",&facebook,&friends);
			insertbeg(&headB,&startB,facebook,friends);
		}
		else if(num==2)
		{
			scanf("%s %d",&facebook,&friends);
			insertend(&headB,&startB,facebook,friends);
		}
	}
	display(headB,startB);

}