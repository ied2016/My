#include <stdio.h>

void buildheap(int a,int last)
{int i;
	for(i=last/2;i>=1;i--)
	maxheap(a,i,last);
}

void maxheap(int a[],int parent,int last)
{
	int temp,child;
	temp=a[parent];
	child=2*parent; 
	while(child<=last)
	{
		printf("\nchild=%d parent=%d",child,parent);
	if(child+1<=last&&a[child+1]>a[child])
	child++;
if(temp>a[child])
	break;

	else if(temp<=a[child])
	{
		a[child/2]=a[child];
		child=2*child;
	}
	}
	a[child/2]=temp;
	return;
}


int main()
{
	int i,j,k,n;
	scanf("%d",&n);
	int a[n];
	for(i=1;i<=n;i++)
	scanf("%d",&a[i]);
	buildheap(a,n);
	for(i=1;i<=n;i++)
	printf(" %d ",a[i]);	
}