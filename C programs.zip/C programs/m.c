#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>
int main() {

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    int N,Q;
    scanf("%d%d",&N,&Q);
    int Arr[N+1];
    bool H[N+1];
    int i;
    for(i=1;i<N+1;i++)
        Arr[i] = 1;
    for(i=1;i<N+1;i++)
        H[i] = false;
    int X = 2*Q;
    while(X--){
        char ch;
        int j;
        int personI,personJ;
        scanf("%c",&ch);
        //printf("Q:%d\n",Q);
        if(ch == 'Q'){
            scanf("%d",&personI);
            //printf("Char:%c, PersonI: %d\n",ch,personI);
            if(personI <= N)
                printf("%d\n",Arr[personI]);
        }
        if(ch == 'M'){
            scanf("%d%d",&personI,&personJ);
            //printf("Char:%c, PersonI: %d, PersonJ:%d\n",ch,personI,personJ);
            if(personI <= N && personJ<=N){
                if( Arr[personI] >= Arr[personJ]){
                   Arr[personI] += 1;
                   Arr[personJ] = Arr[personI];
                }
                else{
                    Arr[personJ] += 1;
                    Arr[personI] = Arr[personJ];
                }
                H[personI] = true;
                H[personJ] = true;
                for(j=1;j<=N;j++){
                    if(j==personI || j==personJ)
                        continue;
                    if(H[j] == true){
                        Arr[j] = Arr[personI];
                    }
                }
            }
        }
    }
    return 0;
}