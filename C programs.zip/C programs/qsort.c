#include <stdio.h>
#include <stdlib.h>

char values[] = { 'w','c','s','a','z','b','c' };

int cmpfunc (const void * a, const void * b)
{
   return ( *(char*)b - *(char*)a );
}

int main()
{
   int n;

   printf("Before sorting the list is: \n");
   for( n = 0 ; n < 7; n++ ) 
   {
      printf("%c", values[n]);
   }

   qsort(values, 7, sizeof(char), cmpfunc);

   printf("\nAfter sorting the list is: \n");
   for( n = 0 ; n < 7; n++ ) 
   {   
      printf("%c ", values[n]);
   }
  
   return(0);
}