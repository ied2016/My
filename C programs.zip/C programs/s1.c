#include<stdio.h>
#include<string.h>
int main()
{
	int i;
char s1[]="abc",s2[]="bcd",a[5][103],s[10];
for(i=0;i<3;i++){
scanf("%s",&s);
strcpy(a[i],s);
}
for(i=0;i<3;i++)
printf(" %s ",a[i]);
printf(" %s ",a[0]);

}