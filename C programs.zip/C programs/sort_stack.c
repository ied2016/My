#include <stdio.h>
int top=-1,n,st[11111];
void push(int x)
{
	int temp,j;
	if(top>=n)
		printf("Overflow");
else if(top==-1)
st[++top]=x;
else
	{
	if(st[top]>x)
	{j=top;
		st[top+1]=st[top];
		while(st[j]>x&&j>-1)
		{
	temp=st[j];
	st[j]=x;
	st[j+1]=temp;
	j--;
	}
	printf(" top=%d",st[top]);
}
	else
		st[++top]=x;
	}	
	display();
}
void display()
{
	int i;
		for(i=0;i<n;i++)
	printf(" %d ",st[i]);
}
int main()
{
	int i,x;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{scanf("%d",&x);
	push(x);
	}
	display();
}