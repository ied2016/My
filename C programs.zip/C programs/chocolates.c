#include <stdio.h>
int main()
{
	int i,t,n,j,m,c,count,rem,chocolate;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
	chocolate=0;
	scanf("%d %d %d",&n,&c,&m);
	while(n>0)
	{
	n-=c;
	chocolate++;
	}
	// For Wrappers
	j=chocolate;
	if(j>=m)
	while(j>=m)
	{
	count=j/m;
	chocolate+=count;
	rem=j%m;
	j=rem+count;
	}
 	printf("%d\n",chocolate);
	}
	return 0;
}