#include <stdio.h>
int main()
{
	int t,i,j,n,num,pl,pf,n1,n2,max;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
	int count=0;
	max=0;
	int q;
	//printf("q==");
	scanf("%d",&q);
	//printf("n1 n2=");
	scanf("%d %d",&n1,&n2);
	// if(q==1)
	// 	printf("%d\n",1);
	pf=n1;
	pl=n2;
	count++;
	for(j=0;j<q-1;j++)
	{
	//printf("n1 n2=");
	scanf("%d %d",&n1,&n2);
	if(pl<=n1)//||n2<=pf)			//(n1>=pf&&n2>=pf)||(n1>=pl&&n2>=pl))
	{
		//printf("count=%d max=%d",count,max);
	if(max<count)
		max=count;
	count=0;
	}
	else
	{
	count++;
	}
	// if(max==0)
	// 	max=1;
	// printf("max=%d\n",max);
	pf=n1;
	if(n2>pl)
	pl=n2;
	}
		if(max==0)
		max=1;
	printf("%d\n",max);
}
return 0;
}