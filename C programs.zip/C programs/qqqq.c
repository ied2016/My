#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct Node{
long long int data;
struct Node *next;
}*start,*prev;

struct Node* Insert(struct Node* head1,int x)
{
	if(head1==NULL)
	{
	struct Node *temp=(struct Node*)malloc(sizeof(struct Node));

		temp->data=x;
		temp->next=NULL;
		head1=temp;
		start=temp;
		return head1;
	}
	
	else{	struct Node *temp=(struct Node*)malloc(sizeof(struct Node));

		temp=start;
		while(temp!=NULL)
		{
			if(x<=temp->data||temp->next==NULL)
			{
			struct Node *temp1=(struct Node*)malloc(sizeof(struct Node));	
				temp1->next=temp;
				temp1->data=x;
				prev->next=temp1;
				head1=temp;

			}
			prev=temp;
			temp=temp->next;
		}
	}						
}




void removeDuplicates()
{
  struct Node *ptr1, *ptr2, *dup;
  ptr1 = start;
 int c=0;
  while(ptr1 != NULL && ptr1->next != NULL)
  {
     ptr2 = ptr1;
 
     while(ptr2->next != NULL)
     {
   
       if(ptr1->data == ptr2->next->data)
       {

          dup = ptr2->next;
          ptr2->next = ptr2->next->next;
          printf("%lld ",dup->data);
          c++;
          free(dup);
       }
       else 
       {
          ptr2 = ptr2->next;
       }
     }
     ptr1 = ptr1->next;
  }
if(c==0)
	printf("%d",-1);
}



void Print(long long int index)
{
	struct Node *temp=(struct Node*)malloc(sizeof(struct Node));
	temp=start;
	//index++;
	int count=0;
	while(temp!=NULL)
	{
	
		if(count==index)
		{printf("%lld\n",temp->data);
		return;}
	
	count++;
		temp=temp->next;
	}
	printf("%d\n",-1);
}

void display1()
{
	struct Node *temp=(struct Node*)malloc(sizeof(struct Node));
	temp=start;
	while(temp!=NULL)
	{
		printf(" %lld ",temp->data);
		temp=temp->next;
	}
}

int main()
{
	struct Node* head=NULL;
	long long int t,n,index,x,i,j;
	char s[80];
	scanf("%lld",&t);
	for(i=0;i<t;i++)
	{
		scanf("%lld",&x);
		head=Insert(head,x);
		printf("l,,%d\n",head );
		while(x!=0)
		{
			scanf("%lld",&x);
			if(x!=0)
			head=Insert(head,x);
		}
		scanf("%lld",&n);
		for(j=0;j<n;j++)
		{
		scanf("%s",s);
		if(strcmp(s,"Insert")==0)
		{
			scanf("%lld",&x);
			head=Insert(head,x);
			printf("%lld\n",x);
		}
		else if(strcmp(s,"Delete")==0)
		{
			removeDuplicates();
			printf("\n");
		}
		else if(strcmp(s,"Print")==0)
		{
			scanf("%lld",&index);
			Print(index);
		}
		}
	}
return 0;
}