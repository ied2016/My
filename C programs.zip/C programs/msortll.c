// C program for merge sort on doubly linked list
#include <stdio.h>
#include <stdlib.h>
struct dll
{
    int data;
    struct dll *next, *prev;
}*start;

struct dll *head1=NULL;
 
 // half sizes
struct dll *spli(struct dll *head)
{
    struct dll *fast = head,*slow = head;
    while (fast->next && fast->next->next)
    {
        fast = fast->next->next;
        slow = slow->next;
    }
    struct dll *temp = slow->next;
    slow->next = NULL;
    return temp;
}
// Function to merge two linked lists
struct dll *mergeo(struct dll *first, struct dll *second)
{
    // If first linked list is empty
    if (!first)
        return second;
 
    // If second linked list is empty
    if (!second)
        return first;
 
    // Pick the smaller value
    if (first->data > second->data)
    {
        first->next = mergeo(first->next,second);
        first->next->prev = first;
        first->prev = NULL;
        return first;
    }
    else
    {
        second->next = mergeo(first,second->next);
        second->next->prev = second;
        second->prev = NULL;
        return second;
    }
}
 
struct dll *mergel(struct dll *first, struct dll *second)
{
    // If first linked list is empty
    if (!first)
        return second;
 
    // If second linked list is empty
    if (!second)
        return first;
 
    // Pick the smaller value
    if (first->data < second->data)
    {
        first->next = mergel(first->next,second);
        first->next->prev = first;
        first->prev = NULL;
        return first;
    }
    else
    {
        second->next = mergel(first,second->next);
        second->next->prev = second;
        second->prev = NULL;
        return second;
    }
}
// Function to do merge sort
struct dll *mergeSort(struct dll *head)
{
    if (!head || !head->next)
        return head;
    struct dll *second=spli(head) ;
 
    // Recur for left and right halves
    head = mergeSort(head);
    second = mergeSort(second);
 
    // Merge the two sorted halves
    return mergeo(head,second);
}

void insert(int v)
{
    struct dll *temp=(struct dll*)malloc(sizeof(struct dll));
    temp->data=v;
    if(head1==NULL)
    {
    temp->prev=temp->next=NULL;
    start=temp;
    head1=temp;
    return;
    }
    head1->next=temp;
    temp->prev=head1;
    head1=temp;
    return;
}
 
// A utility function to print a doubly linked list in
// both forward and backward directions
void print()
{
    struct dll *temp = start;
    printf("\nForward Traversal using next poitner : ");
 
    while (temp)
    {
        printf("%d ", temp->data);
        temp = temp->next;
    }
}
 
// Utility function to swap two integers
void swap(int *A, int *B)
{
    int temp = *A;
    *A = *B;
    *B = temp;
}
 void p()
{
    struct dll *temp=(struct dll*)malloc(sizeof(struct dll));
    temp=start;
    //index++;
    //int count=0;
    while(temp!=NULL)
    {
    
        printf(" %d ",temp->data);

        temp=temp->next;
    }
    //printf("%d\n",-1);
}
// Split a doubly linked list (DLL) into 2 DLLs of
void send(int v,int l)
{
    int count=0,i;
    struct dll *temp=start,*savef,*saveb,*sort,*t,*pr,*ret;
    if(v!=1)
    {
    for(i=0;i<v-1;i++)
    {
        printf("\nv== %d ",temp->data);
        temp=temp->next;
    }
    savef=temp->prev;
    temp->prev=NULL;
    sort=temp;
    for(i=v;i<l;i++)
    {
                printf("\nl v=== %d ",temp->data);

        temp=temp->next;
    }
    saveb=temp->next;
    temp->next=NULL;
    ret=mergeSort(sort);
    savef->next=ret;
    ret->prev=savef;
    t=ret;
    while(t)
    {
                pr=t;
                                printf("\nt= %d ",t->data);

        t=t->next;
    }
    pr->next=saveb;
    }
    else if(v==1)
    {
        printf("here" );
       for(i=v;i<l;i++)
    {
                printf("\nl v=== %d ",temp->data);

        temp=temp->next;
    }
    saveb=temp->next;
    temp->next=NULL;
    start=mergeSort(start);
    //savef->next=ret;
    //ret->prev=savef;
    t=start;
    while(t)
    {
                pr=t;
                                printf("\nt= %d ",t->data);

        t=t->next;
    }
    pr->next=saveb; 
    }
    p();
}
 
// Driver program
int main()
{
    int i,j,num,n;
    scanf("%d",&n);
    scanf("%d",&num);
    insert(num);
    for(j=0;j<n-1;j++)
    {
    scanf("%d",&num);
    insert(num);
    }
    print();
    printf("enter=");
    int v,l;
    scanf("%d %d",&v,&l);
    send(v,l);
     


    printf("\n\nLinked List after sorting\n");
    print();
    return 0;
}