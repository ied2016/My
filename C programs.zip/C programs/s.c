#include <stdio.h>
int main()
{
int i;
char s[3][6];
for(i=0;i<3;i++)
{
	scanf("%s",s[i]);
}
for(i=0;i<3;i++)
{
	printf("%s\n",s[i]);
}		
}