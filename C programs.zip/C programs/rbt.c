#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct rbtNode

{          int key;

char color;

struct rbtNode *left, *right,*parent;

};         struct rbtNode* root = NULL;

int count=0;
void printLevelOrder(struct rbtNode* root,char c)
{
    int h = height(root);
    int i;
    for (i=1; i<=h; i++)
        printGivenLevel(root, i,c);
}
 
void printGivenLevel(struct rbtNode* root, int level,char c)
{
    if (root == NULL)
        return;
    if (level == 1&&root->color==c)
      {  printf("%d ", root->key);
    count++;
	}
    else if (level > 1)
    {
        printGivenLevel(root->left, level-1,c);
        printGivenLevel(root->right, level-1,c);
    }
}
 

int height(struct rbtNode* node)
{
    if (node==NULL)
        return 0;
    else
    {
        int lheight = height(node->left);
        int rheight = height(node->right);
 
        if (lheight > rheight)
            return(lheight+1);
        else return(rheight+1);
    }
}

void leftRotate(struct rbtNode *x)
{          struct rbtNode *y;
y = x->right;  x->right = y->left;
if( y->left != NULL)
{          y->left->parent = x;
}
y->parent = x->parent;
if( x->parent == NULL)
{          root = y;
}
else if( (x->parent->left!=NULL) && (x->key == x->parent->left->key))
{          x->parent->left = y;
}
else x->parent->right = y;
y->left = x; x->parent = y; return;
}

void rightRotate(struct rbtNode *y)
{          struct rbtNode *x;
x = y->left; y->left = x->right;
if ( x->right != NULL)
{          x->right->parent = y;
}
x->parent = y->parent;
if( y->parent == NULL)
{          root = x;
}
else if((y->parent->left!=NULL)&& (y->key == y->parent->left->key))
{          y->parent->left = x;
}
else
y->parent->right = x;
x->right = y; y->parent = x;
return;
}

void color_insert(struct rbtNode *z)
{          
	
struct rbtNode *y=NULL;
while ((z->parent != NULL) && (z->parent->color == 'r'))
{
if ( (z->parent->parent->left != NULL) && (z->parent->key == z->parent->parent->left->key))
{   
if(z->parent->parent->right!=NULL)
y = z->parent->parent->right;
if ((y!=NULL) && (y->color == 'r'))
{          z->parent->color = 'b';
y->color = 'b';
z->parent->parent->color = 'r';
if(z->parent->parent!=NULL)
z = z->parent->parent;
}
else
{
if ((z->parent->right != NULL) && (z->key == z->parent->right->key))
{          z = z->parent;
leftRotate(z);
}
z->parent->color = 'b';
z->parent->parent->color = 'r';
rightRotate(z->parent->parent);
}
}
else
{
if(z->parent->parent->left!=NULL)
y = z->parent->parent->left;
if ((y!=NULL) && (y->color == 'r'))
{          z->parent->color = 'b';
y->color = 'b';
z->parent->parent->color = 'r';
if(z->parent->parent!=NULL)
z = z->parent->parent;
}
else
{
if ((z->parent->left != NULL) && (z->key == z->parent->left->key))
{          z = z->parent;
rightRotate(z);
}
z->parent->color = 'b';
z->parent->parent->color = 'r';
leftRotate(z->parent->parent);
}
}
}          root->color = 'b';
}

void insert(int val)
{          struct rbtNode *x, *y;
struct rbtNode *z = (struct rbtNode*)malloc(sizeof(struct rbtNode));
z->key = val;
z->left = NULL;
z->right = NULL;
z->color = 'r';
x=root;
if ( root == NULL )
{          root = z;
root->color = 'b';
return;
}
while ( x != NULL)
{          y = x;
if ( z->key < x->key)
{          x = x->left;
}
else x = x->right;
}
z->parent = y;
if ( y == NULL)
{          root = z;
}
else if( z->key < y->key )
{          y->left = z;
}
else y->right = z;
color_insert(z);
return;
}

void postorderTree(struct rbtNode* root,char c)
{struct rbtNode* temp = root;
if (temp != NULL)
{        
printf("%d-%c ",temp->key,temp->color);
postorderTree(temp->left,c);
postorderTree(temp->right,c);
}
}

int main()
{
int choice,val,data,var,fl=0,i,q,t,num,n;
char s[80],c[80],ch;
scanf("%d",&q);
for(i=0;i<q;i++)
{
	count=0;	
	scanf("%s",s);
	if(strcmp(s,"INSERT")==0)
	{	
		scanf("%d",&num);
		insert(num);	
	}
	else if(strcmp(s,"PRINT")==0)
	{				
		scanf("%s",&c);	
		if(strcmp(c,"R")==0)
		{
			ch='r';	
			printLevelOrder(root,ch);
			if(count!=0)
				printf("\n");
		}
		if(strcmp(c,"B")==0)
		{
			ch='b';	
			printLevelOrder(root,ch);
			if(count!=0)
			printf("\n");
		}	
	}
}
return 0;
}