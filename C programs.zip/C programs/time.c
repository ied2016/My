#include <stdio.h>
#include <time.h>
//void timeNdate();
void main()
{
time_t rawtime; // Setup variable
time(&rawtime); // Get time
printf("%d\n", rawtime);

}