#include<stdio.h>
int main()
{
int itc=0,ii=0,ij=0,ik=0,ix=0,imin[5]={0},iminimum=0;
int icity[5]={0},iroad[5]={0},ishrine[5]={0};
int icity1[5][10],icity2[5][10],idist[5][10];
scanf("%d",&itc);
for(ii=0;ii<itc;ii++)
{
	scanf("%d%d%d",&icity[ii],&iroad[ii],&ishrine[ii]);
	for(ij=1;ij<icity[ii];ij++)
	{
		for(ik=ij+1;ik<=icity[ii];ik++)
		{
			scanf("%d%d%d",&icity1[ii][ij],&icity2[ii][ik],&idist[ij][ik]);
			idist[ik][ij]=idist[ij][ik];
		}
	}
}
for(ii=0;ii<itc;ii++)
{
	for(ij=1;ij<ishrine[ii];ij++)
	{
		ix=0;
		for(ik=ij+1;ik<=ishrine[ii];ik++)
		{
			imin[ix]=imin[ix]+idist[ij][ik];
			ix=ix+1;
		}
		imin[ix]=imin[ix]+idist[ij][--ik];
	}
}
iminimum=imin[0];
for(ii=0;ii<itc;ii++)
{
	for(ix=1;ix<ishrine[ii]-1;ix++)
	{
		if(iminimum>imin[ix])
		{
			iminimum=imin[ix];
		}
	}
}
printf("%d",iminimum);
return 0;
}