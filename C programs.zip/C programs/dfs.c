#include <stdio.h>
#include <stdlib.h>
struct node{
	int key;
	struct node *next,*head;
};

struct graph
{
	int v;
	struct node* array;
};

struct node* createnode(int x)
{
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->key=x;
	temp->next=NULL;
	return temp;
}

struct graph* creategraph(int v)
{
	struct graph* g=(struct graph*)malloc(sizeof(struct graph));
	g->v=v;
	g->array=(struct node*)malloc((v+1)*sizeof(struct node));
	int i;
	for(i=1;i<=v;i++)
		g->array[i].head=NULL;
	return g;
}

void addedge(struct graph* g,int a1,int a2)
{
	struct node* temp=createnode(a2);
	temp->next=g->array[a1].head;
	g->array[a1].head=temp;
	temp=createnode(a1);
	temp->next=g->array[a2].head;
	g->array[a2].head=temp;
}

void print(struct graph* g)
{
	int i;
	for(i=1;i<=g->v;i++)
	{
		struct node* temp=g->array[i].head;
		printf("\n list of vertex %d\n",i);
		while(temp)
		{
			printf("->%d",temp->key);
			temp=temp->next;
		}
		printf("\n");
	}
}

int dfs(int u,int v,struct graph* g)
{
	int n;
	visited[u]=1;
	//count++;
	struct node* temp;
	for(temp=g->array[u].head;temp!=NULL;temp=temp->next)
	{
		if(!visited[temp->key])
		{
			count++;
			//printf("\ncount=%d 		temp->key=%d",count,temp->key);
			dfs(temp->key,v,g);
		}
	}
	if(max<count)
	{
		//printf("\n--count=%d",count);
		max=count;
	}
}


int main()
{
	int v,e,i,a,n;
	scanf("%d %d",&v,&e);
	struct graph* g=creategraph(v);
	for(i=0;i<e;i++)
	{
		int a1,a2;
		scanf("%d %d",&a1,&a2);
		addedge(g,a1,a2);
	}
		for(i=1;i<=v;i++)
	{
		visited[i]=0;
	}
	for(s=1;s<=v;s++)
	{	count=1;
		max=-1;
		if(!visited[s])
	{
		dfs(s,v,g);
		arr[++top]=max;
	}}
	printf("%d\n",top);
	for(i=top;i>=1;i--)
	{
		printf("%d\n",arr[i]);
	}
	return 0;
}