#include <stdio.h>
#include <stdlib.h>
struct dl{
int data;
struct dl *next,*prev;
}*start;
//struct dl* head=NULL;
void insert(int x,struct dl** head )
{
	struct dl *temp=(struct dl*)malloc(sizeof(struct dl));
	if(*head==NULL)
	{
		temp->data=x;
		temp->prev=NULL;
		*head=temp;
		start=temp;
		return;
	}
	temp->data=x;
	temp->prev=*head;
	temp->prev->next=temp;
	temp->next=NULL;
	*head=temp;
}

void delete(int key,struct dl** head1)
{
	struct dl *temp=(struct dl*)malloc(sizeof(struct dl));
	temp=start;
	while(temp!=NULL)
	{
		if(temp->data==key)
		{
		if(temp->prev==NULL)
		{
			temp->next->prev=NULL;
			start=temp->next;
			free(temp);
			return;
		}
		else if(temp->next==NULL)
		{
			temp->prev->next=NULL;
			head1=temp->prev;
			free(temp);
			return;
		}
		else
		{
		temp->prev->next=temp->next;
		temp->next->prev=temp->prev;
		free(temp);
		return;
		}
		}
		temp=temp->next;
	}
}


void display1()
{
	struct dl *temp=(struct dl*)malloc(sizeof(struct dl));
	temp=start;
	while(temp!=NULL)
	{
		printf(" %d ",temp->data);
		temp=temp->next;
	}
}

// void display2()
// {
// 	struct dl *temp=(struct dl*)malloc(sizeof(struct dl));
// 	temp=head;
// 	while(temp!=NULL)
// 	{
// 		printf(" %d ",temp->data);
// 		temp=temp->prev;
// 	}
// }

int main()
{
	struct dl *head=NULL;
	int i,n,x;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&x);
		insert(x,&head);
	}
	display1();
	printf("\n");
	//display2();
	printf("enter element to delete : ");
	scanf("%d",&x);
	delete(x,&head);
	display1();
	return 0;
}
// struct node
// {
//     int data;
//     struct node* next;
// };
 
// /* function prototypes */
// struct node* SortedMerge(struct node* a, struct node* b);
// void FrontBackSplit(struct node* source,
//           struct node** frontRef, struct node** backRef);
 
// /* sorts the linked list by changing next pointers (not data) */
// void MergeSort(struct node** headRef)
// {
//   struct node* head = *headRef;
//   struct node* a;
//   struct node* b;
 
//   /* Base case -- length 0 or 1 */
//   if ((head == NULL) || (head->next == NULL))
//   {
//     return;
//   }
 
//   /* Split head into 'a' and 'b' sublists */
//   FrontBackSplit(head, &a, &b); 
 
//   /* Recursively sort the sublists */
//   MergeSort(&a);
//   MergeSort(&b);
 
//   /* answer = merge the two sorted lists together */
//   *headRef = SortedMerge(a, b);
// }
 
// /* See http://geeksforgeeks.org/?p=3622 for details of this 
//    function */
// struct node* SortedMerge(struct node* a, struct node* b)
// {
//   struct node* result = NULL;
 
//   /* Base cases */
//   if (a == NULL)
//      return(b);
//   else if (b==NULL)
//      return(a);
 
//   /* Pick either a or b, and recur */
//   if (a->data <= b->data)
//   {
//      result = a;
//      result->next = SortedMerge(a->next, b);
//   }
//   else
//   {
//      result = b;
//      result->next = SortedMerge(a, b->next);
//   }
//   return(result);
// }
 
// /* UTILITY FUNCTIONS */
// /* Split the nodes of the given list into front and back halves,
//      and return the two lists using the reference parameters.
//      If the length is odd, the extra node should go in the front list.
//      Uses the fast/slow pointer strategy.  */
// void FrontBackSplit(struct node* source,
//           struct node** frontRef, struct node** backRef)
// {
//   struct node* fast;
//   struct node* slow;
//   if (source==NULL || source->next==NULL)
//   {
//     /* length < 2 cases */
//     *frontRef = source;
//     *backRef = NULL;
//   }
//   else
//   {
//     slow = source;
//     fast = source->next;
 
//     /* Advance 'fast' two nodes, and advance 'slow' one node */
//     while (fast != NULL)
//     {
//       fast = fast->next;
//       if (fast != NULL)
//       {
//         slow = slow->next;
//         fast = fast->next;
//       }
//     }
 
//     /* 'slow' is before the midpoint in the list, so split it in two
//       at that point. */
//     *frontRef = source;
//     *backRef = slow->next;
//     slow->next = NULL;
//   }
// }
 
// /* Function to print nodes in a given linked list */
// void printList(struct node *node)
// {
//   while(node!=NULL)
//   {
//    printf("%d ", node->data);
//    node = node->next;
//   }
// }
 
// /* Function to insert a node at the beginging of the linked list */
// void push(struct node** head_ref, int new_data)
// {
//   /* allocate node */
//   struct node* new_node =
//             (struct node*) malloc(sizeof(struct node));
  
//   /* put in the data  */
//   new_node->data  = new_data;
  
//   /* link the old list off the new node */
//   new_node->next = (*head_ref);    
  
//   /* move the head to point to the new node */
//   (*head_ref)    = new_node;
// } 
  
// /* Drier program to test above functions*/
// int main()
// {
//   /* Start with the empty list */
//   struct node* res = NULL;
//   struct node* a = NULL;
  
//   /* Let us create a unsorted linked lists to test the functions
//    Created lists shall be a: 2->3->20->5->10->15 */
//   push(&a, 15);
//   push(&a, 10);
//   push(&a, 5); 
//   push(&a, 20);
//   push(&a, 3);
//   push(&a, 2); 
  
//   /* Sort the above created Linked List */
//   MergeSort(&a);
  
//   printf("\n Sorted Linked List is: \n");
//   printList(a);           
  
//   getchar();
//   return 0;
// }


//bubble sort in ll
 
// /* structure for a node */
// struct node
// {
//     int data;
//     struct node *next;
// };
 
// /* Function to insert a node at the begining of a linked lsit */
// void insertAtTheBegin(struct node **start_ref, int data);
 
// /* Function to bubble sort the given linked lsit */
// void bubbleSort(struct node *start);
 
// /* Function to swap data of two nodes a and b*/
// void swap(struct node *a, struct node *b);
 
// /* Function to print nodes in a given linked list */
// void printList(struct node *start);
 
// int main()
// {
//     int arr[] = {12, 56, 2, 11, 1, 90};
//     int list_size, i;
 
//     /* start with empty linked list */
//     struct node *start = NULL;
 
//     /* Create linked list from the array arr[].
//       Created linked list will be 1->11->2->56->12 */
//     for (i = 0; i< 6; i++)
//         insertAtTheBegin(&start, arr[i]);
 
//     /* print list before sorting */
//     printf("\n Linked list before sorting ");
//     printList(start);
 
//     /* sort the linked list */
//     bubbleSort(start);
 
//     /* print list after sorting */
//     printf("\n Linked list after sorting ");
//     printList(start);
 
//     getchar();
//     return 0;
// }
 
 
// /* Function to insert a node at the begining of a linked lsit */
// void insertAtTheBegin(struct node **start_ref, int data)
// {
//     struct node *ptr1 = (struct node*)malloc(sizeof(struct node));
//     ptr1->data = data;
//     ptr1->next = *start_ref;
//     *start_ref = ptr1;
// }
 
// /* Function to print nodes in a given linked list */
// void printList(struct node *start)
// {
//     struct node *temp = start;
//     printf("\n");
//     while (temp!=NULL)
//     {
//         printf("%d ", temp->data);
//         temp = temp->next;
//     }
// }
 
// /* Bubble sort the given linked lsit */
// void bubbleSort(struct node *start)
// {
//     int swapped, i;
//     struct node *ptr1;
//     struct node *lptr = NULL;
 
//     /* Checking for empty list */
//     if (ptr1 == NULL)
//         return;
 
//     do
//     {
//         swapped = 0;
//         ptr1 = start;
 
//         while (ptr1->next != lptr)
//         {
//             if (ptr1->data > ptr1->next->data)
//             { 
//                 swap(ptr1, ptr1->next);
//                 swapped = 1;
//             }
//             ptr1 = ptr1->next;
//         }
//         lptr = ptr1;
//     }
//     while (swapped);
// }
 
// /* function to swap data of two nodes a and b*/
// void swap(struct node *a, struct node *b)
// {
//     int temp = a->data;
//     a->data = b->data;
//     b->data = temp;
// }

//Bubble sort in doubly linked list
// void sort(int count)
// {
//     struct data *tmp,*current,*nextone;
//     int i,j;
//     for(i=0;i<count;i++)
//     {
//         current = first;
//         for(j=0;j<count-1-i;j++ )
//         {
//             if(current->number > current->next->number)
//             {
//                 nextone = current->next;
//                 current->next = nextone->next;
//                 nextone->next = current;
//                 if(current == first)
//                 {
//                     first = nextone;
//                     current = nextone;
//                 }
//                 else
//                 {
//                     current = nextone;
//                     tmp->next = nextone;
//                 }
//             }
//             tmp = current;
//             current = current->next;
//         }
//     }
// }

//Merge sort in douby linked list
// #include<stdio.h>
// #include<stdlib.h>
// struct node
// {
//     int data;
//     struct node *next, *prev;
// };
 
// struct node *split(struct node *head);
 
// // Function to merge two linked lists
// struct node *merge(struct node *first, struct node *second)
// {
//     // If first linked list is empty
//     if (!first)
//         return second;
 
//     // If second linked list is empty
//     if (!second)
//         return first;
 
//     // Pick the smaller value
//     if (first->data < second->data)
//     {
//         first->next = merge(first->next,second);
//         first->next->prev = first;
//         first->prev = NULL;
//         return first;
//     }
//     else
//     {
//         second->next = merge(first,second->next);
//         second->next->prev = second;
//         second->prev = NULL;
//         return second;
//     }
// }
 
// // Function to do merge sort
// struct node *mergeSort(struct node *head)
// {
//     if (!head || !head->next)
//         return head;
//     struct node *second = split(head);
 
//     // Recur for left and right halves
//     head = mergeSort(head);
//     second = mergeSort(second);
 
//     // Merge the two sorted halves
//     return merge(head,second);
// }
 
// // A utility function to insert a new node at the
// // beginning of doubly linked list
// void insert(struct node **head, int data)
// {
//     struct node *temp =
//         (struct node *)malloc(sizeof(struct node));
//     temp->data = data;
//     temp->next = temp->prev = NULL;
//     if (!(*head))
//         (*head) = temp;
//     else
//     {
//         temp->next = *head;
//         (*head)->prev = temp;
//         (*head) = temp;
//     }
// }
 
// // A utility function to print a doubly linked list in
// // both forward and backward directions
// void print(struct node *head)
// {
//     struct node *temp = head;
//     printf("Forward Traversal using next poitner\n");
//     while (head)
//     {
//         printf("%d ",head->data);
//         temp = head;
//         head = head->next;
//     }
//     printf("\nBackword Traversal using prev pointer\n");
//     while (temp)
//     {
//         printf("%d ", temp->data);
//         temp = temp->prev;
//     }
// }
 
// // Utility function to swap two integers
// void swap(int *A, int *B)
// {
//     int temp = *A;
//     *A = *B;
//     *B = temp;
// }
 
// // Split a doubly linked list (DLL) into 2 DLLs of
// // half sizes
// struct node *split(struct node *head)
// {
//     struct node *fast = head,*slow = head;
//     while (fast->next && fast->next->next)
//     {
//         fast = fast->next->next;
//         slow = slow->next;
//     }
//     struct node *temp = slow->next;
//     slow->next = NULL;
//     return temp;
// }
 
// // Driver program
// int main(void)
// {
//     struct node *head = NULL;
//     insert(&head,5);
//     insert(&head,20);
//     insert(&head,4);
//     insert(&head,3);
//     insert(&head,30);
//     insert(&head,10);
//     head = mergeSort(head);
//     printf("\n\nLinked List after sorting\n");
//     print(head);
//     return 0;
// }

/*
 * C Program to Implement a Stack using Linked List
 */

// #include <stdio.h>
// #include <stdlib.h>
 
// struct node
// {
//     int info;
//     struct node *ptr;
// }*top,*top1,*temp;
 
// int topelement();
// void push(int data);
// void pop();
// void empty();
// void display();
// void destroy();
// void stack_count();
// void create();
 
// int count = 0;
 
// void main()
// {
//     int no, ch, e;
 
//     printf("\n 1 - Push");
//     printf("\n 2 - Pop");
//     printf("\n 3 - Top");
//     printf("\n 4 - Empty");
//     printf("\n 5 - Exit");
//     printf("\n 6 - Dipslay");
//     printf("\n 7 - Stack Count");
//     printf("\n 8 - Destroy stack");
 
//     create();
 
//     while (1)
//     {
//         printf("\n Enter choice : ");
//         scanf("%d", &ch);
 
//         switch (ch)
//         {
//         case 1:
//             printf("Enter data : ");
//             scanf("%d", &no);
//             push(no);
//             break;
//         case 2:
//             pop();
//             break;
//         case 3:
//             if (top == NULL)
//                 printf("No elements in stack");
//             else
//             {
//                 e = topelement();
//                 printf("\n Top element : %d", e);
//             }
//             break;
//         case 4:
//             empty();
//             break;
//         case 5:
//             exit(0);
//         case 6:
//             display();
//             break;
//         case 7:
//             stack_count();
//             break;
//         case 8:
//             destroy();
//             break;
//         default :
//             printf(" Wrong choice, Please enter correct choice  ");
//             break;
//         }
//     }
// }
 
// /* Create empty stack */
// void create()
// {
//     top = NULL;
// }
 
//  Count stack elements 
// void stack_count()
// {
//     printf("\n No. of elements in stack : %d", count);
// }
 
// /* Push data into stack */
// void push(int data)
// {
//     if (top == NULL)
//     {
//         top =(struct node *)malloc(1*sizeof(struct node));
//         top->ptr = NULL;
//         top->info = data;
//     }
//     else
//     {
//         temp =(struct node *)malloc(1*sizeof(struct node));
//         temp->ptr = top;
//         temp->info = data;
//         top = temp;
//     }
//     count++;
// }
 
// /* Display stack elements */
// void display()
// {
//     top1 = top;
 
//     if (top1 == NULL)
//     {
//         printf("Stack is empty");
//         return;
//     }
 
//     while (top1 != NULL)
//     {
//         printf("%d ", top1->info);
//         top1 = top1->ptr;
//     }
//  }
 
// /* Pop Operation on stack */
// void pop()
// {
//     top1 = top;
 
//     if (top1 == NULL)
//     {
//         printf("\n Error : Trying to pop from empty stack");
//         return;
//     }
//     else
//         top1 = top1->ptr;
//     printf("\n Popped value : %d", top->info);
//     free(top);
//     top = top1;
//     count--;
// }
 
// /* Return top element */
// int topelement()
// {
//     return(top->info);
// }
 
// /* Check if stack is empty or not */
// void empty()
// {
//     if (top == NULL)
//         printf("\n Stack is empty");
//     else
//         printf("\n Stack is not empty with %d elements", count);
// }
 
// /* Destroy entire stack */
// void destroy()
// {
//     top1 = top;
 
//     while (top1 != NULL)
//     {
//         top1 = top->ptr;
//         free(top);
//         top = top1;
//         top1 = top1->ptr;
//     }
//     free(top1);
//     top = NULL;
 
//     printf("\n All stack elements destroyed");
//     count = 0;
// }

 //push pop operation on linked list
//  #include <stdio.h>
// #include <stdlib.h>

// struct Node
// {
//     int Data;
//     struct Node *next;
// }*top;

 /*
 * C Program to Implement Queue Data Structure using Linked List
 */
// #include <stdio.h>
// #include <stdlib.h>
 
// struct node
// {
//     int info;
//     struct node *ptr;
// }*front,*rear,*temp,*front1;
 
// int frontelement();
// void enq(int data);
// void deq();
// void empty();
// void display();
// void create();
// void queuesize();
 
// int count = 0;
 
// void main()
// {
//     int no, ch, e;
 
//     printf("\n 1 - Enque");
//     printf("\n 2 - Deque");
//     printf("\n 3 - Front element");
//     printf("\n 4 - Empty");
//     printf("\n 5 - Exit");
//     printf("\n 6 - Display");
//     printf("\n 7 - Queue size");
//     create();
//     while (1)
//     {
//         printf("\n Enter choice : ");
//         scanf("%d", &ch);
//         switch (ch)
//         {
//         case 1:
//             printf("Enter data : ");
//             scanf("%d", &no);
//             enq(no);
//             break;
//         case 2:
//             deq();
//             break;
//         case 3:
//             e = frontelement();
//             if (e != 0)
//                 printf("Front element : %d", e);
//             else
//                 printf("\n No front element in Queue as queue is empty");
//             break;
//         case 4:
//             empty();
//             break;
//         case 5:
//             exit(0);
//         case 6:
//             display();
//             break;
//         case 7:
//             queuesize();
//             break;
//         default:
//             printf("Wrong choice, Please enter correct choice  ");
//             break;
//         }
//     }
// }
 
// /* Create an empty queue */
// void create()
// {
//     front = rear = NULL;
// }
 
// /* Returns queue size */
// void queuesize()
// {
//     printf("\n Queue size : %d", count);
// }
 
// /* Enqueing the queue */
// void enq(int data)
// {
//     if (rear == NULL)
//     {
//         rear = (struct node *)malloc(1*sizeof(struct node));
//         rear->ptr = NULL;
//         rear->info = data;
//         front = rear;
//     }
//     else
//     {
//         temp=(struct node *)malloc(1*sizeof(struct node));
//         rear->ptr = temp;
//         temp->info = data;
//         temp->ptr = NULL;
 
//         rear = temp;
//     }
//     count++;
// }
 
// /* Displaying the queue elements */
// void display()
// {
//     front1 = front;
 
//     if ((front1 == NULL) && (rear == NULL))
//     {
//         printf("Queue is empty");
//         return;
//     }
//     while (front1 != rear)
//     {
//         printf("%d ", front1->info);
//         front1 = front1->ptr;
//     }
//     if (front1 == rear)
//         printf("%d", front1->info);
// }
 
// /* Dequeing the queue */
// void deq()
// {
//     front1 = front;
 
//     if (front1 == NULL)
//     {
//         printf("\n Error: Trying to display elements from empty queue");
//         return;
//     }
//     else
//         if (front1->ptr != NULL)
//         {
//             front1 = front1->ptr;
//             printf("\n Dequed value : %d", front->info);
//             free(front);
//             front = front1;
//         }
//         else
//         {
//             printf("\n Dequed value : %d", front->info);
//             free(front);
//             front = NULL;
//             rear = NULL;
//         }
//         count--;
// }
 
// /* Returns the front element of queue */
// int frontelement()
// {
//     if ((front != NULL) && (rear != NULL))
//         return(front->info);
//     else
//         return 0;
// }
 
// /* Display if queue is empty or not */
// void empty()
// {
//      if ((front == NULL) && (rear == NULL))
//         printf("\n Queue empty");
//     else
//        printf("Queue not empty");
// }


// void popStack()
// {
//     struct Node *temp, *var=top;
//     if(var==top)
//     {
//         top = top->next;
//         free(var);
//     }
//     else
//     printf("\nStack Empty");
// }

// void push(int value)
// {
//     struct Node *temp;
//     temp=(struct Node *)malloc(sizeof(struct Node));
//     temp->Data=value;
//     if (top == NULL)
//     {
//          top=temp;
//          top->next=NULL;
//     }
//     else
//     {
//         temp->next=top;
//         top=temp;
//     }
// }

// void display()
// {
//      struct Node *var=top;
//      if(var!=NULL)
//      { 
//           printf("\nElements are as:\n");
//           while(var!=NULL)
//           {
//                printf("\t%d\n",var->Data);
//                var=var->next;
//           } 
//      printf("\n");
//      }
//      else
//      printf("\nStack is Empty");
// }

// int main(int argc, char *argv[])
// {
//      int i=0;
//      top=NULL;
//      printf(" \n1. Push to stack");
//      printf(" \n2. Pop from Stack");
//      printf(" \n3. Display data of Stack");
//      printf(" \n4. Exit\n");
//      while(1)
//      {
//           printf(" \nChoose Option: ");
//           scanf("%d",&i);
//           switch(i)
//           {
//                case 1:
//                {
//                int value;
//                printf("\nEnter a valueber to push into Stack: ");
//                scanf("%d",&value);
//                push(value);
//                display();
//                break;
//                }
//                case 2:
//                {
//                popStack();
//                display();
//                break;
//                }
//                case 3:
//                {
//                display();
//                break;
//                }
//                case 4:
//                {
//                struct Node *temp;
//                while(top!=NULL)
//                {
//                     temp = top->next;
//                     free(top);
//                     top=temp;
//                }
//                exit(0);
//                } 
//                default:
//                {
//                printf("\nwrong choice for operation");
//                }
//          }
//     }
// }

 // A C program to demonstrate linked list based implementation of queue
// #include <stdlib.h>
// #include <stdio.h>
 
// // A linked list (LL) node to store a queue entry
// struct QNode
// {
//     int key;
//     struct QNode *next;
// };
 
// // The queue, front stores the front node of LL and rear stores ths
// // last node of LL
// struct Queue
// {
//     struct QNode *front, *rear;
// };
 
// // A utility function to create a new linked list node.
// struct QNode* newNode(int k)
// {
//     struct QNode *temp = (struct QNode*)malloc(sizeof(struct QNode));
//     temp->key = k;
//     temp->next = NULL;
//     return temp; 
// }
 
// // A utility function to create an empty queue
// struct Queue *createQueue()
// {
//     struct Queue *q = (struct Queue*)malloc(sizeof(struct Queue));
//     q->front = q->rear = NULL;
//     return q;
// }
 
// // The function to add a key k to q
// void enQueue(struct Queue *q, int k)
// {
//     // Create a new LL node
//     struct QNode *temp = newNode(k);
 
//     // If queue is empty, then new node is front and rear both
//     if (q->rear == NULL)
//     {
//        q->front = q->rear = temp;
//        return;
//     }
 
//     // Add the new node at the end of queue and change rear
//     q->rear->next = temp;
//     q->rear = temp;
// }
 
// // Function to remove a key from given queue q
// struct QNode *deQueue(struct Queue *q)
// {
//     // If queue is empty, return NULL.
//     if (q->front == NULL)
//        return NULL;
 
//     // Store previous front and move front one node ahead
//     struct QNode *temp = q->front;
//     q->front = q->front->next;
 
//     // If front becomes NULL, then change rear also as NULL
//     if (q->front == NULL)
//        q->rear = NULL;
//     return temp;
// }
 
// // Driver Program to test anove functions
// int main()
// {
//     struct Queue *q = createQueue();
//     enQueue(q, 10);
//     enQueue(q, 20);
//     deQueue(q);
//     deQueue(q);
//     enQueue(q, 30);
//     enQueue(q, 40);
//     enQueue(q, 50);
//     struct QNode *n = deQueue(q);
//     if (n != NULL)
//       printf("Dequeued item is %d", n->key);
//     return 0;
// }

 /* Program to reverse a doubly linked list */
// #include <stdio.h>
// #include <stdlib.h>
 
// /* a node of the doubly linked list */
// struct node
// {
//   int data;
//   struct node *next;
//   struct node *prev;    
// };
 
// /* Function to reverse a Doubly Linked List */
// void reverse(struct node **head_ref)
// {
//      struct node *temp = NULL;  
//      struct node *current = *head_ref;
      
//      /* swap next and prev for all nodes of 
//        doubly linked list */
//      while (current !=  NULL)
//      {
//        temp = current->prev;
//        current->prev = current->next;
//        current->next = temp;              
//        current = current->prev;
//      }      
      
//      /* Before changing head, check for the cases like empty 
//         list and list with only one node */
//      if(temp != NULL )
//         *head_ref = temp->prev;
// }     
 
 
 
// /* UTILITY FUNCTIONS */
// /* Function to insert a node at the beginging of the Doubly Linked List */
// void push(struct node** head_ref, int new_data)
// {
//     /* allocate node */
//     struct node* new_node =
//             (struct node*) malloc(sizeof(struct node));
  
//     /* put in the data  */
//     new_node->data  = new_data;
     
//      since we are adding at the begining, 
//       prev is always NULL 
//     new_node->prev = NULL;
  
//     /* link the old list off the new node */
//     new_node->next = (*head_ref);    
 
//     /* change prev of head node to new node */
//     if((*head_ref) !=  NULL)
//       (*head_ref)->prev = new_node ;    
  
//     /* move the head to point to the new node */
//     (*head_ref)    = new_node;
// }
 
// /* Function to print nodes in a given doubly linked list 
//    This function is same as printList() of singly linked lsit */
// void printList(struct node *node)
// {
//   while(node!=NULL)
//   {
//    printf("%d ", node->data);
//    node = node->next;
//   }
// } 
 
// /* Drier program to test above functions*/
// int main()
// {
//   /* Start with the empty list */
//   struct node* head = NULL;
  
//   /* Let us create a sorted linked list to test the functions
//    Created linked list will be 10->8->4->2 */
//   push(&head, 2);
//   push(&head, 4);
//   push(&head, 8);
//   push(&head, 10);
  
//   printf("\n Original Linked list ");
//   printList(head);
  
//   /* Reverse doubly linked list */
//   reverse(&head);
  
//   printf("\n Reversed Linked list ");
//   printList(head);           
  
//   getchar();
// }

 /*
 * C Program to Reverse a Linked List 
 */
// #include <stdio.h>
// #include <stdlib.h>
 
// struct node
// {
//     int num;
//     struct node *next;
// };
 
// void create(struct node **);
// void reverse(struct node **);
// void release(struct node **);
// void display(struct node *);
 
// int main()
// {
//     struct node *p = NULL;
//     int n;
 
//     printf("Enter data into the list\n");
//     create(&p);
//     printf("Displaying the nodes in the list:\n");
//     display(p);
//     printf("Reversing the list...\n");
//     reverse(&p);
//     printf("Displaying the reversed list:\n");
//     display(p);
//     release(&p);
 
//     return 0;
// }
 
// void reverse(struct node **head)
// {
//     struct node *p, *q, *r;
 
//     p = q = r = *head;
//     p = p->next->next;
//     q = q->next;
//     r->next = NULL;
//     q->next = r;
 
//     while (p != NULL)
//     {
//         r = q;
//         q = p;
//         p = p->next;
//         q->next = r;
//     }
//     *head = q;
// }
 
// void create(struct node **head)
// {
//     int c, ch;
//     struct node *temp, *rear;
 
//     do
//     {
//         printf("Enter number: ");
//         scanf("%d", &c);
//         temp = (struct node *)malloc(sizeof(struct node));
//         temp->num = c;
//         temp->next = NULL;
//         if (*head == NULL)
//         {
//             *head = temp;
//         }
//         else
//         {
//             rear->next = temp;
//         }
//         rear = temp;
//         printf("Do you wish to continue [1/0]: ");
//         scanf("%d", &ch);
//     } while (ch != 0);
//     printf("\n");
// }
 
// void display(struct node *p)
// {
//     while (p != NULL)
//     {
//         printf("%d\t", p->num);
//         p = p->next;
//     }
//     printf("\n");
// }
 
// void release(struct node **head)
// {
//     struct node *temp = *head;
//     *head = (*head)->next;
//     while ((*head) != NULL)
//     {
//         free(temp);
//         temp = *head;
//         (*head) = (*head)->next;
//     }
// }