#include <stdio.h>
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	int c=a-b;

	if(c%10==9)
	{
		printf("%d",c-1);
	}
	else
		printf("%d",c+1);
	return 0;
}