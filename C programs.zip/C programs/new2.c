#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct bst{
int key;
struct bst *left,*right;	
};

struct bst* insert(struct bst* root,int x)
{
	if(root==NULL)
	{
		//printf("innull");
	struct bst *node=(struct bst*)malloc(sizeof(struct bst));
	node->key=x;
	//printf("%c ",node->key);
	node->left=node->right=NULL;
	return node;
	}
	if(x<=root->key)	
		{//	printf("inl");

			root->left=insert(root->left,x);
	}
	else	
		{
		//printf("inr" );
			root->right=insert(root->right,x);
}
}

void postorder(struct bst* root)
{
	if(root!=NULL)
	{
	postorder(root->left);
	postorder(root->right);
	printf("%d ",root->key);
	}
}

void find(struct bst* root,int p,int s,int x)
{
	if(root==NULL)
		return;
	if(root->key==x)
		{
			if(root->left!=NULL)
			{
			struct bst* tmp=root->left;
			while(tmp->right)
				tmp=tmp->right;
			printf("\np=%d",tmp->key);
			p=tmp->key;
		}
		if(root->right!=NULL)
		{
			struct bst* tmp=root->right;
			while(tmp->left)
				tmp=tmp->left;
			printf("\ns=%d",tmp->key);
			s=tmp->key;
		}
			return;
		}
	if(root->key<x)
	{
		find(root->right,p,s,x);
	}
	else
		find(root->left,p,s,x);

}

int main()
{
	int t,n,j;
	int ch;
	//scanf("%d",&t);
	//for(i=0;i<t;i++)
	//{
	struct bst* root1=NULL;
	//printf("n=");
	scanf("%d",&n);
	//printf("ch=");
	scanf("%d",ch);
	root1=insert(root1,ch);
	for(j=0;j<n-1;j++)
	{
	//printf("\nj=%d ch=",j);
	scanf("%d",ch);
	insert(root1,ch);
	}
	//printf("dsfgh=%s",root1->key);
	postorder(root1);
	int p,s;
	find(root1,p,s,'c');
	printf("%d   %d\n",p,s );
	printf("\n");
	//}
	return 0;
}