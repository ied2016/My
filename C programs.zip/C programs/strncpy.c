#include <stdio.h>
#include <string.h>
int main()
{
	int n,Q,i,l,j,save;
	char s[102][102],s2[102][102],q[102],str[102]="";
	scanf("%s %s",s,s2);
	strncpy(str,&s[3],100);
	printf("str=%s\n",str);
return 0;
}