#include <stdio.h>
#include <string.h> 
int main()
{
	int n,q,x,i,j,maxr=-1,maxc=-1;
	char s[10];
	scanf("%d %d",&n,&q);
	int r[314170]={0},c[324160]={0};
	while(q--)
	{
	scanf("%s",s);
	scanf("%d",&i);
	scanf("%d",&x);
	if(strcmp(s,"RowAdd")==0)
	{
	r[i]+=x;
	if(maxr<r[i])
		maxr=r[i];
	}
	else
	{
	c[i]+=x;
	if(maxc<c[i])
		maxc=c[i];
	}
	}
	printf("%d",maxr+maxc);
	return 0;
}