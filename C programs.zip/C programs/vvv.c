#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct bst{
char key;
struct bst *left,*right;	
};

struct bst* insert(struct bst* root,char x)
{
	if(root==NULL)
	{
	struct bst *node=(struct bst*)malloc(sizeof(struct bst));
	node->key=x;
	printf("%c ",node->key);
	node->left=node->right=NULL;
	return node;
	}
	if(root->key>=x)	root->left=insert(root->left,x);
	else	root->right=insert(root->right,x);
}

void postorder(struct bst* root)
{
	if(root!=NULL)
	{
	postorder(root->left);
	postorder(root->right);
	printf("%c ",root->key);
	}
}

int main()
{
	int t,n,i,j,num;
	int ch;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
	struct bst* root=NULL;
	scanf("%d",&n);
	//printf("%d",n);
	scanf("%c",&ch);
	root=insert(root,ch);
	for(j=0;j<n-1;j++)
	{
	scanf("%c",&ch);
	insert(root,ch);
	}
	printf("%c",root->key);
	postorder(root);
	printf("\n");
	}
	return 0;
}