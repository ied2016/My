#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
   float val;
   char str[20];
   
   //strcpy(str, "98993489");
   int i=98993489;
   val = atof(i);
   printf("String value = %d, Float value = %f\n", i, val);

   strcpy(str, "tutorialspoint.com");
   val = atof(str);
   printf("String value = %s, Float value = %f\n", str, val);

   return(0);
}