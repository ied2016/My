#include<stdio.h>
int main()
{
	int n=0;
	while(1)
	{
	scanf("%d",&n);
	if(n!=42)
		printf("\n%d",n);
	else 
		break;
	}
	return 0;
}