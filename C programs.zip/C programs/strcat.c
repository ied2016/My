#include <stdio.h>
#include <string.h>

int main ()
{
   char src[50], dest[50];

   strcpy(src,  "ddfg.txt");
   strcpy(dest, " ");

   //strcat(dest, src[3]);

   printf("src=%s\n",src+2);
   strcpy(dest,src+4);
   printf("dest=%s\n",dest);
   return(0);
}