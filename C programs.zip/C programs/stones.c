#include <stdio.h>
int main()
{
      int i,l,m,count;
      char j[105],s[105];
      scanf("%d",&i);
      while(i--)
      {
        count=0;
        scanf("%s %s",&j,&s);
        for(l=0;s[l]!='\0';l++)
        {
          for(m=0;j[m]!='\0';m++)
          {
    	if(s[l]==j[m])
    	{
    	  count++;
    	  s[l]='.';
    	}
          }
        }
        printf("%d\n",count);
      }
      return 0;
} 