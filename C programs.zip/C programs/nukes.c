#include <stdio.h>
int main()
{
	int i,j,n,k,rem,top[102]={0};
	long long int a;
	scanf("%lld %d %d",&a,&n,&k);
	while(a--)
	{
		for(i=0;i<k;i++)
		{
			if(top[i]+1>=n+1)
			{	top[i]=0;
				//rem=top[i];
			}
			else
			{
				top[i]+1;
				//break;
			}
		}
	}
	for(i=0;i<k;i++)
		printf("%d ",top[i]);
	return 0;
}