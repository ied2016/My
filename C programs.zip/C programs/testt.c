#include <stdio.h>
void partition(int arr[],int low,int high){

    int mid;

    if(low<high){
         mid=(low+high)/2;
         partition(arr,low,mid);
         partition(arr,mid+1,high);
         mergeSort(arr,low,mid,high);
    }
}

void mergeSort(int arr[],int low,int mid,int high)
{
    int i,m,k,l,temp[1000];
    l=low;
    i=low;
    m=mid+1;
    while((l<=mid)&&(m<=high)){

         if(arr[l]<=arr[m]){
             temp[i]=arr[l];
             l++;
         }
         else{
             temp[i]=arr[m];
             m++;
         }
         i++;
    }

    if(l>mid){
         for(k=m;k<=high;k++){
             temp[i]=arr[k];
             i++;
         }
    }
    else{
         for(k=l;k<=mid;k++){
             temp[i]=arr[k];
             i++;
         }
    }

    for(k=low;k<=high;k++){
         arr[k]=temp[k];
    }
}

int main()
{
	int i,k=0,j=0,n,t,a[1111],odd[1111],even[1111];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		if(a[i]%2==0)
			even[j++]=a[i];
		else
			odd[k++]=a[i];
	}
	int md1,md2;
	md1=j/2;
	md2=k/2;
	mergesort(odd,0,md2,j);
	mergesort(even,0,md1,k);
	printf("\n");
	for(i=0;i<j;i++)
		printf(" %d ",even[i]);
	for(i=k-1;i>=0;i--)
		printf(" %d ",odd[i]);
	printf("\n");
	return 0;
}
