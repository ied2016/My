#include <stdio.h>
#include <stdlib.h>
void is(int size, int arr[]) {
	int i,j,k,shift=0,tmp;
	for(i=1;i<size ;i++)
	{tmp=arr[i];
	j=i-1;
	while(tmp < arr[j])
	{shift++;
		arr[j+1]=arr[j];
		j--;
	}
	arr[j+1]=tmp;
}}


int cmpfunc (const void * a, const void * b)
{
   return ( *(int*)a - *(int*)b );
}

int main()
{int i,j,k,T,m,n,flag=1,*p1,*p2,t,f=0,temp,count=0;
	scanf("%d",&t);
	for(T=0;T<t;T++)
	{	f=0;
		flag=1;
		scanf("%d %d",&m,&n);
		int boys[m],girl[n];
		for(j=0;j<m;j++)
			scanf("%d",&boys[j]);
		for(k=0;k<n;k++)
			scanf("%d",&girl[k]);
		
	is(m,boys);
	is(n,girl);
/*		 for(i=0;i<n;i++)
    {
        for(j=1;j<n;j++)
        {
            if(girl[i]<girl[j])
            {
                temp=girl[i];
                girl[i]=girl[j];
                girl[j]=temp;

        }
        }
    }
    	// qsort(boys, m, sizeof(int), cmpfunc);
    	// qsort(girl, n, sizeof(int), cmpfunc);
 for(i=0;i<m;i++)
    {
        for(j=1;j<m;j++)
        {
            if(boys[i]<boys[j])
            {
                temp=boys[i];
                boys[i]=boys[j];
                boys[j]=temp;

        }
        }
    }*/
            	// qsort(boys, m, sizeof(int), cmpfunc);
    	// qsort(girl, n, sizeof(int), cmpfunc);
    
		p2=&girl[0];

		if(m<=n){
		for(i=0;i<m;i++)
		{
			p1=&boys[i];
			if(*p2>=*p1)
				flag=0;
			else
			{
				p2++;
				count++;

			}
					
		
		}
	}
	else 
		flag=0;

		if(count!=m)
			flag=0;
			if(flag==1)
				printf("YES\n");
			else
				printf("NO\n");
	}
	return 0;
}