#include <stdio.h>
void m(int A[],int p,int q,int r)
{	int n1,n2;
	n1=q-p+1;
	n2=r-q;
	int i,j,k,L[n1+1],R[n2+1];
	for(i=1;i<=n1;i++)
	L[i]=A[p+i-1];
	for(j=1;j<=n2;j++)
	R[j]=A[q+j];
	L[n1+1]=-9999999;
	R[n2+1]=-9999999;
	i=1;
	j=1;
	for(k=p;k<=r;k++)
	{
	if(L[i]>=R[j])
	{
	A[k]=L[i];
	i=i+1;
	}
	else
	{
	A[k]=R[j];
	j=j+1;
	}
	}
}

void v(int A[],int p,int r)
{
	int q;
	if(p<r)
	{
	q=(p+r)/2;
	v(A,p,q);
	v(A,q+1,r);
	m(A,p,q,r);
	}
}

int main()
{
int n,t,i,j,k,a[100];
scanf("%d",&n);
for(i=1;i<=n;i++)
scanf("%d",&a[i]);
v(a,1,n);
for(i=1;i<=n;i++)
printf(" %d ",a[i]);
}