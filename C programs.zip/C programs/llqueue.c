#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct lll
{
	int data;
	struct lll *next;
}*front=NULL,*rear,*save,*savefirstaddr,*stop=NULL,*last;
int f=0;
void enqueue(int x)
{
if(f==0)
{
	struct lll *temp=(struct lll*)malloc(sizeof(struct lll));
	temp->data=x;
	temp->next=front;
	front=temp;
	last=front;
	f=1;
}
else
{
struct lll *temp=(struct lll*)malloc(sizeof(struct lll));
temp->data=x;
temp->next=front;
front=temp;
last=front;
}
}

void dequeue()
{
struct lll *temp=(struct lll*)malloc(sizeof(struct lll));
temp=last;
while(temp->next!=NULL)
{
	temp=temp->next;
}
stop=temp;
free(temp);
}

void display()
{
	struct lll *temp=(struct lll*)malloc(sizeof(struct lll));
	temp=front;
while(temp->next!=stop)
{
	printf(" %d ",temp->data);
	temp=temp->next;
}
printf(" %d ",temp->data);
}

int main()
{
	int t,i,j,n,x,e;
	char s[80];
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
	scanf("%s",s);
	if(strcmp(s,"enqueue")==0)
	{
	scanf("%d",&x);
	enqueue(x);
	}
	else if(strcmp(s,"dequeue")==0)
	dequeue();
	//else
	display();
	}

}