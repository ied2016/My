#include <stdio.h>
#include <conio.h>
using namespace std;
int main()
{
	int x,y,z;
	printf("here\n");
	gotoxy(36,25);
	printf("now here");

}