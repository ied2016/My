#include <stdio.h>
#include <string.h>
int main()
{
	int t,i,bug,rank,m,count=0,a[5002]={0};
	int laddu=0;
	char s[100],national[100];
	scanf("%d",&t);
	while(t--)
	{
	count=0;
	laddu=0;
	scanf("%d %s",&m,&national);
	while(m--)
	{
	scanf("%s",&s);
	// if(strcmp(s,"TOP_CONTRIBUTER")==0)
	// 	laddu+=300;
	// if(strcmp(s,"BUG_FOUND")==0)
	// {
	// 	scanf("%d",&bug);
	// 	laddu+=bug;
	// }
	// if(strcmp(s,"CONTEST_HOSTDED")==0)
	// 	laddu+=50;
	// if(strcmp(s,"CONTEST_WON")==0)
	// {
	// 	scanf("%d",&rank);
	// 	//laddu+=a[rank];
	// 	// if(rank<=20)
	// 	// 	laddu=laddu+320-rank;
	// 	// else
	// 	// 	laddu+=300;
	// }
	}
	if(strcmp(national,"INDIAN")==0)
	{
		while(laddu>=200)
		{
			laddu-=200;
			count++;
		}
	}
	if(strcmp(national,"NON_INDIAN")==0)
	{
		while(laddu>=400)
		{
			laddu-=400;
			count++;
		}
	}
	//a[rank]+=laddu;
	printf("%d\n",0);
	}
}