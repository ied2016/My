#include <stdio.h>
int main()
{
  long long int i,t,n,q,min=999999999,max=-1,num;
  scanf("%lld",&n);
  long long int a[n];
  for(i=0;i<n;i++)
  {
    scanf("%lld",&a[i]);
  }
  quicksort(a,0,n-1);
  for(i=0;i<n;i++)
  {
    printf(" %lld ",a[i]);
  }
return 0;
}

void quicksort(long long int x[],long long int first,long long int last){
    long long int pivot,j,temp,i;

     if(first<last){
         pivot=first;
         i=first;
         j=last;

         while(i<j){
             while(x[i]<=x[pivot]&&i<last)
                 i++;
             while(x[j]>x[pivot])
                 j--;
             if(i<j){
                 temp=x[i];
                  x[i]=x[j];
                  x[j]=temp;
             }
         }

         temp=x[pivot];
         x[pivot]=x[j];
         x[j]=temp;
         quicksort(x,first,j-1);
         quicksort(x,j+1,last);

    }
}