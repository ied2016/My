#include <stdio.h>
#include <stdlib.h>
struct MaxHeap
{
    int size;
    int* array;
};
int n;
void swap(int* a, int* b) { int t = *a; *a = *b;  *b = t; }
void maxHeapify(int a[], int idx)
{
    int largest = idx;         
    int left = 2*idx ;
    int right = 2*idx + 1;
 
  
    if (left < n && a[left] > a[largest])
        largest = left;
    if (right <n && a[right] > a[largest])
        largest = right;
    if (largest != idx)
    {
        swap(&a[largest], &a[idx]);
        maxHeapify(a,largest);
    }
}
 
void createAndBuildHeap(int a[])
{
    int i;
    for (i = (n) / 2; i >= 0; --i)
        maxHeapify(a, i);
}
 
// The main function to sort an array of given size
// void heapSort(int* array, int size)
// {
//     // Build a heap from the input data.
//     struct MaxHeap* maxHeap = createAndBuildHeap(array, size);
 
//     // Repeat following steps while heap size is greater than 1. 
//     // The last element in max heap will be the minimum element
//     while (maxHeap->size > 1)
//     {
//         // The largest item in Heap is stored at the root. Replace
//         // it with the last item of the heap followed by reducing the
//         // size of heap by 1.
//         swap(&maxHeap->array[0], &maxHeap->array[maxHeap->size - 1]);
//         --maxHeap->size;  // Reduce heap size
 
//         // Finally, heapify the root of tree.
//         maxHeapify(maxHeap, 0);
//     }
// }
 
void hs(int a[])
{
    createAndBuildHeap(a);
    int i;
    for(i=n-1;i>=1;i--)
    {
        swap(&a[i],&a[0]);
        n--;
        maxHeapify(a,0);
    }
}



// A utility function to print a given array of given size
void printArray(int* arr, int size)
{
    int i;
    for (i = 0; i < size; ++i)
        printf("%d ", arr[i]);
}
 
int main()
{
    int arr[] = {1,2123,3,42,5};
    int size = sizeof(arr)/sizeof(arr[0]);
    n=size;
    printf("Given array is \n");
    printArray(arr, size);
    //createAndBuildHeap(arr,size);
    //heapSort(arr, size);
    hs(arr);
    printf("\nmax=%d",arr[0]);
    printf("\nSorted array is \n");
    printArray(arr, size);
    return 0;
}