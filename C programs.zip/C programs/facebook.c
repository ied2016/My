#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct facebook
{
long long int friends;
char name[111];	
struct facebook *next,*prev;
}*head1=NULL,*start;

struct linkedin
{
long long int links;
char name[111];
struct linkedin *next,*prev;
}*head2=NULL,*start2;

struct facebook *spli(struct facebook *head)
{
    struct facebook *fast = head,*slow = head;
    while (fast->next && fast->next->next)
    {
        fast = fast->next->next;
        slow = slow->next;
    }
    struct facebook *temp = slow->next;
    slow->next = NULL;
    return temp;
}
// Function to merge two linked lists
struct facebook *mergeo(struct facebook *first, struct facebook *second)
{
    // If first linked list is empty
    if (!first)
        return second;
 
    // If second linked list is empty
    if (!second)
        return first;
 
    // Pick the smaller value
    if (strcmp(first->name,second->name)<=0)
    {
    	    //	printf("up1");
        first->next = mergeo(first->next,second);
        first->next->prev = first;
        first->prev = NULL;
        return first;
    }
    else
    {    //	printf("down1");

        second->next = mergeo(first,second->next);
        second->next->prev = second;
        second->prev = NULL;
        return second;
    }
}
 
struct facebook *mergeSort(struct facebook *head)
{
    if (!head || !head->next)
        return head;
    struct facebook *second=spli(head) ;
 
    // Recur for left and right halves
    head = mergeSort(head);
    second = mergeSort(second);
 
    // Merge the two sorted halves
    return mergeo(head,second);
}

struct linkedin *spli2(struct linkedin *head)
{
    struct linkedin *fast = head,*slow = head;
    while (fast->next && fast->next->next)
    {
        fast = fast->next->next;
        slow = slow->next;
    }
    struct linkedin *temp = slow->next;
    slow->next = NULL;
    return temp;
}
// Function to merge two linked lists
struct linkedin *mergeo2(struct linkedin *first, struct linkedin *second)
{
    // If first linked list is empty
    if (!first)
        return second;
 
    // If second linked list is empty
    if (!second)
        return first;
 
    // Pick the smaller value
    if (strcmp(first->name,second->name)<=0)
    {
    	//printf("up2");
        first->next = mergeo2(first->next,second);
        first->next->prev = first;
        first->prev = NULL;
        return first;
    }
    else
    {    //	printf("down2");

        second->next = mergeo2(first,second->next);
        second->next->prev = second;
        second->prev = NULL;
        return second;
    }
}
 
struct linkedin *mergeSort2(struct linkedin *head)
{
    if (!head || !head->next)
        return head;
    struct linkedin *second=spli2(head) ;
 
    // Recur for left and right halves
    head = mergeSort2(head);
    second = mergeSort2(second);
 
    // Merge the two sorted halves
    return mergeo2(head,second);
}

// 	i=(i==NULL)?start1:i->next;
// 	//swap(&i,&head11);
// 			strcpy(ch,i->name);
// 			strcpy(i->name,head11->name);
// 			strcpy(head11->name,ch);
// 			tmp=i->friends;
// 			i->friends=head11->friends;
// 			head11->friends=tmp;
// 	return i;
// }

// void quicks(struct facebook* start2,struct facebook* head12)
// {
// 	if(head12!=NULL&&start2!=head12&&start2!=head12->next)
// 	{
// 		struct facebook *p=part(start2,head12);
// 		quicks(start2,p->next);
// 		quicks(p->next,head12);
// 	}
// }

void insert(int x)
{
	struct facebook *temp=(struct facebook*)malloc(sizeof(struct facebook));
	if(head1==NULL)
	{
	temp->next=NULL;
	temp->prev=NULL;
	scanf("%s",&temp->name);
	scanf("%lld",&temp->friends);
	head1=temp;
	start=temp;
	return;
	}
	if(x==2)
	{
	temp->prev=head1;
	temp->prev->next=temp;
	scanf("%s",&temp->name);
	scanf("%lld",&temp->friends);
	temp->next=NULL;
	head1=temp;
	return;
	}
	else if(x==1)
	{
	temp->next=start;
	temp->prev=NULL;
	scanf("%s",&temp->name);
	scanf("%lld",&temp->friends);
	start=temp;
	return;
	}
}

void insert2(int x)
{
	struct linkedin *temp=(struct linkedin*)malloc(sizeof(struct linkedin));
	if(head2==NULL)
	{
	temp->next=NULL;
	temp->prev=NULL;
	scanf("%s",&temp->name);
	scanf("%lld",&temp->links);
	head2=temp;
	start2=temp;
	return;
	}
	if(x==2)
	{
	temp->prev=head2;
	temp->prev->next=temp;
	scanf("%s",&temp->name);
	scanf("%lld",&temp->links);
	temp->next=NULL;
	head2=temp;
	return;
	}
	else if(x==1)
	{
	temp->next=start2;
	temp->prev=NULL;
	scanf("%s",&temp->name);
	scanf("%lld",&temp->links);
	start2=temp;
	return;
	}
}

void display()
{
	struct facebook *temp=(struct facebook*)malloc(sizeof(struct facebook));
	temp=start;
	printf("\n");
	while(temp!=NULL)
	{
		printf("\nname=%s 	friends=%lld",temp->name,temp->friends);
		temp=temp->next;
	}
}

void display2()
{
	struct linkedin *temp=(struct linkedin*)malloc(sizeof(struct linkedin));
	temp=start2;	printf("\n");
	while(temp!=NULL)
	{
		printf("\nn=%s 	links=%lld",temp->name,temp->links);
		temp=temp->next;
	}
}

void myfun()
{
	struct linkedin *t2=(struct linkedin*)malloc(sizeof(struct linkedin));
	struct facebook *t1=(struct facebook*)malloc(sizeof(struct facebook));
	t1=start;
	t2=start2;
	while(t1&&t2)
	{
		if(strcmp(t1->name,t2->name)==0)
		{
			//printf("\n = ");
			printf("%s %lld %lld",t1->name,t1->friends,t2->links);
			printf("\n");
			t1=t1->next;
			t2=t2->next;
		}
		else if(strcmp(t1->name,t2->name)<0)
		{	//printf("\n < ");
			t1=t1->next;
		}
		else if(strcmp(t1->name,t2->name)>0)
		{	//printf("\n >");
			t2=t2->next;
		}
	}
}

int main()
{
	int n;
	scanf("%d",&n);
	while(n!=0)
	{
		insert(n);
		scanf("%d",&n);
	}
	//quicks(start,head1);
	//display();
	//printf("\nstart=%s",start->name);
	start=mergeSort(start);
	//display();

	scanf("%d",&n);
	while(n!=0)
	{
		insert2(n);
		scanf("%d",&n);
	}
	//display2();
	start2=mergeSort2(start2);
	//display2();
	myfun();
	//return 0;
}