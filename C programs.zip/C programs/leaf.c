#include <stdio.h>
#include <stdlib.h>
struct bst
{
	int key;
	struct bst *left,*right;
};
int count;
struct bst *insert(struct bst* node,int x)
{
	if(node==NULL)
	{
	struct bst *temp=(struct bst*)malloc(sizeof(struct bst));
		temp->key=x;
		temp->left=temp->right=NULL;
		return temp;
	}

	if(x<=node->key)
		node->left=insert(node->left,x);
	else if(x>node->key)
		node->right=insert(node->right,x);
	return node;
}

void inorder(struct bst* root)
{
	if(root!=NULL)
	{
	inorder(root->left);
	if((root->left==NULL)&&(root->right==NULL))
	{
	count++;
	}
	free(root);
	inorder(root->right);

	}
}

int main()
{
	int t,n,num,i,j;
	
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
		struct bst *root=NULL;
	count=0;
	scanf("%d",&n);
	scanf("%d",&num);
	root=insert(root,num);
	for(j=0;j<n-1;j++)
	{
		scanf("%d",&num);
		insert(root,num);
	}
	inorder(root);
	printf("%d\n",count);
	}
	return 0;
}