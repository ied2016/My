#include<stdio.h>
int main()
{
	char s2[80];
	int t;
	scanf("%d",&t);
	while(t--)
	{
	scanf("%s",s2);
	printf("sdfsd\n");
	}
}