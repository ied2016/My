#include <stdio.h>
#include <stdlib.h>
struct node{
	int key;
	struct node *next,*head;
};

int visited[10000000]={0},s,count=0,f=0,max=-1,top=0,arr[1000000];

void m(int A[],int p,int q,int r)
{	int n1,n2;
	n1=q-p+1;
	n2=r-q;
	int i,j,k,L[n1+1],R[n2+1];
	for(i=1;i<=n1;i++)
	L[i]=A[p+i-1];
	for(j=1;j<=n2;j++)
	R[j]=A[q+j];
	L[n1+1]=9999999;
	R[n2+1]=9999999;
	i=1;
	j=1;
	for(k=p;k<=r;k++)
	{
	if(L[i]<=R[j])
	{
	A[k]=L[i];
	i=i+1;
	}
	else
	{
	A[k]=R[j];
	j=j+1;
	}
	}
}

void vs(int A[],int p,int r)
{
	int q;
	if(p<r)
	{
	q=(p+r)/2;
	vs(A,p,q);
	vs(A,q+1,r);
	m(A,p,q,r);
	}
}

struct graph
{
	int v;
	struct node* array;
};

struct node* createnode(int x)
{
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->key=x;
	temp->next=NULL;
	return temp;
}

struct graph* creategraph(int v)
{
	struct graph* g=(struct graph*)malloc(sizeof(struct graph));
	g->v=v;
	g->array=(struct node*)malloc((v+1)*sizeof(struct node));
	int i;
	for(i=1;i<=v;i++)
		g->array[i].head=NULL;
	return g;
}

void addedge(struct graph* g,int a1,int a2)
{
	struct node* temp=createnode(a2);
	temp->next=g->array[a1].head;
	g->array[a1].head=temp;
	temp=createnode(a1);
	temp->next=g->array[a2].head;
	g->array[a2].head=temp;
}

void print(struct graph* g)
{
	int i;
	for(i=1;i<=g->v;i++)
	{
		struct node* temp=g->array[i].head;
		printf("\n list of vertex %d\n",i);
		while(temp)
		{
			printf("->%d",temp->key);
			temp=temp->next;
		}
		printf("\n");
	}
}

int dfs(int u,int v,struct graph* g)
{
	int n;
	visited[u]=1;
	//count++;
	struct node* temp;
	for(temp=g->array[u].head;temp!=NULL;temp=temp->next)
	{
		if(!visited[temp->key])
		{
			count++;
			//printf("\ncount=%d 		temp->key=%d",count,temp->key);
			dfs(temp->key,v,g);
		}
	}
	if(max<count)
	{
		//printf("\n--count=%d",count);
		max=count;
	}
}


int main()
{
	int v,e,i,a,n;
	scanf("%d %d",&v,&e);
	struct graph* g=creategraph(v);
	for(i=0;i<e;i++)
	{
		int a1,a2;
		scanf("%d %d",&a1,&a2);
		addedge(g,a1,a2);
	}
		for(i=1;i<=v;i++)
	{
		visited[i]=0;
	}
	for(s=1;s<=v;s++)
	{	count=1;
		max=-1;
		if(!visited[s])
	{
		dfs(s,v,g);
		arr[++top]=max;
	}}
	vs(arr,0,top);
	printf("%d\n",top);
	for(i=top;i>=1;i--)
	{
		printf("%d\n",arr[i]);
	}
	return 0;
}