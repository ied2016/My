#include <stdio.h>
#define MAX 10005
int id[MAX], nodes, edges;
struct edge{
	int x,y;
	long long weight;
};
struct edge p[MAX];

void sort(struct edge e[],int size){
	for(int i = 0;i < size-1;++i) {
		int max=i;
		for(int j=i+1;j<size;j++){
			if(e[j].weight<e[max].weight){
				max=j;
			}
		}
		struct edge tmp;
		tmp.x=e[i].x;
		tmp.y=e[i].y;
		tmp.weight=e[i].weight;

		e[i].x=e[max].x;
		e[i].y=e[max].y;
		e[i].weight=e[max].weight;

		e[max].x=tmp.x;
		e[max].y=tmp.y;
		e[max].weight=tmp.weight;
	}
}

void initialize() {
	for(int i = 0;i < MAX;++i)
		id[i] = i;
}

int root(int x) {
	while(id[x] != x)
	{
		id[x] = id[id[x]];
		x = id[x];
	}
	return x;
}

	//scanf("%d %d",&nodes,&edges);

void union1(int x, int y) {
	int xx = root(x);
	int yy = root(y);
	id[xx] = id[yy];
}

long long kruskal(struct edge e[]) {
	int x, y;
	long long cost, maximumCost = 0;
	for(int i = 0;i < edges;++i) {
		// Selecting edges one by one in increasing order from the beginning
		x = e[i].x;
		y = e[i].y;
		cost = e[i].weight;
		// Check if the selected edge is creating a cycle or not
		if(root(x) != root(y)) {
			maximumCost += cost;
			union1(x, y);
		}    
	}
	return maximumCost;
}

int main() {
	long long maximumCost;
	initialize();
	scanf("%d %d",&nodes,&edges);

	for(int i = 0;i < edges;++i) {
		scanf("%d %d %lld",&p[i].x,&p[i].y,&p[i].weight);
	}
	/*
	for(int i = 0;i < edges;++i) {
		printf("%d %d %lld\n",p[i].x,p[i].y,p[i].weight);
	}
	*/
	// Sort the edges in the ascending order
	sort(p,edges);
	/*
	for(int i = 0;i < edges;++i) {
		printf("%d %d %lld\n",p[i].x,p[i].y,p[i].weight);
	}
	*/

	maximumCost = kruskal(p);
	printf("%lld\n",maximumCost);
	return 0;
}