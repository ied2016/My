#include <stdio.h>
#include <stdlib.h>
int cmpfunc (const void * a, const void * b)
{
   return ( *(int*)b - *(int*)a );
}
int main()
{
	int t,n,i,num;
	scanf("%d",&t);
	while(t--)
	{
   int max=-1,mnum,count=0;
	scanf("%d",&n);
	int a[100002]={0};
	for(i=0;i<n;i++)
		{scanf("%d",&num);
         a[num]+=1;
         if(max<a[num])
            {
               max=a[num];
               mnum=num;
            }
      }
   //qsort(a, n, sizeof(int), cmpfunc);
   //for(i=0;i<n;i++)
   //printf(" max=%d  mnum=%d\n",max,mnum);
   for(i=0;i<=100000;i++)
   {
      if(i!=mnum)
      count+=a[i];
   }	
   printf("%d\n",count);
   }
return 0;
}