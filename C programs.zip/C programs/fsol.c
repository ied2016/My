#include <stdio.h>
int main()
{	
    	int maxr=0,maxc=0;		
    	int N,Q;
    	scanf("%d",&N);
    	scanf("%d",&Q);
        int r[314170]={0},c[314170]={0};
    	char str[15];
    	while(Q--)
    	{
    		scanf("%s",str);
    		int i,x;
    		scanf("%d",&i);
    		scanf("%d",&x);
    		if(str[0]=='R')
    		{
    			r[i]+=x;
    			if(r[i]>maxr) 
                    maxr=r[i];
    		}
    		else if(str[0]=='C')
    		{
    			c[i]+=x;
    			if(c[i]>maxc) 
                    maxc=c[i];
    		}
    	}
    	printf("%d",maxr+maxc);
    	return 0;
} 

