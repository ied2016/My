#include <stdio.h>
#include <string.h>
int main()
{
	int n,Q,i,l,j,save,c=0,flag;
	char s[102][102],s2[102][102],q[102],str[102];
	scanf("%d %d",&n,&Q);
	for(i=0;i<n;i++)
	{
	scanf("%s %s",s[i],s2[i]);
	}
	while(Q--)
	{
		char str[102]="";
		flag=0;
		c=0;
		scanf("%s",q);
		for(i=strlen(q)-1;i>=0;i--)
		{
			if(q[i]=='.')
			{	save=i;
				strcpy(str,q+i+1);
				flag=1;
			//	printf("str=%s\n",str);
				break;
			}	
			else
				flag=0;
		}
		for(j=0;j<n;j++)
			{
				if(strcmp(str,s[j])==0)
				{
					printf("%s\n",s2[j]);
					c=1;
				}
			}
			if(c==0||flag==0)
				printf("unknown\n");
	}
return 0;
}