#include <stdio.h>
int main()
{
	long long int t,n,i;
	scanf("%lld",&t);
	while(t--)
	{
		long long int count=0;
		scanf("%lld",&n);
		long long int a[n],b[n];
		for(i=0;i<n;i++)
			scanf("%lld",&a[i]);
		for(i=0;i<n;i++)
			scanf("%lld",&b[i]);
		for(i=0;i<n;i++)
		{
			if(i==0)
				if(a[i]>=b[i])
					{count++;
						//printf("i=%lld\n",i );
					}
			if((i!=0)&&a[i]-a[i-1]>=b[i])
				{count++;//printf("i=%lld \n",i );
		}

		}
		printf("%lld\n",count);
	}
}