#include <stdio.h>
#include <stdlib.h>
struct Node{
int data;
struct Node *next;
};

Node* Insert(Node* head,int val)
{
	struct Node* temp=(struct Node*)malloc(sizeof(struct Node));
	temp->data;
	
}
int main()
{
	int t,n,
	char s[80];
	scanf("%d",&t);
	for(i=0;i<n;i++)
	{
		scanf("%d",&x);
		while(x!=0)
		{
			scanf("%d",&x);
			Insert(x);
		}
		scanf("%d".&s);
		if(strcmp(s,"Insert")==0)
		{
			Insert(x);
		}
		else if(strcmp(s,"Delete")==0)

	}

}