#include <stdio.h>
#include <stdlib.h>

struct s{
	int x,y;
	struct s *next;
}*startA,*startB;

struct s *headA=NULL,*headB=NULL;

void insert(int x,int val1,int val2)
{
	struct s *temp=(struct s*)malloc(sizeof(struct s));
	temp->x=val1;
	temp->y=val2;
	if(x==1)
	{
		if(headA==NULL)
		{
			// temp->prev=NULL;
			temp->next=NULL;
			headA=temp;
			startA=temp;
			return;
		}
		temp->next=NULL;
		startA->next=temp;
		startA=temp;
	}
	else if(x==2)
	{
		if(headA==NULL)
		{
			// temp->prev=NULL;
			temp->next=NULL;
			headA=temp;   
			startA=temp;
			return;
		}
		temp->next=headA;
		headA=temp;
	}
}

void insert2(int x,int val1,int val2)
{
	struct s *temp=(struct s*)malloc(sizeof(struct s));
	temp->x=val1;
	temp->y=val2;
	if(x==1)
	{
		if(headB==NULL)
		{
			// temp->prev=NULL;
			temp->next=NULL;
			headB=temp;
			startB=temp;
			return;
		}
		temp->next=NULL;
		startB->next=temp;
		startB=temp;
	}
	else if(x==2)
	{
		if(headB==NULL)
		{
			// temp->prev=NULL;
			temp->next=NULL;
			headB=temp;   
			startB=temp;
			return;
		}
		temp->next=headB;
		headB=temp;
	}
}

struct s *spli(struct s* headA)
{
    struct s *fast = headA,*slow = headA;
    while (fast->next && fast->next->next)
    {
        fast = fast->next->next;
        slow = slow->next;
    }
    struct s *temp = slow->next;
    slow->next = NULL;
    return temp;
}
// Function to merge two linked lists
struct s *mergeo(struct s *first, struct s *second)
{
    // If first linked list is empty
    if (!first)
        return second;
 
    // If second linked list is empty
    if (!second)
        return first;
 
    // Pick the smaller value
    if (first->x>second->x)
    {
    	    //	printf("up1");
        first->next = mergeo(first->next,second);
        // first->next->prev = first;
        // first->prev = NULL;
        return first;
    }
    else
    {    //	printf("down1");

        second->next = mergeo(first,second->next);
        // second->next->prev = second;
        // second->prev = NULL;
        return second;
    }
}
 
struct s *mergeSort(struct s* headA)
{
    if (!headA || !headA->next)
        return headA;
    struct s *second=spli(headA) ;
 
    // Recur for left and right halves
    headA = mergeSort(headA);
    second = mergeSort(second);
 
    // Merge the two sorted halves
    return mergeo(headA,second);
}

struct s *spli2(struct s* headB)
{
    struct s *fast = headB,*slow = headB;
    while (fast->next && fast->next->next)
    {
        fast = fast->next->next;
        slow = slow->next;
    }
    struct s *temp = slow->next;
    slow->next = NULL;
    return temp;
}
// Function to merge two linked lists
struct s *mergeo2(struct s *first, struct s *second)
{
    // If first linked list is empty
    if (!first)
        return second;
 
    // If second linked list is empty
    if (!second)
        return first;
 
    // Pick the smaller value
    if (first->x>second->x)
    {
    	    //	printf("up1");
        first->next = mergeo(first->next,second);
        // first->next->prev = first;
        // first->prev = NULL;
        return first;
    }
    else
    {    //	printf("down1");

        second->next = mergeo(first,second->next);
        // second->next->prev = second;
        // second->prev = NULL;
        return second;
    }
}
 
struct s *mergeSort2(struct s* headB)
{
    if (!headB || !headB->next)
        return headB;
    struct s *second=spli(headB) ;
 
    // Recur for left and right halves
    headB = mergeSort(headB);
    second = mergeSort(second);
 
    // Merge the two sorted halves
    return mergeo(headB,second);
}

void change()
{
	struct s *temp=(struct s*)malloc(sizeof(struct s));
	struct s *prev,*save;
	temp=headA;
	save=temp;
	prev=NULL;
	while(save!=NULL)
	{
		temp=save;
		//printf("check=%d  %d \n",save->x ,temp->x );
		save=temp->next;
		temp->next=prev;
		prev=temp;
	}
	headA=prev;
}

void change2()
{
	struct s *temp=(struct s*)malloc(sizeof(struct s));
	struct s *prev,*save;
	temp=headB;
	save=temp;
	prev=NULL;
	while(save!=NULL)
	{
		temp=save;
		//printf("check=%d  %d \n",save->x ,temp->x );
		save=temp->next;
		temp->next=prev;
		prev=temp;
	}
	headB=prev;
}

// void check()
// {
// 	struct s *tempA=(struct s*)malloc(sizeof(struct s));
// 	temp=headA;
// 	struct s *tempB=(struct s*)malloc(sizeof(struct s));
// 	temp=headB;
// 	while(tempA!=NULL&&tempB!=NULL)
// 	{
// 		if(tempA->x<tempB->x)
// 		{
// 			prev=tempA;
// 			tempA=tempA->next;
// 		}
// 		else if(tempB->x<tempA->x)
// 		{
// 			prev=tempB;
// 			tempB=tempB->next;
// 		}
// 		else if(tempB->x==tempA->x)
// 		{
// 			if(temp->)
// 		}
// 	}
// }

void display()
{
	struct s *temp=(struct s*)malloc(sizeof(struct s));
	temp=headA;
	while(temp!=NULL)
	{
		printf("x=%d y=%d\n",temp->x,temp->y);
		temp=temp->next;
	}
}

void display2()
{
	struct s *temp=(struct s*)malloc(sizeof(struct s));
	temp=headB;
	while(temp!=NULL)
	{
		printf("x=%d y=%d\n",temp->x,temp->y);
		temp=temp->next;
	}
}

int main()
{
	int x,y,t,n,i;
		scanf("%d",&n);
		while(n!=0)
		{
		scanf("%d %d",&x,&y);
		insert(n,x,y);
		scanf("%d",&n);
		}
		
		scanf("%d",&n);
		while(n!=0)
		{
		scanf("%d %d",&x,&y);
		insert2(n,x,y);
		scanf("%d",&n);
		}
	printf("list1=\n");
	display();
	change();
	printf("list2=\n");
	display2();
	change2();
	headA=mergeSort(headA);
	printf("after sorting A :\n");
	display();
	headB=mergeSort2(headB);
	printf("after sorting B :\n");
	display2();
}
