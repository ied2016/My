#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct ll{
	int key;
	struct ll *next ,*prev;
}*start;
struct ll* head=NULL;

void insert(int x)
{
	struct ll *temp=(struct ll*)malloc(sizeof(struct ll));
	if(head==NULL)
	{
		temp->key=x;
		temp->prev=temp->next=NULL;
		head=temp;
		start=temp;
		return;
	}
	struct ll *new1=(struct ll*)malloc(sizeof(struct ll));
	new1=start;
	while(new1)
	{
		if(new1->key>=x)
		{
			temp->key=x;
			temp->next=new1;
			temp->prev=new1->prev;
			if(new1->prev!=NULL)
			new1->prev->next=temp;
			else
			start=temp;
			new1->prev=temp;	
			return;	
		}
		else if(new1->next==NULL&&new1->key<x)
		{
			temp->key=x;
			temp->next=NULL;
			new1->next=temp;
			temp->prev=new1;
			head=temp;
			return;
		}
		new1=new1->next;
	}
}

void print(int x)
{
	struct ll *new1=(struct ll*)malloc(sizeof(struct ll));
	new1=start;
	int c=0;
	//printf("\nLinked list=");
	while(new1)
	{
		if(c==x)
		printf("%d\n",new1->key);
		c++;
		new1=new1->next;
	}
	if(x>=c)
	{
		printf("%d\n",-1);
		return;
		}	
}

void removedup()
{
    struct ll* current = start;
 
    struct ll* next_next; 
   
  
int c=0;
    while (current->next != NULL) 
    {
    //	printf("\ncurrent=%d",current->key);
       if (current->key == current->next->key) 
       {
           next_next = current->next->next;
           if(current->next->next!=NULL)
           current->next->next->prev=current;
           printf("%d ",current->next->key);
           if(current->next->next==NULL)
           {
		   head=current;
       	   //current->next=NULL;
	   	   }
		   free(current->next);
           c++;
           current->next = next_next;  
       }
       else 
       {
	    current = current->next; 
       }
    }
    if(c==0)
    {
    	printf("%d",-1);
	}
}

int main()
{
	char s[80];
	int k,t,n,i,j,num;
	scanf("%d",&t);
	for(k=0;k<t;k++)
	{
	head=NULL;
	scanf("%d",&num);
	while(num!=0)
	{
		insert(num);		
		scanf("%d",&num);
	}
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%s",&s);
		if(strcmp(s,"Insert")==0)
		{
			scanf("%d",&num);
			insert(num);
			printf("%d\n",num);
		//	print();
		}
		 if(strcmp(s,"Delete")==0)
		{
			removedup();
			printf("\n");
	//		print();
		}
		if(strcmp(s,"Print")==0)
		{
			scanf("%d",&num);
			print(num);
		}
	}
	//print();
	//printf("\nenter new elements=");
	//scanf("%d",&n);
//	for(i=0;i<n;i++)
//	{
//		scanf("%d",&num);
//		insert(num);
//			print();
//		
//	}
//	print();
		free(head);

}
	return 0;
}
