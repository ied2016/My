#include <stdio.h>
int n;
// void hs(int A[])
// {
// 	int i,len,tmp;
// 	len=sizeof(A)/sizeof(A[0]);
// 	build(A);
// 	for(i=len;i>=2;i--)
// 	{
// 		tmp=A[1];
// 		A[1]=A[i];
// 		A[i]=tmp;
// 		len--;
// 		mh(A,1);
// 	}
// }

void mh(int A[],int i)
{
	int l,r,largest,tmp,len;
	l=2*i;
	r=2*i+1;	
	if(l<n&&A[l]>A[i])
		largest=l;
	else
		largest=i;
	if(r<n&&A[r]>A[largest])
		largest=r;
	if(largest!=i)
	{
		tmp=A[i];
		A[i]=A[largest];
		A[largest]=tmp;
		mh(A,largest);
	}
}

void build(int A[])
{
	int len,i;
	//len=sizeof(A)/sizeof(A[0]);
	for(i=n/2;i>0;i--)
	mh(A,i);
}

int main()
{
int t,i,j,k;
scanf("%d",&n);
int a[n];
for(i=0;i<n;i++)
scanf("%d",&a[i]);
build(a);
for(i=0;i<n;i++)
printf(" %d ",a[i]);
}