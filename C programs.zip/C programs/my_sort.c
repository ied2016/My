#include <stdio.h>
int main()
{
	int a[10000]={0},i,j,n,num;
	scanf("%d",&num);
	for(i=0;i<num;i++)
	{
	scanf("%d",&n);
	a[n]=1;
	}
	for(i=0;i<10000;i++)
	{
	if(a[i]==1)
	{
		printf("->%d",i);
	}
	}
}