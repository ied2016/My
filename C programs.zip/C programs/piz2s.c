#include <stdio.h>
int main()
{
	long long int n,i,ans=0,num,want=0;
	scanf("%lld",&n);
	for(i=0;i<n;i++)
	{
	scanf("%lld",&num);
	want+=(num-1);
	//printf("want=%d\n",want);
	}
	if(want>=n)
		{ans=want-n;
			if(ans%2==0)
				ans/=2;
			else
				ans=(ans/2)+1;
			//printf("ans=%lld\n",ans);
		}
	else 
		ans=0;
	printf("%lld",n+ans);
	return 0;
}