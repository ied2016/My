#!/usr/local/bin/python
import os
import glob
import filecmp
import sys
import difflib


if __name__ == '__main__':
	l = list(glob.glob("./*.c"))
	for f in l:
		file_out = open("Failed_tests.txt", "w+")
		filename = f.split("/")[-1]
		print "Running "+filename+"..."
		diff = raw_input("Do you want diffs for test cases to be stored?(Yes/No)")
		os.system("rm -rf ./diffs")
		if diff=="Yes":
			os.system("mkdir diffs")
		os.system("rm -rf ./your_outputs")
		os.system("mkdir your_outputs")
		os.system("gcc "+f+" -o "+"./"+filename[:-2])
		tests = list(glob.glob("./in/*.in"))
		for i in range(1,len(tests)+1):
			sys.stdout.write("test"+str(i)+"...")
			os.system("timeout 5s ./"+filename[:-2]+" < ./in/test"+str(i)+".in > ./your_outputs/test"+str(i)+".out")
			prog_out = open("./your_outputs/test"+str(i)+".out", "r").readlines()
			out = open("./out_dir/test"+str(i)+".out", "r").readlines()
			diff_lines = list(difflib.unified_diff(out, prog_out, fromfile="out_dir/test"+str(i)+".out", tofile="./your_outputs/test"+str(i)+".out", lineterm='', n=0))
			if diff_lines:
				sys.stdout.write("Failed\n")
				file_out.write(" test"+str(i)+"\n")
				if diff=="Yes":
					diff_fil = open("./diffs/test"+str(i)+".diff", "w+")
					for line in diff_lines:
						diff_fil.write("%s\n" % line)
					print "Diff Has been written to file ./diffs/test"+str(i)+".diff"
			else:
				sys.stdout.write("\n")
		file_out.close()
