#include <stdio.h>
#include <string.h>
int main()
    {
    	int i,c,t;
    	char s[100000];
    	scanf("%d",&t);
    	while(t--)
    	{
    		c=0;
    		scanf("%s",&s);
    		for(i=0;i<strlen(s);i++)
    		{
    			if(s[i]!='4'&&s[i]!='7')
    				c++;
    		}
    		printf("%d\n",c);
    	}
} 