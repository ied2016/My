#include <stdio.h>
#include <stdlib.h>
struct bst
{
int key;
struct bst *left,*right;
};

struct bst *insert(struct bst* node,int x)
{
	if(node==NULL)
	{
		struct bst *temp=(struct bst*)malloc(sizeof(struct bst));
		temp->key=x;
		temp->left=temp->right=NULL;
		return temp;
	}
	if(x<=node->key) 
		node->left=insert(node->left,x);
	else if(x>node->key)
		node->right=insert(node->right,x);
	return node;
}
void inorder(struct bst* root,int j)
{
	int i;
	if(root!=NULL)
		for(i=0;i<j;i++)
	{	
		inorder(root->left);
			printf("\nkey=%d",root->key);
		inorder(root->right);
	}
}

int main()
{
    int key = 65,i,j,num;    
 
    struct bst *root = NULL;
    printf("how many=");
    scanf("%d",&j);
    scanf("%d",&num);
    root = insert(root,num);
    for(i=0;i<j-1;i++)
    {
       scanf("%d",&num);
	   insert(root,num);
    }
	inorder(root,j);
return 0;    
}