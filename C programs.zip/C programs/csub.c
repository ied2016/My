#include <stdio.h>
#include <string.h>
int main()
{
	long long int t,n,i,c,ans;
	scanf("%lld",&t);
	while(t--)
	{
	c=0;
	scanf("%lld",&n);
	char s[n+2];
	scanf("%s",s);
	for(i=0;i<strlen(s);i++)
	{
	if(s[i]=='1')
		c++;
	}
	ans=(c*(c+1))/2;
	printf("%lld\n",ans);
	}
}