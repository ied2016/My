#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#define ulli unsigned long long int
inline int inp1()
{
int noRead=0;
char p=getchar_unlocked();
for(;p<33;){p=getchar_unlocked();};
while(p>32)
{
noRead = (noRead << 3) + (noRead << 1) + (p - '0');
p=getchar_unlocked();
}
return noRead;
};
int main(){
ulli count,st,inp,l,tc;//bool flag=1;
tc=inp1();
while(tc--){
   l=inp1();
   count=1;
   inp=inp1();
   st=inp;
   while(l>1){
       inp=inp1();
       if(inp<=st){count++;st=inp;}
       l--;
   }
   printf("%lld\n",count);
}
return 0;
}
// #include <stdio.h>
// inline int inp()
//     {
//     int noRead=0;
//     char p=getchar_unlocked();
//     for(;p<33;){p=getchar_unlocked();}
//     while(p>32)
//     {
//     noRead = (noRead << 3) + (noRead << 1) + (p - '0');
//     p=getchar_unlocked();
//     }
//     return noRead;
//     }
// int main()
// {
// 	int i,n,t,prev;
// 	scanf("%d",&t);
// 	while(t--)
// 	{
// 	scanf("%d",&n);
// 	int c=0,a[n];
// 	for(i=0;i<n;i++)
// 		{
// 		scanf("%d",&a[i]);
// 		if(i>0)
// 		{
// 		if(prev>a[i])
// 		c++;
// 		};
// 		prev=a[i];
// 		};
// 	printf("%d\n",c+1);
// 	}
// };