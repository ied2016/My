#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct dll{
	int key;
	struct dll *prev,*next;
}*sv,*sn,*start;

struct dll *head=NULL;

struct dll *spli(struct dll *head)
{
    struct dll *fast = head,*slow = head;
    while (fast->next && fast->next->next)
    {
        fast = fast->next->next;
        slow = slow->next;
    }
    struct dll *temp = slow->next;
    slow->next = NULL;
    return temp;
}
// Function to merge two linked lists
struct dll *mergeo(struct dll *first, struct dll *second)
{
    // If first linked list is empty
    if (!first)
        return second;
 
    // If second linked list is empty
    if (!second)
        return first;
 
    // Pick the smaller value
    if (first->key > second->key)
    {
        first->next = mergeo(first->next,second);
        first->next->prev = first;
        first->prev = NULL;
        return first;
    }
    else
    {
        second->next = mergeo(first,second->next);
        second->next->prev = second;
        second->prev = NULL;
        return second;
    }
}
 
struct dll *mergel(struct dll *first, struct dll *second)
{
    // If first linked list is empty
    if (!first)
        return second;
 
    // If second linked list is empty
    if (!second)
        return first;
 
    // Pick the smaller value
    if (first->key < second->key)
    {
        first->next = mergel(first->next,second);
        first->next->prev = first;
        first->prev = NULL;
        return first;
    }
    else
    {
        second->next = mergel(first,second->next);
        second->next->prev = second;
        second->prev = NULL;
        return second;
    }
}
// Function to do merge sort
struct dll *mo(struct dll *head)
{
    if (!head || !head->next)
        return head;
    struct dll *second=spli(head) ;
 
    // Recur for left and right halves
    head = mo(head);
    second = mo(second);
 
    // Merge the two sorted halves
    return mergeo(head,second);
}

struct dll *ml(struct dll *head)
{
    if (!head || !head->next)
        return head;
    struct dll *second=spli(head) ;
 
    // Recur for left and right halves
    head = ml(head);
    second = ml(second);
 
    // Merge the two sorted halves
    return mergel(head,second);
}


// void insert(int v)
// {
//     struct dll *temp=(struct dll*)malloc(sizeof(struct dll));
//     temp->key=v;
//     if(head1==NULL)
//     {
//     temp->prev=temp->next=NULL;
//     start=temp;
//     head1=temp;
//     return;
//     }
//     head1->next=temp;
//     temp->prev=head1;
//     head1=temp;
//     return;
// }
 
// // A utility function to print a doubly linked list in
// // both forward and backward directions
// void print()
// {
//     struct dll *temp = start;
//     printf("\nForward Traversal using next poitner : ");
 
//     while (temp)
//     {
//         printf("%d ", temp->key);
//         temp = temp->next;
//     }
// }
 
// Utility function to swap two integers
void swap(int *A, int *B)
{
    int temp = *A;
    *A = *B;
    *B = temp;
}
//  void p()
// {
//     struct dll *temp=(struct dll*)malloc(sizeof(struct dll));
//     temp=start;
//     //index++;
//     //int count=0;
//     while(temp!=NULL)
//     {
    
//         printf(" %d ",temp->key);

//         temp=temp->next;
//     }
//     //printf("%d\n",-1);
// }
// Split a doubly linked list (DLL) into 2 DLLs of
void send(int o,int v,int l)
{
    int count=0,i;
    struct dll *temp=start,*savef,*saveb,*sort,*ret,*prev;
    if(v!=1)
    {
    for(i=0;i<v-1;i++)
    {
       // printf("\nv== %d ",temp->key);
        temp=temp->next;
    }
    savef=temp->prev;
    temp->prev=NULL;
    sort=temp;
    for(i=v;i<l;i++)
    {
             //   printf("\nl v=== %d ",temp->key);

        temp=temp->next;
    }
    saveb=temp->next;
    temp->next=NULL;
    if(o==2)
    ret=mo(sort);
	else if(o==1)
    ret=ml(sort);		
    savef->next=ret;
    ret->prev=savef;
    temp=ret;
    while(temp)
    {
                prev=temp;
            //                    printf("\nt= %d ",t->key);

        temp=temp->next;
    }
    prev->next=saveb;
    }
    else if(v==1)
    {
       // printf("here" );
       for(i=v;i<l;i++)
    {
             //   printf("\nl v=== %d ",temp->key);

        temp=temp->next;
    }
    saveb=temp->next;
    temp->next=NULL;
    if(o==2)
    start=mo(start);
	else if(o==1)
    start=ml(start);
    //savef->next=ret;
    //ret->prev=savef;
    temp=start;
    while(temp)
    {
                prev=temp;
                    //            printf("\nt= %d ",t->key);

        temp=temp->next;
    }
    prev->next=saveb; 
    }
    //p();
}
 

void insertbeg(int v)
{
	struct dll *temp=(struct dll*)malloc(sizeof(struct dll));
	temp->key=v;
	if(head==NULL)
	{
	temp->prev=temp->next=NULL;
	start=temp;
	head=temp;
	return;
	}
	start->prev=temp;
	temp->next=start;
	temp->prev=NULL;
	start=temp;
}

void insertend(int v)
{
	struct dll *temp=(struct dll*)malloc(sizeof(struct dll));
	temp->key=v;
	if(head==NULL)
	{
	temp->prev=temp->next=NULL;
	start=temp;
	head=temp;
	return;
	}
	head->next=temp;
	temp->prev=head;
	temp->next=NULL;
	head=temp;
}

void delete(int i, int m)
{
	if(start==NULL)
		return ;
	struct dll *temp=(struct dll*)malloc(sizeof(struct dll));
	temp=start;
	while(i!=1)
	{
		temp=temp->next;
		i--;
	}
	sn=temp;
	temp=temp->next;
	while(m!=1)
	{
		temp=temp->next;
		m--;
	}
	if(temp->next==NULL)
	{
		sn->next=NULL;
		head=sn;
		free(temp);
		return ;
	}
	else{
	sn->next=temp->next;
	temp->next->prev=sn;
	free(temp);
	}
}

void print()
{
	struct dll *temp=(struct dll*)malloc(sizeof(struct dll));
	temp=start;
	while(temp)
	{
		printf("%d ",temp->key);
		temp=temp->next;
	}
}

int main()
{
	int t,num,i,j,m,o,l,u;
	char s[80];
	scanf("%d",&t);
	for(j=0;j<t;j++)
	{
		scanf("%s",s);
		if(strcmp(s,"INSERTBEG")==0)
			{
			scanf("%d",&num);
			insertbeg(num);
			}
		if(strcmp(s,"INSERTEND")==0)
			{
			scanf("%d",&num);
			insertend(num);
			}
		if(strcmp(s,"PRINT")==0)
			{print();printf("\n");}
		if(strcmp(s,"DELETENEXT")==0)
		{
			scanf("%d %d",&i,&m);
			delete(i,m);
		}
		if(strcmp(s,"SORT")==0)
		{
			scanf("%d %d %d",&o,&l,&u);
			send(o,l,u);
		}
		//print();
		//printf("\n");
	}
	return 0;
}