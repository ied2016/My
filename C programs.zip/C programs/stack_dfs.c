#include <stdio.h>
#include <stdlib.h>
struct node{
	int key;
	struct node *next,*head;
};

int visited[100002]={0},s,count=0,f=0;

struct graph
{
	int v;
	struct node* array;
};

struct node* createnode(int x)
{
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->key=x;
	temp->next=NULL;
	return temp;
}

struct graph* creategraph(int v)
{
	struct graph* g=(struct graph*)malloc(sizeof(struct graph));
	g->v=v;
	g->array=(struct node*)malloc((v+1)*sizeof(struct node));
	int i;
	for(i=1;i<=v;i++)
		g->array[i].head=NULL;
	return g;
}

void addedge(struct graph* g,int a1,int a2)
{
	struct node* temp=createnode(a2);
	temp->next=g->array[a1].head;
	g->array[a1].head=temp;
	temp=createnode(a1);
	temp->next=g->array[a2].head;
	g->array[a2].head=temp;
}

void print(struct graph* g)
{
	int i;
	for(i=1;i<=g->v;i++)
	{
		struct node* temp=g->array[i].head;
		printf("\n list of vertex %d\n",i);
		while(temp)
		{
			printf("->%d",temp->key);
			temp=temp->next;
		}
		printf("\n");
	}
}

void dfs(int u,int v,struct graph* g)
{
	int nd,a[10000],top=-1;
	//visited[u]=1;
	a[++top]=u;
	struct node* temp;
	//for(temp=g->array[u].head;temp!=NULL;temp=temp->next)
	while(top!=-1)
	{
		nd=a[top--];
		if(!visited[nd])
		{
			//a[++top]=nd;
			visited[nd]=1;
			//count++;
			//printf("visit=%d\n",nd);
		temp=g->array[nd].head;
		int prev;
		for(;temp!=NULL;temp=temp->next)
		{
			if(!visited[temp->key])
			{
			//printf("\ntemp->key=%d",temp->key);
			a[++top]=temp->key;
			}
			if(visited[temp->key]&&prev!=temp->key)
			{
			//	printf("got it!!!=%d  	prev=%d\n",temp->key,prev);
				//return temp->key;
				f=1;
			}
		}
		prev=nd;
		}
		//top--;
	}
	//return 0;
}


int main()
{
	int v,e,i,t,ans;
	scanf("%d",&t);
	//printf("t=%d\n",t);
	while(t--)
	{
		ans=1;
		f=0;
	for(i=1;i<=v;i++)
	{
		visited[i]=0;
	}
	scanf("%d %d",&v,&e);
	//printf("v=%d e=%d\n",v,e);
	struct graph* g=creategraph(v);
	for(i=0;i<e;i++)
	{
		int a1,a2;
		scanf("%d %d",&a1,&a2);
		//printf("a1=%d a2=%d\n",a1,a2);
		addedge(g,a1,a2);
	}
	//print(g);
	// for(s=1;s<=v;s++)
	// {	count=0;
	//int ans=
	dfs(1,v,g);
	for(i=1;i<=v;i++)
		if(visited[i]==0)
			{
				ans=0;
				//printf("i=%d\n",i);
			}
	if(f==1||ans==0)
	{//printf("%d\n",ans);
	printf("NO\n");
	}
	else if(f==0&&ans!=0)
		printf("YES\n");
	}
	//return 0;
}