#include<stdio.h>
int main()
{int a;
char s;
double b;
printf("size of char=%d\n%d\n%d",sizeof(s),sizeof(b),sizeof(a));
return 0 ;
}