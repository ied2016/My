#include<stdio.h>
int main()
{
	int i,j;
	char s[222];
	gets(s);
	for(i=0;s[i]!='\0';i++)
	{if(s[i]=='a')
	s[i]='2';
	else if(s[i]=='b')
	 s[i]='3';
	else if(s[i]=='c')
	 s[i]='4';	 
		 }
	for(i=0;s[i]!='\0';i++)
{
		printf("%c",s[i]);
}}
