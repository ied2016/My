#include<stdio.h>
int main()
{
 int a[1000000000],i,j,d1=0,d2=0,n;
 scanf("%d\n",&n);
 for(i=0;i<n;i++)
 {
  for(j=0;j<n;j++)
  {
   scanf("%d ",&a[i]);
  }printf("\n");
 }
 for(i=0;i<n;i++)
 {for(j=0;j<n;j++)
  {
   if (i==j)
   {d1+=a[i];}
   if(i+j==n-1)
   {d2+=a[i];}
  }
 }
 if (d1>d2)
 printf("%d",d1-d2);
 else
 printf("%d",d2-d1);
 return 0;
}
