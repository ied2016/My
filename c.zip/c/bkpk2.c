#include<stdio.h>
int main()
{
	int i,j,n,zero=0,max=0,row,x,y,z,size=0,k,num=0;
	scanf("%d",&n);
	int a[n][n];
	for(i=0;i<n;i++)
	for(j=0;j<n;j++)
	scanf("%d",&a[i][j]);

	for(i=0;i<n;i++)
	for(j=0;j<n;j++)
	printf("\n  %d   i=%d   j=%d",a[i][j],i,j);

	for(i=0;i<n;i++)
	for(j=0;j<n;j++)
	{
		if(*(*(a+i)+j)==0)
		{
			for(k=0;k<n;k++)
			{	if(*(*(a+i)+k)==0)
				{num++;
					printf("\n %d  i=%d   k=%d",a[i][k],i,k);
			}}
			printf("\n NUM=%d",num);
		}

	}

//printf("\n%d\n",size+1);


} 