#include<stdio.h>
int main()
{
	int a[1000],n,count,i,j;
	for(i=0;i<1000;i++)
	{
	for(j=0;j<1000;j++)
	{
	count++;
	}
	}
	printf("\ncount=%d\n",count);
}