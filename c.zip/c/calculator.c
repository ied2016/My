#include<stdio.h>
int main()
{
	int p,n,i,j,pos;
	char c,s[200];
	gets(s);
	for(i=0;s[i]!='\0';i++)
	{if(s[i]=='+')
	 {p=s[i-1];n=s[i+1];c=p+n;
	   s[i+1]=c; printf("\n=%c",s[i+1]); pos=i+1; }
	else if(s[i]=='-')
	  {p=s[i-1];n=s[i+1];c=p-n;
	  s[i+1]=c;  pos=i+1; }
	else if(s[i]=='*')
	  {p=s[i-1];n=s[i+1];c=p*n;
	  s[i+1]=c;  pos=i+1; }
	else if(s[i]=='/')
	 {p=s[i-1];n=s[i+1];c=p/n;
	   s[i+1]=c;   pos=i+1; }
}
	
	printf("answer=%c",s[pos]);
	
}
