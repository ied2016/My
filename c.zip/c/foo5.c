#include <vector>
#include <stdio.h>
using namespace std;
int max(vector<int> a[])
{int j;
	for(j=0;j<a.size();j++)
		printf(" %d ",a[j]);

}
int main()
{
	vector<int> v(5);
	v[0]=1;
	v[1]=2;
	printf("%d\n",v[1]);
	v.push_back(9);
	for(int i=0;i<v.size();i++)
	{
		printf(" %d ",v[i]);
	}
	max(v);
}