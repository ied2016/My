#include<stdio.h>
int main()
{
	int *i;

	char *p="Abhas";
	printf("%d",*p);
	int (*(*ptr)())[2];
	printf("\ns=%s \n",p[1]+p[1]-p[3]);
/*		printf("\n%c\n",*p);
		printf("\n*p=%d  p=%d",*p,p);
		p++;

		printf("\n%c\n",*p);
		printf("\n*p=%d  p=%d",(char)*p,p);
				printf("\n  i=%c",*i);
		i++;
		p++;
		printf("\n%c\n",*p);
		printf("\n*p=%d  p=%d",*p,p);
						printf("\n  i=%c",*i);

		p++;*/

}