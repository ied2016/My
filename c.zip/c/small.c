#include<stdio.h>
int main()
{
	int a[5],i,sml=a[0],*p;
	printf("Enter the elements\n");
	for(i=0;i<5;i++)
	scanf("%d",&a[i]);
	p=&a;
	for(i=0;i<5;i++)
	{
		if(sml>*p)
	{
			sml=*p;
		
	
	}
	p++;
	}
	printf("small=%d",sml);
	
}
