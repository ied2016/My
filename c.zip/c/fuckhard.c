#include<stdio.h>
int main()
{
	int i=0;
	for(;i<10;)
	{i++;
		printf("fuck you harddd !!! \n");
	}
}
