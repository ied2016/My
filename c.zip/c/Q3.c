#include<stdio.h>
#include<string.h>
int main()
{char a[100];
	int c=0,k=0,i,j,l1;
		char b[900],out[100];
char *p;
	p=&out;
	scanf("%s",&a);
	printf("string=%s\n",a);
	l1=strlen(a);

	for(i=0;i<l1;i++)
	{
		b[i]=a[i];
	}
	printf("%s",b);
	for(i=0;i<l1;i++)
	{c=0;
	for(j=0;j<l1;j++)
	{
	if(a[i]==b[j])
	{
		c++;
	}
	
	}
	//out[k++]=a[i];
	//out[k]=c;
	//k++;
		printf("\nc=%d\n",c);

	*p=a[i];
	p++;
	*p=c;
	p++;
	}
printf("%s\n",out);
}