#include<stdio.h>
int main()
{
	int i,j,l;
	int tc;
	scanf("%d",&tc);
	for(i=0;i<tc;i++)
	{scanf("%d",&l);
	char s[100];
	scanf("%s",&s);
	char *p;
	p=&s[l-1];
	for(j=0;j<l;j++)
	{
	printf("%c",*p);
	p--;	
	}printf("\n");
}
}
