#include<stdio.h>
int main()
{
	int count,i=0,j;
	char ch[10][0];
	while(i!=10)
	{
		printf("\n");
		scanf("%c",&ch[i][0]);
		i++;
		printf("*\n");
		
	}
	
}
