#include<stdio.h>
int main()
{
	int i,j,n,zero=0,max=0,row,x,y,z,up,down,left,right,size=0;
	scanf("%d",&n);
	int a[n][n];
	for(i=0;i<n;i++)
	for(j=0;j<n;j++)
	scanf("%d",&a[i][j]);

	for(i=0;i<n;i++){printf("\n");
	for(j=0;j<n;j++)
	{
	printf(" %d i=%d j=%d",*(*(a+i)+j),i,j);

	}
}
	for(i=0;i<n;i++){
	for(j=0;j<n;j++)

	{
		if(*(*(a+i)+j)==0)
		{if(*(*(a+i+1)+j)!=0||*(*(a+i-1)+j)!=0||*(*(a+i)+j+1)!=0||*(*(a+i)+j-1)!=0)
		{*(*(a+i)+j)=1;

		}
		
}}}

for(i=0;i<n;i++){printf("\n");
	for(j=0;j<n;j++)
	{
	printf(" %d ",*(*(a+i)+j));

	}
}
} 