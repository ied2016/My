#include<stdio.h>
int main()
{
	int a[100],v,n,i,ind,num;
	scanf("%d",&v);
	scanf("%d",&n);
	for(i=0 ;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	if(a[i]==v)
	printf("%d",i+1);
}
