#include <stdio.h>
#include <math.h>

int main()
{
   char *str;
   str="sddf";
   printf("%d",printf("%s",str));
   
   return(0);
}