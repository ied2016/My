#include<stdio.h>
int main()
{
	int i=0,j,k,l;
	char ch,a,b,s[453];
	FILE *f1,*f2;
	f1=fopen("v4.txt","r+");
	//f2=fopen("v4.txt","a");
	//printf("%p  %p",f1,*f1);
	//printf("\nsize=%ld",sizeof(*f1));
	//ch=getc(f1);
	//printf("\n%p",getw(f1));
	//for(i=100;i<105;i++)
	//putw(i,f2);
	fseek(f1,-4,2);
	a=getc(f1);
	rewind(f1);
	i=ftell(f1);
	fseek(f1,0,0);
	//fseek(f2,-1,1);
	b=getc(f1);
	fputs("f",f1);
	//fgets(s,5,f1);
	//printf("\n%c  %c  \n",ch,a);
	//fgets(s,234,f1);
	printf("string=  a=%c  b=%c size=%d\n",a,b,i);
	//fclose(f1);
	//fclose(f2);
}