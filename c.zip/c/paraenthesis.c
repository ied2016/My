#include<stdio.h>
#include<stdlib.h>
#define msize 1000
int a[msize];
int top=-1;
void push(int x)
{if(top==msize-1)
{printf("\nStack overflow ");
return;
}
a[++top]=x;
}
void pop()
{if(top==-1)
{printf("\nError: Stack is empty!!!");
return;
}
top--;
}
void print()
{int i;
for(i=0;i<=top;i++)
{printf("\nElemten %d is = %d ",i+1,a[i]);
}
}
void main()
{
	printf("Enter the expression you want= ");
	int size,n,choice,i;
	char br;
	
	scanf("%c",&br);
	for(i=0;i<size;i++)
	{printf("\nEnter the element number %d = ",i+1);
	scanf("%d",&n);
	push(n);
	printf("\nYour current stack is =");
	print();
	}
}
