#include<stdio.h>
int small(int arr[],int a,int b)
{ int j,min=arr[a];

for(j=a;j<=b;j++)
{
	if(arr[j]<min)
	{
	min=arr[j];
	
	}
	
}
return min;
	
}

int main()
{int n; 
    int t,i,ar[100000],a,b,sml; 
    scanf("%d %d",&n,&t);
    int width[n];
    for( i = 0;i < n; i++){
       scanf("%d",&ar[i]);
    }
    for(i= 0; i< t; i++){
        scanf("%d %d",&a,&b);
        sml=small(ar,a,b);
        printf("%d",sml);
        
    }
    
}
