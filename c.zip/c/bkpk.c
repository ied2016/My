#include<stdio.h>
#include<ctype.h>
#include<string.h>
int main()
{
	int i,j,k=0,n,up=0,down=0,right=0,left=0,a,b,c,d;
	scanf("%d",&n);
	char s[n+1][n+1],str[100],*p,*ptr;
	for(i=0;i<n;i++){
		scanf("%s",s[i]);
}


	for(i=0;i<n;i++)
		{printf("\n");
	for(j=0;j<n;j++)
	printf(" %c ",*(*(s+i)+j));
}

for(i=0;i<n;i++)
	for(j=0;j<n;j++)
	*(*(s+i)+j)=tolower(*(*(s+i)+j));

printf("\nEnter the string=");
scanf("%s",str);
for(i=0;i<strlen(str);i++)
{
	str[i]=tolower(str[i]);
}

ptr=&str;

	for(i=0;i<n;i++)
	{
	for(j=0;j<n;j++)
	{up=down=left=right=0;
		if(*(*(s+i)+j)==*ptr)
	{
		p=ptr;
		for(a=i;a>=0;a--)
		{
			if(*(*(s+a)+j)!=*p)
				break;
			else
				{p++;
					up++;}
		}
		
		p=ptr;
		for(b=i;b<n;b++)
		{
			if(*(*(s+b)+j)!=*p)
				break;
			else
				{p++;
					down++;}
		}

		p=ptr;
		for(c=j;c<n;c++)
		{
			if(*(*(s+i)+c)!=*p)
				break;
			else
				{p++;
					right++;}
		}

		p=ptr;
		for(d=j;d>=0;d--)
		{
			if(*(*(s+i)+d)!=*p)
				break;
			else
				{p++;
					left++;}
		}

		if(up==strlen(str)||down==strlen(str)||right==strlen(str)||left==strlen(str))
			return printf("\nYes\n");

	}
}
}
printf("\nNO\n");
}
