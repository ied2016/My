#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct student{
    double roll;
    char name[50];
    int marks;
};
int main()
{
    int i,j,t,n,k,min=10000,dist;
    char X[100],Y[100];
    scanf("%d",&t);
    for(k=0;k<t;k++)
    {
    struct student s[n];
        scanf("%ld %s %d",&s[i].roll,&s[i].name,&s[i].marks);
    
  /*  for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            if(i!=j)
            {
                dist=abs(s[i].x-s[j].x)+abs(s[i].y-s[j].y);
                if(dist<min)
                {   
                    min=dist;
                    strcpy(X,s[i].name);
                    strcpy(Y,s[j].name);
                }
            }
        }
    }*/
   // printf("%s %s",X,Y);
}
}