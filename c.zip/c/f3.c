#include<stdio.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>
int main()
{
	int t,i,j,l,c=0,zero,cnt=0,k;
	char n[100],*ptr;
	double d;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{cnt=0;zero=0;c=0;
	scanf("%s",&n);
	ptr=&n;
	l=strlen(n);

	for(j=0;j<l;j++)
	{printf("%c",*ptr);
		if(*ptr=='.')
			c++;
		ptr++;
		if(c==1)
			cnt++;
	}

		if(c>=2)
			printf("ERROR");
		else
{
	if(cnt<6)
	{
		zero=6-cnt;
		for(k=0;k<=zero;k++)
		{
			printf("%c",'0');
		}
	}}
}
}
