#include<stdio.h>
struct student{
double d;
char name[4];
char ch;
};
struct teacher
{
char n[30];
struct student my;
};
struct class{
int uniqCode;
struct teacher* whoteaches;
struct student* whoStudy[25];

};
int main()
{		struct student st;
		struct teacher te;
		struct class cl;

	printf("student=%ld\n",sizeof(st));
	printf("teacher=%ld\n",sizeof(te));
	printf("class=%ld\n",sizeof(cl));

}