#include<stdio.h>
#include<string.h>
int main()
{
	char s[80],word[80];int i,j,k=0;
	gets(s);
	for(i=0;i<=s[i]!='\0';i++)
	{
		if(s[i]!=' ')
		{
			word[k++]=s[i];
		}
		else
{
		while(k>0)
	{printf("\n\n%c",word[--k]);
	
	}
	
	printf("%c",s[i]);
}
	}
	
	
}
