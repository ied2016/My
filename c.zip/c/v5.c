#include<stdio.h>
int main()
{
char s[200],s1,s2;
int i=0;
s2=getchar();
while(s1!='\n')
{s1=getchar();
s[i]=s1;
i++;
}                                   
printf("\n%s  \n %c",s,s2);

return 0;
}
