#include<stdio.h>
void main()
{
    int i, j;
int n;
scanf("%d",&n);
int m[n][n];
 for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
        scanf("%d",&m[i][j]);
        }
    }
    for (i = 0; i < n; i++)
    {
        for (j = i + 1; j < n; j++)
        {
            int tmp = m[i][j];
            m[i][j] = m[j][i];
            m[j][i] = tmp;
        }
    }
    for (i = 0; i < n / 2; i++)
    {
        for (j = 0; j < n; j++)
        {
            int tmp = m[j][i];
            m[j][i] = m[j][n - i - 1];
            m[j][n - i - 1] = tmp;
        }
    }
       for (i = 0; i < n; i++)
    {printf("\n");
        for (j = 0; j < n; j++)
        {
        printf(" %d ",m[i][j]);
        }
    }
}