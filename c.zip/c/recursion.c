#include<stdio.h>
void a(int n)
{
	if(n>=1)
	{
	a(n-1);
	printf(" %d ",n);
	a(n-1);
	printf(" (%d) ",n);
	}
}
int main()
{
	a(3);
}