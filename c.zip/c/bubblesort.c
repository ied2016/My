#include<stdio.h>
int main()
{
	int i,j,a[100],n,temp;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	for(j=n-1;j>=i+1;j--)
	{
	if(*(a+j)<*(a+j-1))
	{
	temp=*(a+j);
	*(a+j)=*(a+j-1);
	*(a+j-1)=temp;
	}
	}
	for(i=0;i<n;i++)
	printf(" %d ",*(a+i));
}