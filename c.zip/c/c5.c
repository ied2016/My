#include<stdio.h>
int main()
{int a=3;
	printf("%d",a++*a+a);
}
