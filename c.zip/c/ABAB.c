#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
	int i,j,c=0,n;
	char t[10000000];
	scanf("%d",&n);
	for(i=0;i<n;i++){
	c=0;
	scanf("\n%s",&t);
	for(j=0;j<strlen(t);j++)
	{
		if(t[j]==t[j+1])
		c++;	
	}
	printf("%d",c);}
	return 0;
}
