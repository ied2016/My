#include<stdio.h>
#include<string.h>
int main()
{
	char s[80],word[80];int i,j,k=0;
	gets(s);
	for(i=0;i<=sizeof(s)/sizeof(s[0]);i++)
	{k=0;
		if(s[i]!=' ')
		{
			word[k++]=s[i];
		}
	else
{k=0;
		while(k>=0)
	{
       if (k==0)
	   printf("\n%c",toupper(word[k]));
	   else	
	printf("\n%c",word[k++]);
	
	}
}}
}
