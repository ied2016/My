#include<stdio.h>
#include<stdlib.h>
int main()
{ int r=3,c=4,i,j,cu=0;char s[10],ss;
int *a=(int *)malloc(r*c*sizeof(int));
printf("%d\n",sizeof(s[2]));
for(i=0;i<r;i++)
for(j=0;j<c;j++)
*(a+i*c+j)=++cu;
for(i=0;i<r;i++)
for(j=0;j<c;j++)
printf("%d ",*(a+i*c+j));
}
