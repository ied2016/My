#include <stdio.h>
#include <stdlib.h>

int compl(int a)
{
	return 1-a;
}

int min(int a,int b,int c)
{
	int min=a; 
	if(b<=a && b<=c)
	{
		return b;
	}
	else if(c<=a && c<=b)
	{
		return c;
	}
	return a;
}

void main()
{
	int max;
	int n,check;
	printf("Enter size of array :");
	scanf("%d",&n);
	int a[n][n],b[n][n];
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			scanf(" %d",&a[i][j]);
			a[i][j]=compl(a[i][j]);
			b[i][j]=a[i][j];
		}
	}

	for(int i=1;i<n;i++)
	{
		for(int j=1;j<n;j++)
		{
			if(b[i][j]==1)
			{
				b[i][j]=min(b[i-1][j-1],b[i][j-1],b[i-1][j])+1;
			}
		}
	}
	printf("\n");
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	printf("\n");
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
	max=b[0][0];
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			if(max<b[i][j])
			{
				max=b[i][j];
			}
		}
	}
	printf("The subarray with max 0's : %d\n",max);
}	