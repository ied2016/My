#include<stdio.h>
#include<stdlib.h>
int main()
{
	FILE *f1,*f2;
	int i=0,n=1;char ch,*f,num[4]="1234";
	f1=fopen("v2.txt","r");

	while((ch=fgetc(f1))!=EOF)
	{if(ch=="\n")
	n++;
	printf("%c",ch);
	}
	if(!f1)
	exit (0);
	else
	{
	char fn[100]="shread_1";
	while(fgets(f,100,f1)!=NULL)
	{
		fn[7]=num[i];
		i++;
		printf("%s",fn);
		f2=fopen(fn,"w");
		fprintf(f2,"%s",f);
		fclose(f2);
	}
	fclose(f1);
	}
}