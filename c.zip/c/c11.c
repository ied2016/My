#include<stdio.h>
int main()
{float income,tax;
printf("enter the income");
scanf("%f",&income);
if (income<200000){
    tax=0;
}
else if (200000<=income<400000)
{
    tax=income*(0.2);
}
else if (400000<=income<=600000)
{
    tax=income*(0.3);
}
else
{
    tax=income*(0.35);
}
printf("the tax rates=%f",tax);
return 0;
}
