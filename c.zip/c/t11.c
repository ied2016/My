#include<stdio.h>
int main()
{
	char a='A';
	int *p=(int*)&a;
	printf("\n%d\n",p);
	printf("%d\n",p+2);
}