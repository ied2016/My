#include <stdio.h>

struct st
{
	long  rollno;
	char name[51];
	int marks;		
};

int main()
{
	int i,j,t;
	int  temp;

	scanf("%d",&t);
	struct st a[t];
    int mark[t];
	for(i=0;i<t;i++)
	{
		scanf("%ld %s %d",&a[i].rollno,&a[i].name,&a[i].marks);
	}

	for(i=0;i<t;i++)
	{
		mark[i]=a[i].marks;
	}

	for(i=0;i<t;i++)
	{
		for(j=i+1;j<t;j++)
		{
			if(mark[i]<mark[j])
			{
				temp=mark[i];
				mark[i]=mark[j];
				mark[j]=temp;

		}
		}
	}

	for(i=0;i<t;i++)
	{
		for(j=0;j<t;j++)
		{
			if(mark[i]==a[j].marks)
			{
				printf("%ld %s %d\n",a[j].rollno,a[j].name,a[j].marks);
			}
		}
	}
	return 0;
}