#include<stdio.h>
int lsearch(int [],int,int);
int main()
{int i=0,pos,n,a[200],e;
printf("enter number of elements you want to add=");
scanf("%d",&n);
for(;i<n;i++)
scanf("%d",&a[i]);
scanf("%d",&e);
pos=lsearch(a,n,e);
printf("\nelement is at pos =%d",pos);
}
int lsearch(int a[],int size,int num)
{int i;
	for( i=0;i<size;i++)
	{if(a[i]==num)
	{return i+1;
	}
	else
	return -1;
	}
}
