#include<stdio.h>
int main()
{


int i,j;
scanf("%d %d",&i,&j);
		while (i!=j)
		{if(i>j)
		i-=j;
		else 
		j-=i;
		}printf("%d",i);
		return i; }
