#include<stdio.h>
int main()
{
	int i,j,*p1,*p2,n,count=0,flag=1,max=-1,pos2,pos;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
for(i=0;i<n;i++)
{	
	if(a[i]==0)
	{count=0;
	flag=1;
	p1=&a[i];
	pos=i;
	p2=p1;
	while( flag!=3 )
	{
	if(p1!=&a[0])
	{count+=1;
		p1--;}
	if(p2!=&a[n-1])
	{p2++;
	count+=1;}
	printf("\ncount=%d",count);
	if(*p1==0 )
	{flag+=1;
		if(flag==2)
	pos2=p1-(&a[0]);
	printf("\nflag in p2=%d\n",flag);
	}
	if(*p2==0)
	{
		flag+=1;
		pos2=*p2;
		if(flag==2)
		pos2=p2-(&a[0]);
		printf("\nflag in p2=%d\n",flag);
	}	}
	if(count>max)
	{max=count;
		printf("\npos1=%d  pos2=%d",pos,pos2);
printf("\nmax=%d\n",max);}
	}	}
}