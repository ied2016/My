#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <assert.h>
 
void insertionSort(int size, int arr[]) {
	int i,j,k,tmp,e;
 e=arr[size-1];
 
 for(i=size-1;i>0;i--)
  { if(arr[i]<arr[i-1])
  { tmp=arr[i];
   arr[i]=arr[i-1];
   arr[i-1]=tmp;
   for(k=0;k<size ;k++)
   {printf("%d",arr[k]);
}	 printf("\n");

	}

int main() {
   
   int size;
scanf("%d", &size);
int ar[size], i;
for(i = 0; i < size; i++) { 
   scanf("%d", &ar[i]); 
}

insertionSort(size, ar);
   
   
}

