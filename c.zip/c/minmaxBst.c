#include<stdio.h>
#include<stdlib.h>
struct BstNode{
	int data;
struct	BstNode* left;
struct	BstNode* right;
};
struct BstNode* root=NULL;
struct BstNode* savefirst;

struct BstNode* getnode(int data)
{
	struct BstNode* newNode=(struct BstNode*)malloc(sizeof(struct BstNode));
	newNode->data=data;
	newNode->left=NULL; 
	newNode->right=NULL;
	return newNode;
}



struct BstNode* insert(struct BstNode* root ,int data)
{
	if(root==NULL)
	root=getnode(data);
	else if(data<=root->data){
		root->left=insert(root->left,data);
	}
	else{
		root->right=insert(root->right,data);
	}
	printf("\nroot=%d     rootleft=%d     rootright=%d    ***data=%d",root,root->left,root->right,root->data);
	return root;
}


int Findmin(struct BstNode* root)
{if(root==NULL)
{printf("\nError : Tree is empty!!! ");
return -1;
}
else if(root->left==NULL)
{return root->data;
}
return FindMin(root->left);
}

int main()
{    
	int min;
	root=insert(root,15);
	savefirst=root;
	root=insert(root,10);
	root=insert(root,20);
	root=insert(root,25);
	root=insert(root,8);
	root=insert(root,12);
	int num;
	printf("\nsavefirst=%d",savefirst);
	printf("Enter Number to be searched = ");
	scanf("%d",num);
	root=savefirst;
	min=FindMin(root);
    printf("\nmin = %d   max= %d",min);
}
