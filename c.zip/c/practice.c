#include<stdio.h>
struct st{
	int i;
	float f;
	char c;
	char ch;
 	float f2;
};
void main()
{
	struct st o;
	int *p,i;
	p=&i;
	//printf("%d\n",sizeof(struct st));
	scanf("%d",p);
	printf(" %d ",i);
}