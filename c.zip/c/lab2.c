#include <stdio.h>
#include <string.h>
void partition(char arr[],int low,int high){

    int mid;

    if(low<high){
         mid=(low+high)/2;
         partition(arr,low,mid);
         partition(arr,mid+1,high);
         mergeSort(arr,low,mid,high);
    }
}

void mergeSort(char arr[],int low,int mid,int high)
{  
    int i,m,k,l,temp[1000];
    l=low;
    i=low;
    m=mid+1;
    while((l<=mid)&&(m<=high)){

         if(arr[l]<=arr[m]){
             temp[i]=arr[l];
             l++;
         }
         else{
             temp[i]=arr[m];
             m++;
         }
         i++;
    }

    if(l>mid){
         for(k=m;k<=high;k++){
             temp[i]=arr[k];
             i++;
         }
    }
    else{
         for(k=l;k<=mid;k++){
             temp[i]=arr[k];
             i++;
         }
    }
   
    for(k=low;k<=high;k++){
         arr[k]=temp[k];
    }
}
int main()
{
    int i,n,t,j,count=0,l,f=1;
    char s[200],*p,*p2;
    scanf("%d",&t);
   for(i=0;i<t;i++)
   {count=0;
    scanf("%s",&s);
    l=strlen(s)-1;
    partition(s,0,l);
    printf("%s",s);
    p=&s[0];
    p2=&s[1];
    for(j=0;j<l+1;j++)
    {
        if(*p==*p2)
            {count++;
                p++;
                p2++;
            }
        else
        {printf("\ncount=%d",count);
            if(count%2==0)
                f=0;
            else
                count=0;
            p2++;
            p++;
        }

    }

    if(f==0)
        printf("NO\n");
    else
        printf("YES\n");
   }
}