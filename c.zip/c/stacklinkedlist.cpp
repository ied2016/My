#include<stdio.h>
struct Node
{
	int data;
	struct Node* link;
};
struct Node* top = NULL;
void push(int x)
{
	struct Node* temp=(struct Node*)malloc(sizeof(struct Node*));
	temp->data=x;
	temp->link=top;
	top=temp;
}

void pop()
{
	struct Node* temp;
	if (top == NULL)
	return;
	temp=top;
	top=top->link;
	free(top);
}

int main()
{ 	printf("How many=");
	int n,i,e;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{printf("\nEnter no.=");
	scanf("%d",&e);
	push(e);}
 	pop(2);
   
   
  	}
