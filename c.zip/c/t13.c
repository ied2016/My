#include<stdio.h>
void change(int a)
{
	a+=4;
}
	int main ()
	{
   	 	char str[]="basic";
   	 	char *s=str;
   	 	printf("%s ",s++ +3);
   	 	printf("%s",s);	
   	 	int a=5;
   	 	change(a);
   	 	printf("\na=%d",a);
	}