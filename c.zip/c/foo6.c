#include <vector>
#include <stdio.h>
using namespace std;
int main()
{
int a[2]={1,2},i;
vector<int> v(a,a+4);
vector<int>::iterator iter=v.begin();
printf("v[0]=%d\n",*iter);
iter++;
printf("size=%d\n",v.size());
for(i=0;i<v.size();i++)
printf(" %d ",v[i]);
//iter=v.end()
}