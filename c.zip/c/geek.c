#include<stdio.h>
int main()
{
	int i,j,k,sum ,a[100],n;
	scanf("%d",&n);
	scanf("%d",&sum);
	
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
		for(i=0;i<n;i++)
			for(j=i+1;j<n;j++)
				for(k=j+1;k<n;k++)
				 if(a[i]+a[j]+a[k]<sum)
				  printf("\n%d,%d,%d",a[i],a[j],a[k]);
}
