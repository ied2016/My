#include<stdio.h>
void main() {
    int a[3][3],i,j,n=3;
 for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
        scanf("%d",&a[i][j]);
        }
    }
    
    if (n <= 1) {
        return; // nothing to do
    }

    /* layers */
    for (int i = 0; i < n / 2; i++) {
        /* elements */
        for (int j = i; j < n - i - 1; j++) {
            int saved = a[i][j];
            a[i][j] = a[n - j - 1][i];
            a[n - j - 1][i] = a[n - 1 - i][n - 1 - j];
            a[n - 1 - i][n - 1 - j] = a[j][n - 1 - i];
            a[j][n - 1 - i] = saved;
        }
    }
    for (i = 0; i < n; i++)
    {printf("\n");
        for (j = 0; j < n; j++)
        {
        printf(" %d ",a[i][j]);
        }
    }
}