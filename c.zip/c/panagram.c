#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

int main() {
int x[26]={0},i,c,ind,v=0;
char s[1000];
gets(s);
for(i=0;i<strlen(s);i++)
{s[i]=tolower(s[i]);
}
for(i=0;i<strlen(s);i++)
{   if('a'<=s[i]<='z')
	{
	ind=s[i]-'a';

	x[ind]=1;
}
if('A'<=s[i]<='Z')
	{
	ind=s[i]-'A';

	x[ind]=1;
}

 

}



for(i=0;i<26;i++)
{
if(x[i]==0)
c=1;

}
for(i=0;i<26;i++)
{
printf("%d",x[i]);
}
if(c==1)
printf("not pangram");
else 
printf("pangram");

}

