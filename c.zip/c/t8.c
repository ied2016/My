#include<stdio.h>
int main()
{
	int a[]={1,1,1};
	char ch='a';
	printf("%d \n%d \n%d\n",(a+0),a+1,a+2);
	long p,*ptr;
	p=a+0;
	p++;
	ptr=p;
	printf("\n\n%d",*ptr);
	ptr=&ch;
	printf("\nch=%d\n",ptr);

}