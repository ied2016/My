#include<stdio.h>
int main()
{
    int c=0,i=0,num,n,f;
    int arr[100000];
    scanf("%d",&n);
    for (i=0;i<n;i++)
    {
        scanf("\n%d",&num);
        arr[i]=num;}
        for (i =0;i<n;i++)
        {
		
		f=1;
        while (arr[i]>=1)
        {
            f=f*arr[i];
            arr[i]-=1;
        }
        printf("\n%d",f);
        while (f%10==0)
        {
            f=f/10;
            c+=1;
        }
        
        printf("%d",c);
        c=0;
    }
    for (i=0;i<n;i++)
    {printf("\n%d",arr[i]);
	}
return 0;
}
