#include<stdio.h>
int main()
{
	int i,j,pos,temp,n,k,a[100],*small,*ptr;
	for(i=0;i<5;i++)
	scanf("%d",&a[i]);
	
	for(i=0;i<5;i++)
	{	
		small=&a[0];
	for(j=i;j<5;j++)
	{
		if(*small>a[j])
		{		printf("\n small=%d ,a[j]=%d",*small,a[j]);

			temp=*small;
		*small=a[j];
		pos=j;
		printf("\n small=%d ,a[j]=%d",*small,a[j]);
		}
	a[i]=*small;
	a[pos]=temp;
	for(k=0;k<5;k++)
	printf("%d",a[k]);
	}
	}
	for(k=0;k<5;k++)
	printf("%d",a[k]);
}