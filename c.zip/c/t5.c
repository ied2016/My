#include<stdio.h>
	int main ()
	{
	    printf(5+"Good Morning\n");
	}