#include <stdio.h>
struct student{
    long roll;
    char name[200];
    int marks;
};
int main()
{
    int i,n,t;
    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
    struct student s[t];
    
        scanf("%ld %d %s",&s[i].roll,&s[i].name,&s[i].marks);
        }
    printf("Displaying information of students:\n\n");
    for(i=0;i<t;i++)
    {
     printf("\nInformation for roll number %ld:\n",s[i].roll);
     printf("Name: %s",s[i].name);
     printf("Marks: %d",s[i].marks);
   }
   return 0;
}