#include<stdio.h>
#include<stdlib.h>
#include<process.h>
#define newnode (struct node*) malloc(sizeof(struct node))

struct node
{
	int data;
	struct node *next;
};
struct node *create_list();
void main()
{
	struct node *f1,*f2;
	int len,reply;
	f1 = f2 = NULL;
	printf("\nEnter first list\n");
	f1 = create_list();
	printf("\nEnter second list\n");
	f2 = create_list();
	reply = compare(f1,f2);
	if( reply == 1 )
		printf("Both lists are same");
	else
		printf("Both lists are not same");
} // main

struct node *create_list()
{
	struct node *f,*c,*p;
	int tdata;	
	f = NULL;
	printf("\n Enter data ( use 0 to exit ) : ");
	scanf("%d",&tdata);
	while( tdata != 0 )
	{
	c = newnode;
	if( c == NULL)
	{
		printf("\n Insuf. mem. ");
		exit(0);
	}
	c->data = tdata;
	c->next = NULL;
	if( f== NULL)
		f = c;
	else
		p->next = c;
		p = c;
		printf("\n Enter data ( use 0 to exit ) : ");
		scanf("%d",&tdata);
	} //while
	return(f);
} // create list

int compare(struct node *f1, struct node *f2)
{
	int reply;
	struct node *t1,*t2;
	
	if( f1 == NULL && f2 == NULL)
	return(1);
	
	
	t1 = f1;
	t2 = f2;
	
	while( t1 != NULL && t2 != NULL)
	{
	if( t1->data != t2->data )
	break;
	t1 = t1->next;
	t2 = t2->next;
	}
	if( t1 == NULL && t2 == NULL)
	return(1);
	else
	return(0);
}
