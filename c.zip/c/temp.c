#include<stdio.h>
 int big(int a[] ,int *big);
int main()
{
	int a[]={1,2,8,4,5},n=5,val;
val=big(a,&val);
	printf("sum=%d",val);
	
	}
int big(int a[],int *big)
{
	int i,su=0;*big=a[0];
	for(i=0;i<5;i++)
	 if(*big<a[i])
	  *big=a[i];
	  	

return *big;

}
	
	
