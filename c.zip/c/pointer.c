#include<stdio.h>
int main()
{
	int *p,sum=0,a[5]={1,2,3,4,5},i=9;
	char a1[100]={'a','b','c','d','e'};
	//*p=i;

	p=&a[2];
    //p=&a1[0];
    //*p*=3;

    while(*p!='\0')
    {sum+=*p++;
	}
    p-=2;
    //int c=*p*4;
	printf("\na=%d  , p=%d",*p,sum);
}
