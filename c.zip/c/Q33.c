#include<stdio.h>
#include<string.h>
int main()
{char a[100];
	int c=0,k=0,i,j,l1;
		char b[900],out[100],prev;
char *p,*ptr=&out;

	scanf("%s",&a);
	printf("string=%s\n",a);
	l1=strlen(a);
	p=&a;
	for(i=0;i<l1;i++)
	{					printf("\nprev=%c\n",prev);
	
		if(*p==a[i])
		{
			c++;
			prev=*p;
		//	ch=*p;
			
		//	printf("\nc= %d p=%c \n",c,*p);

		}
		 if((*p)!=prev)
		{	printf("\nprev ===%c\n",prev);
			c=0;
			c+=1;
			
		}
	
	p++;
		printf("c=%d *p=%c\n",c,*p);
	}
	//printf("out=%s",out);
}