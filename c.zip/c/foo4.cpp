#include <iostream>
#include <stdio.h>
#include <string>
using namespace std;
int main()
{	char str[100]="iiitd",str2[100],str3[100],firstname,last,fullname[];
	//printf("%s\n",str);
	//cout<<str;
	//str2=str;
	//str[]="..."
	cin>>firstname;
	cin>>last;
	string full[]=firstname+" "+last;
	//	printf("\nstr2=%s str1=%s \n",str2);

	printf("%s\n",fullname);
	return 0;
}