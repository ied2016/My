#include<stdio.h>
int main()
{
	int a[200],i,c=0;
	for(i=0;i<20;i++)
	{scanf("%d",&a[i]);
	}
   	
		for(i=0;i<20;i++)
	{if (a[i]>=85){
	
	c+=1;}
	}
	printf("no. of hot days=%d",c);
	
}
