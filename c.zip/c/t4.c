#include<stdio.h>
int main()
{
	int *p1,**p2;
	double *q1,**q2;
	printf("\np1=%d p2=%d ",sizeof(p1),sizeof(p2));
	printf("\n q1=%d q2=%d",sizeof(q1),sizeof(q2));
}