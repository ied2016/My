#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int a; 
    int b; 
    int c; 
    int d; 
    scanf("%d %d %d %d",&a,&b,&c,&d);
 
 if (a-b)



}

