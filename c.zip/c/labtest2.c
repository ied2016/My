#include <stdio.h>
#include <string.h>
#include <stdlib.h>
char* checkfunny(char* s)
{
	char rev[1111],temp;
	int a1,a2,i,j,count=0;
	strcpy(rev,s);
	i = 0;
    j = strlen(rev)-1;
   while (i < j) {
      temp = rev[i];
      rev[i] = rev[j];
      rev[j] = temp;
      i++;
      j--;
   }
	for(i=0;i<strlen(s);i++)
	{
		a1=s[i]-s[i-1];
		a2=rev[i]-rev[i-1];
		if(abs(a1)==abs(a2))
		{
			count++;
		}
	}
	if(count==strlen(s)-1)
		return "Funny";
	else
		return "Not Funny";
}
void main()
{
	int t,n,i,j;
	char str[1111],ret[100];
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
		scanf("%s",str);
		strcpy(ret,checkfunny(str));
		printf("%s",ret);
	}
}