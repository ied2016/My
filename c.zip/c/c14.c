#include<stdio.h>
int main()
{int prdno,qty,sum=0,i=1;
printf("enter the product number =");
scanf("%d",&prdno);
if(prdno==1)
{


for (i=1;i<=7;i++)
{
    printf("\nenter quantity sold for day %d=",i);
    scanf("%d",&qty);
    sum+=qty*20;
}}
else if(prdno==2)
{


for (i=1;i<=7;i++)
{
    printf("\nenter quantity sold for day %d=",i);
    scanf("%d",&qty);
    sum+=qty*40;
}}
else if(prdno==3)
{


for (i=1;i<=7;i++)
{
    printf("\nenter quantity sold for day %d=",i);
    scanf("%d",&qty);
    sum+=qty*90;
}}
else if(prdno==4)
{


for (i=1;i<=7;i++)
{
    printf("\nenter quantity sold for day %d=",i);
    scanf("%d",&qty);
    sum+=qty*45;
}}
else if (prdno==5)
{


for (i=1;i<=7;i++)
{
    printf("\nenter quantity sold for day %d=",i);
    scanf("%d",&qty);
    sum+=qty*60;
}
}
printf("\nThe total retail value of each product sold on weekly basis=%d",sum);
return 0;
}
