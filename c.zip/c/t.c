#include<stdio.h>
int main()
{int i=0,j=0,pos,n,a[200],tmp,small=0;
for(i=0;i<5;++i)
{printf("%d\n",i);
}
}
