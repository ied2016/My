#include<stdio.h>
#include<stdlib.h>  
int main()
{
   char c[1000],ch,a[1000];
   int i=0,cnt=0,j=0,n=0;
   FILE *f1ptr;
   f1ptr=fopen("q1.txt","w");
   if(f1ptr==NULL){
      printf("Error!");
      exit(1);
   }
   printf("Enter a file name:\n");
   gets(c);
      FILE *newf1,*newf2;
      newf1=fopen("c","r");
   newf2=fopen("c","w");
   printf("%s",c);
if(!c)
{
  printf("file not exist!\n");
}
   while((ch=getc(newf1))!=EOF)
   {
    if(ch=='\n')
      n+=1;
  printf("\n i'm in\n");
   }
   printf("\nn=%d",n);


      fclose(f1ptr);
   fclose(newf1);
   return 0;
}