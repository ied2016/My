#include<stdio.h>
#include<stdlib.h>

void insertionSort(int size, int arr[]) {
	int i,j,k,tmp;
	for(i=1;i<size ;i++)
	{tmp=arr[i];
	j=i-1;
	while(tmp < arr[j])
	{
		arr[j+1]=arr[j];
		j--;
	}
	arr[j+1]=tmp;
}}

struct Node{
	int data;
	struct Node* next;
};
struct Node* head=NULL;
void insert(int e)
{
	struct Node* temp=malloc(sizeof(struct Node));
	temp->data=e;
	temp->next=head;
	head=temp;
	printf("\naddr= %p \n",head);
}
void print()
{ struct Node* temp;
          temp=head;
	printf("List is= ");
	while(temp!=NULL)
	{
		printf("%d ",temp->data);
		temp=temp->next;
	}
	printf("\n");
}

int main()
{
	printf("How many=");
	int n,i,e;
	scanf("%d",&n);

	for(i=0;i<n;i++)
	{printf("\nEnter no.=");
	scanf("%d",&e);
	insert(e);
	}

	printf("\n magic= %p ",head->next->next->next->next); 
	print();
}
