#include<stdio.h>
int main()
{
	int n,k=0,i,j,c;
	int a[30],b[30],count[1000],l=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for (i=0;i<n;i++)
	{ c=0;
		for (j=0;j<n;j++)
		{
			if(a[i]==a[j])
			{c+=1;
	
			}
		}
		count[i]=c;
		if (c==1)
		{b[k++]=a[i];
		
		}
		
	}
		for(i=0;i<=k-1;i++)
	{
		printf("\nunique no.=%d",b[i]);}
	for(i=0;i<=n;i++)
	{
	
		printf("\n\nelement=%d, count=%d",a[i],count[i]);
		
		
	}
	return 0;
}
