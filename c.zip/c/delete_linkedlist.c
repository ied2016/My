#include<stdio.h>
#include<stdlib.h>
struct Node
{
    int  data;
    struct Node* next;
}  ;
void insert(int lnum,struct Node** head )
{ struct Node* temp=(struct Node*)malloc(sizeof(struct Node));
temp->data=lnum;
temp->next=*head;
*head=temp;
}

struct Node* del(int num,struct Node* head)
{
	struct Node* saveaddr;
	struct Node* savenext;
    struct Node* backup=head;
    
	if(num==head->data)
{
	struct Node* h;
	h=head->next;
    free(head);
    return h;
}
	else
    {
	while(head->data!=num)
	{ 
		head=head->next;
	}
		saveaddr=head;
		savenext=head->next;
		free(head);	
		while(backup->next!=saveaddr)
		{
			backup=backup->next;	
		}
		backup->next=savenext;
		return 0;
	}
}

void display(struct Node* head)
{ 
	while(head!=NULL)
	{ 
		printf(" %d ",head->data);
		head=head->next;
	}
}

int main()
{int i,j,k,n,num,e;
char c='y';
struct Node* r;
struct Node* head=NULL;
printf("How many no. you Want to insert=");
scanf("%d",&n);
for(i=0;i<n;i++)
{
	printf("Enter the element no.%d =",i+1);
	scanf("%d",&num);
	insert(num, &head);
}
	printf("\nYour current linked list is = ");
	display(head);
	while(c=='y'){
	printf("\nEnter the element you want to delete = ");
	scanf("%d",&e);
	r=del(e,head);
	if(r!=0)
	{head=r;
	}
	printf("\nYour New linked list is = ");
	display(head);
	printf("\nDo you want to delete more element(y/n)=");
	scanf("%s",&c);
	}
}
