#include<stdio.h>
#include<stdlib.h>
struct Node
{
    int  data;
    struct Node *next;
}  ;
struct Node* head;
//void create(int );
//void display();
int main()
{
	head=NULL;
	int inf,n,i;
	printf("Enter no. of elements=");
    	scanf("%d",&n);
    	for(i=0;i<n;i++)
    	{printf("\nEnter %d element=",i+1);
	scanf("%d",&inf);	
	create(inf);
	display();
}  	
	}
void create(int x)
	{
	struct	Node* temp;
	temp=(struct Node*)malloc(sizeof(struct Node));

		temp->data=x;
		temp->next=head;
		head=temp;	

	}
void display()
{struct Node* temp=head;

while(temp!=NULL)
{	
printf("->%d",temp->data);
temp=temp->next;
}
}
