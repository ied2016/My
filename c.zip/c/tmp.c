#include<stdio.h>
int main()
{int i=0,j=0,pos,n,a[200],tmp,small=0;
printf("enter number of elements you want to add=");
scanf("%d",&n);
for(;i<n;i++)
scanf("%d",&a[i]);
for(i=0;i<n;i++)
{pos=i;
small=a[i];
for(j=i+1;j<n;j++)
{
	if(a[j]<small)
	{small=a[j];
	 pos=j;
	 printf("\n==%d",small);
	}
}
tmp=a[i];
a[i]=a[pos];
a[pos]=tmp;
}
for(i=0;i<n;i++)
printf("\n%d",a[i]);
}
