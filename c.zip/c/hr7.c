#include<stdio.h>
int main()
{ int i,j,n,t,a[1000000],sl=0,sr=0,f=0,l,r;
scanf("%d",&t);
for(j=0;j<t;j++)
{   f=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{   
	sl=0;
	sr=0;
	l=i-1;
	r=i+1;
	if(i==0||i==n-1||l<0||r>=n)
	{sl=0;
	sr=0;
	}
	else
	{
		while(l>=0)
		{
			sl+=a[l--];
		 } 
		 while(r<n)
		 {sr+=a[r++];
		 }
		if(sl==sr)
		f=1;}
	}
	if(f==1)
	printf("YES");
	else
	printf("NO");
	printf("\n");	
}}
