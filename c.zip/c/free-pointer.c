#include<stdio.h>
int main()
{
	int a[]={1,2,3,4,5};int *p=a,i;
	printf("first=%d",*p);
	while(*p<5)
	{if(*p%3!=0)
	free(p);
	}
	for (i=0;a[i]!='\0';i++)
	  printf("\ne=%d",a[i]);
}
