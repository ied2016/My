#include<stdio.h>
#include<stdlib.h>
struct BstNode{
	int data;
struct	BstNode* left;
struct	BstNode* right;
};

struct BstNode* root=NULL;
struct BstNode* savefirst;

int search(int data)
{
	if(root==NULL)
	return 0;
	
	else if(root->data==data)
	return 1;
	
	else if (data<=root->data)
{
		root=root->left;
	return search(data);
}
	else 
	{
	root=root->right;
	return search(data);}
}	

int fkmin(struct BstNode* root)
{if(root==NULL)
{printf("\nError : Tree is empty!!! ");
return -1;
}
else if(root->left==NULL)
{return root->data;
}
return fkmin(root->left);
}

struct BstNode* getnode(int data)
{
	struct BstNode* newNode=(struct BstNode*)malloc(sizeof(struct BstNode));
	newNode->data=data;
	newNode->left=NULL; 
	newNode->right=NULL;
	return newNode;
}

struct BstNode* insert(struct BstNode* root ,int data)
{
	if(root==NULL)
	root=getnode(data);
	else if(data<=root->data){
		root->left=insert(root->left,data);
	}
	else{
		root->right=insert(root->right,data);
	}
	printf("\nroot=%d     rootleft=%d     rootright=%d    ***data=%d",root,root->left,root->right,root->data);
	return root;
}

int main()
{

	root=insert(root,15);
	savefirst=root;
	root=insert(root,10);
	root=insert(root,20);
	root=insert(root,25);
	root=insert(root,8);
	root=insert(root,12);
	int num,min;
/*	printf("\nsavefirst=%d",savefirst);
	printf("Enter Number to be searched = ");
	scanf("%d",num);*/
	root=savefirst;
/*	if(search(num)==1)
	printf("\nFound");
	else
	printf("\nNot Found");*/
		min=fkmin(root);
    printf("\nmin = %d   ",min);
}
