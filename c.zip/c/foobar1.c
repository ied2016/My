#include <stdio.h>
int main()
{
	int i,n,t,j,socks,sum=0,rem;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{	sum=0;
		scanf("%d",&n);
		int a[n];
		for(j=0;j<n;j++)
		scanf("%d",&a[j]);
		for(j=0;j<n;j++)
		{
			rem=a[j]%3;
			socks=(a[j]-rem)/3;
			sum+=socks;
		}
		printf("%d",sum);
	}
} 