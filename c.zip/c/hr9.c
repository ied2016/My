#include<stdio.h>
int main()
{
	int i,j,n,t,a,b,c,sum=0;
	scanf("%d %d %d",&a ,&b,&c);
	if(a+b+c==42){
		printf("%d+%d+%d",a,b,c);
	}
	else 	if(a*b*c==42){
		printf("%d*%d*%d",a,b,c);
	}
	else 	if(a+b*c==42){
		printf("%d+%d*%d",a,b,c);
	}
	else 	if(a*b+c==42){
		printf("%d*%d+%d",a,b,c);
	}
	else 
	printf("This is not the ultimate question");
	
}
