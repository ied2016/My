# include <stdio.h>
# include <string.h>
int main()
{
	int t,i,j,k,f=1,l,mark=0;
	char s[111],temp;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{mark=0;
	scanf("%s",&s);
	l=strlen(s);
	for(j=0;j<l;j++)
	{
	for(k=0;k<l;k++)
	{
	if(s[j]==s[k]&&(j!=k))
	{
	s[j]='*';
	s[k]='*';
	break;
	}
}
}
for(k=0;k<l;k++)
{
	if(s[k]!='*')
		mark=1;
}
	if(mark==1)
		printf("NO\n");
	else 
		printf("YES\n");
	}
	return 0;
}