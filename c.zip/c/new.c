#include<stdio.h>
#include<stdlib.h>
int main()
{
	int i=10,j=1000;
	printf(" %d ",i);
	delay(1000);
	printf("\n %d ",j );
}