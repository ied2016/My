#include<stdio.h>
int main()
{
	int val=10;
	void *p=&val;
	int *ptr=p;
	//p++;
	printf("\n*p=%d \n",*p);
}