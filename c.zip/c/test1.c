#include<stdio.h>
#include<string.h>
void main()
{
char a[30];
printf("Enter string : ");
scanf("%s",&a);
strrev(a);

printf("Reversed String : %s",a);

}