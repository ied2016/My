#include<stdio.h>
int main()
{
	int i;
	char s[234];
	scanf("%[^\t]s",s);
	printf("\n%s",s);
}