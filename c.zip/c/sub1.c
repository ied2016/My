#include<stdio.h>
#include<ctype.h>
#include<string.h>
int main()
{
	int i,j,k=0,n,al,c=0,r=0;
	scanf("%d",&n);
	char s[n+1][n+1],str[10],*p,*ptr,*rev;
	for(i=0;i<n;i++){
		scanf("%s",s[i]);
}
ptr=&s;
	/*for(i=0;i<=n;i++)
	for(j=0;j<=n;j++)
	a[i][j]=tolower(a[i][j]);
	*/
	printf("\n");
	
	for(i=0;i<n;i++)
		{printf("\n");
	for(j=0;j<n;j++)
	printf(" %c  pos->i=%d j=%d",*(*(s+i)+j),i,j);
}
scanf("%s",str);
ptr=&str;
rev=&str;
	
	for(i=0;i<n;i++)
	{
	for(j=0;j<n;j++)
	{if(*(*(s+i)+j)==*ptr)
	{
		p=ptr;
		ptr++;
		c++;
	printf("\nc=%d\n",c);
	if(*(*(s+i)+j+1)!=*(p++)||*(*(s+i+1)+j)!=*(p++)||*(*(s+i)+j-1)!=*(p++)||*(*(s+i-1)+j)!=*(p++))
		return printf("NO");

}	
	else if((*(*(s+j)+i))==*rev)
	{
		rev++;
		r++;
	printf("\nc=%d\n",r);
	}
}}
if(c==strlen(str))
printf("Yes\n");
else 
printf("\nNO\n");
	
}
