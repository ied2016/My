#include<stdio.h>
int main()
{
	int i,a,b,j,n;
	scanf("%d %d %d",&a,&b,&n);
	double ar[900];
	ar[0]=a;
	ar[1]=b;
	for(i=2;i<n;i++)
{
     ar[i]=ar[i-1]*ar[i-1]+ar[i-2];	
	}	
	for(i=0;i<n;i++)
	printf("%d  ",ar[i]);
}
