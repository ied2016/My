#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>
int gcd (int A ,int D)
{
int i=A,j=D;
		while (i!=j)
		{if(i>j)
		i-=j;
		else 
		j-=i;
		}printf("%d",i);
		return i; }
		

int main(){
    int a,b,c,d,w,g=0; 
    int x; 
    int y; 
    int z; 
    scanf("%d %d %d %d",&w,&x,&y,&z);
 for(a=1; a<=w;a++){
  for(b=1; b<=x;b++){
  	 for(c=1; c<=y;c++){
  	 	 for(d=1; d<=z;d++){
  	 	 	printf("\na=%d, b=%d ,c=%d ,d=%d \n",a,b,c,d);
 if ((a-b)%3==0 && (b+c)%5==0 && (a*c)%4==0 && (gcd(a,b)==1))
 {
 g++;}
}}}}
printf("%d",g);

}

