#include<stdio.h>
int main()
{
	int a,b,c,hyp[100],n,i,ind=0;
	scanf("n=%d",&n);
	for(a=1;a<=n;a++)
	{for(b=a+1;b<=n;b++)
	{
	for(c=b+1;c<=n;c++)
	{
	
	if(((a*a)+(b*b))==(c*c))
	{if(c<=n)
{
		printf("a=%d, b=%d, c=%d\n",a,b,c);}
	hyp[ind++]=c;
	}
}}}
for(a=0;a<=ind-1;a++)
{if(hyp[a]<=n)
	{
	printf("%d\n",hyp[a]);}
}
return 0;
}
