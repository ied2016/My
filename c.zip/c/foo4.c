#include <iostream.h>
int main()
{
	cout<<"Hello World";
	return 0;
}