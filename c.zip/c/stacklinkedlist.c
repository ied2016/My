#include<stdio.h>
struct Node
{
	int data;
	struct Node* link;
};
struct Node* top = NULL;
struct Node* savelink;
void push(int x)
{
	struct Node* temp=(struct Node*)malloc(sizeof(struct Node*));
	temp->data=x;
	temp->link=top;
	top=temp;
	savelink=top;
}

void pop()
{
	struct Node* temp;
	if (top == NULL)
	return;
	temp=top;
	savelink=top->link;
	free(top);
}
void display()
{	struct Node* temp;
temp=savelink;
while(temp!=NULL)
{printf("\n==%d  next=%d\n",temp->data,temp->link);
temp=temp->link;
}
}
int main()
{ 	printf("How many=");
	int n,i,e;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{printf("\nEnter no.=");
	scanf("%d",&e);
	push(e);} display();
	push(23);display();
	
pop();display(); 
  	}
