#include<stdio.h>
int main()
{int i ,j,st=1,n,sp=4,sp2=1;
scanf("%d",&n);
int st2;
st2=n-2;
for(j=0;j<=n;j++)
{

if (j<=n/2)
{ 

for(i=1;i<sp;i++)
{
	printf(" ");
}

for(i=0;i<st;i++)
	{
	  printf("*")	;
	}printf("\n");
sp--;
st+=2;
 }
 
 if(j>n/2&&j<n)
 {
 	for(i=0;i<sp2;i++)
 	{printf(" ");
 		
	 }
 	for (i=0;i<st2;i++)
 	{
 		printf("*");
	 }printf("\n");
	 sp2++;
	 st2-=2;
 	
  } 
	 
}
	
}
