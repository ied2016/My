#include<stdio.h>
#include<string.h>
int mian()
{int i,n,j,f=1,sd,rd;
char s[100],r[100];
scanf("%d",&n);
for(i=0;i<n;i++)
{    f=1;
	scanf("%s",s);
	r=strrev(s);
	for(j=1;j<strlen(s);j++)
	{
	sd=s[i]-s[i-1];
	rd=r[i]-r[i-1];
	if(sd!=rd)
	f=0;	
	}
	if(f==1)
	printf("funny");
	else
	printf("not funny");
}

}
