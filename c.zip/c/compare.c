#include<stdio.h>
#include<string.h>
int compare(char *s1,char *s2,int l)
{
	int f=1,i;
	for(i=0;i<l;i++)
	{
		if(*s1!=*s2)
		{
			f=1;
			return 0;
		}
		s1++;
		s2++;
	}
	return f;
}
int main()
{char a[100],b[100];
int ans,l1;
gets(a);
gets(b);
l1=strlen(a);
ans=compare(a,b,l1);
printf("ans=%d",ans);
}
