#include <stdio.h>
void insertionSort(int size, int arr[]) {
	int i,j,k,shift=0,tmp;
	for(i=1;i<size ;i++)
	{tmp=arr[i];
	j=i-1;
	while(tmp < arr[j])
	{shift++;
		arr[j+1]=arr[j];
		j--;
	}
	arr[j+1]=tmp;
}}
int main(void) {
   
   int size;
scanf("%d", &size);
int ar[size], i;
for(i = 0; i < size; i++) { 
   scanf("%d", &ar[i]); 
}

insertionSort(size, ar);
   for(i=0;i<size;i++)
   	printf("%d",ar[i]);
   return 0;
}
