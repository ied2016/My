#include<stdio.h>
int main()
{
	int a[6],i,j,temp;
	for (i=0;i<5;i++)
	{scanf("%d",&a[i]);
	temp=a[i];	
	int rev=0;
	while(temp!=0)
	{
	rev*=10;
	rev+=temp%10;
	temp/=10;	
	}
	a[i]=rev;
	printf("\n ee==%d  \n",a[i]);
} 
       for(i=0;i<5;i++)
       {printf("\n%d =",a[i]);
	   }

int end=4;
	for (i=0;i<5/2;i++)
	{
	temp=a[i];
	a[i]=a[end];
	a[end]=temp;
	end--;
		}
	for (i=0;i<5;i++)
	{printf("\n ee==%d",a[i]);
	}
}

