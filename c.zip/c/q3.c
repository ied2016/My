#include<stdio.h>
int main()
{
	int i,j,l,m,k,temp;
	int tc;
	scanf("%d",&tc);

	for(i=0;i<tc;i++)
	{
	scanf("%d",&l);
	int a[100],*po1,*po2;
		for(j=0;j<l;j++)
		{
			scanf("%d",&a[j]);
		}
		po1=&a[0];
		po1++;
		po2=po1;
		po1=&a[0];
		
	
		for(k=0;k<l/2;k++){
		
		temp=*po1;
	

		*po1=*po2;
		*po2=temp;
		po1+=2;
		po2+=2;}
		
	
	for(m=0;m<l;m++)
	{printf(" %d ",a[m]);
	}
	
	}
	}
	

	
