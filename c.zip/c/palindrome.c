#include<stdio.h>
#include<string.h>
int main()
{
	int i,j,c=1;
	char a[80];
	gets(a);
	for(i=0,j=strlen(a)-1;i<strlen(a),j>=0;i++,j--)
	{
		if(a[i]!=a[j])
		 c=0;
	}
	printf("strlen=%d",strlen(a));
	if (c==0)
	 printf("\nnot");
	else 
	 printf("\n yes");
}
