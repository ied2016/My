#include <iostream>
#include <stack>
using namespace std;
int main()
{
	stack<int> s;
	string input;
	cin>>input;
	s.push(2);
	s.pop();
	int a=s.pop();
	/*if(s.empty())
	{

	}*/
	for(i=0;i<input.size();i++)
	{
		if(input[i]==s.top())
			s.pop();
		else
			s.push(input[i]);
	}
	return 0;
	//sort(iter1,iter2)
	//binary_search(iter1,iter2,value)
	//sort(v.begin,v.end(),show)
}