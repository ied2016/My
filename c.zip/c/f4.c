#include<stdio.h>
#include<ctype.h>
int main()
{
	int i=0,j,k,l;
	char ch,a,b,s[453];
	FILE *f1,*f2;
	f1=fopen("f2.c","r");
	f2=fopen("new2.c","w");
	fscanf(f1,"%s",s);
	//while((ch=getc(f1))!=EOF)
	//{
		fprintf(f2,"%s",ch);

	//}
	fclose(f1);
	fclose(f2);
}