#include<stdio.h>
void main()
{
    int i=4,j=1,a,b;
	printf("***");
while(i>=0 || j<=9)
{
    	for(a=0;a<i;i++)
	 printf(" ");
	for(b=0;b<j;b++)
     printf("* \n");
    i--;
    j+2;
}
    return 0;
}
