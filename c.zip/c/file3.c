#include <stdio.h>
#include <stdlib.h>
int main()
{
	int i=0;
	FILE *f1,*f2;
	f1=fopen("file.txt",'r');
	char fn[]="shread_1.txt",a[]="1234",ch,c;
	if(f1==NULL)
	{
		printf("FILE Don't Exist!!!");
		exit(0);
	}
	else{
		while(c=fgetc(f1)!=EOF)
		{	
			fn[7]=a[i++];
			f2=fopen(fn,'w');
			while(c!='\n'||c==EOF)
			{	
				//ch=fgetc(f1);
				fputc(c,f2);
			}
			fclose(f2);
		}
	}
	fclose(f1);
}