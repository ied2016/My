#include <iostream>
002
#include <Windows.h>
003
using namespace std;
004

005
struct Player
006
{
007
    int x, y;
008
    Player()
009
    {
010
        x = -1;
011
        y = -1;
012
    }
013
};
014

015
struct Ghost
016
{
017
    int x, y, direction;
018
    Ghost()
019
    {
020
        x = -1;
021
        y = -1;
022
        direction = 1;
023
    }
024
};
025

026
const char SYMBOL_EMPTY = ' ';
027
const char SYMBOL_PLAYER = '@';
028
const char SYMBOL_GHOST = 'G';
029
const char SYMBOL_WALL = '#';
030
const int MapDx = 10;
031
const int MapDy = 20;
032
const int GameSpeed = 100;
033
const int LEFT = 1;
034
const int RIGHT = 2;
035
const int UP = 3;
036
const int DOWN = 4;
037
int direction = RIGHT;
038

039
char map[10][20] =
040
{
041
    "###################",
042
    "#                 #",
043
    "#                 #",
044
    "#                 #",
045
    "#                 #",
046
    "#                 #",
047
    "#                 #",
048
    "#                 #",
049
    "###################"
050
};
051

052
bool isValidPos(int x, int y)
053
{
054
    return (x >= 0 && x < MapDx && y >= 0 && y < MapDy);
055
}
056

057
bool movePlayer(Player &player, int x, int y)
058
{
059
    if (!isValidPos(x, y))
060
    {
061
        return false;
062
    }
063

064
    char ch = map[x][y];
065

066
    if(ch != SYMBOL_EMPTY)
067
    {
068
        return false;
069
    }
070

071
    if (isValidPos(player.x, player.y))
072
    {
073
        map[player.x][player.y] = SYMBOL_EMPTY;
074
    }
075
    player.x = x; player.y = y;
076
    map[player.x][player.y] = SYMBOL_PLAYER;
077
    return true;
078
}
079

080
bool moveGhost(Ghost &ghost, int x, int y)
081
{
082
    if (!isValidPos(x, y))
083
    {
084
        return false;
085
    }
086

087
    char ch = map[x][y];
088

089
    if (ch != SYMBOL_EMPTY)
090
    {
091
        return false;
092
    }
093

094
    if (isValidPos(ghost.x, ghost.y))
095
    {
096
        map[ghost.x][ghost.y] = SYMBOL_EMPTY;
097
    }
098
    ghost.x = x; ghost.y = y;
099
    map[ghost.x][ghost.y] = SYMBOL_GHOST;
100
    return true;
101
}
102

103
void GhostAI(Ghost &ghost, Player &player)
104
{
105
    double a = sqrt((pow((double) (ghost.x - 1) - player.x, 2)) + pow((double) ghost.y - player.y, 2)); //UP
106
    double b = sqrt((pow((double) (ghost.x + 1) - player.x, 2)) + pow((double) ghost.y - player.y, 2)); //DOWN
107
    double c = sqrt((pow((double) (ghost.y - 1) - player.x, 2)) + pow((double) ghost.x - player.y, 2)); //RIGHT
108
    double d = sqrt((pow((double) (ghost.y + 1) - player.x, 2)) + pow((double) ghost.x - player.y, 2)); //LEFT
109
    if(a < b && a <= c && a <= d && ghost.direction != DOWN) ghost.direction = UP;
110
    else if(b <= c && b <= d && ghost.direction != UP) ghost.direction = DOWN;
111
    else if(c < d && ghost.direction != LEFT) ghost.direction = RIGHT;
112
    else if(ghost.direction != RIGHT) ghost.direction = LEFT;
113
}
114

115
void showMap()
116
{
117
    for (int x = 0; x < MapDx; x++)
118
    {
119
        cout << map[x] << endl;
120
    }
121
}
122

123
void showPlayer(Player &player)
124
{
125
    cout << "\nPlayerX: " << player.x << endl;
126
    cout << "PlayerY: " << player.y << endl;
127
}
128

129
void gameLoop()
130
{
131
    Player player;
132
    Ghost ghosts[3];
133
    movePlayer(player, 1, 2);
134
    moveGhost(ghosts[0], 5, 2);
135
    moveGhost(ghosts[1], 5, 5);
136
    moveGhost(ghosts[2], 5, 8);
137
    while (true)
138
    {
139
        system("cls");
140
        showMap();
141
        showPlayer(player);
142
        if (GetAsyncKeyState(VK_UP))
143
        {
144
            direction = UP;
145
        }
146
        else if (GetAsyncKeyState(VK_DOWN))
147
        {
148
            direction = DOWN;
149
        }
150
        else if (GetAsyncKeyState(VK_LEFT))
151
        {
152
            direction = LEFT;
153
        }
154
        else if (GetAsyncKeyState(VK_RIGHT))
155
        {
156
            direction = RIGHT;
157
        }
158
        switch (direction)
159
        {
160
        case UP:
161
            movePlayer(player, player.x-1, player.y);
162
            break;
163
        case DOWN:
164
            movePlayer(player, player.x+1, player.y);
165
            break;
166
        case LEFT:
167
            movePlayer(player, player.x, player.y-1);
168
            break;
169
        case RIGHT:
170
            movePlayer(player, player.x, player.y+1);
171
            break;
172
        }
173
        for (int ghost = 0; ghost < 3; ghost++)
174
        {
175
            GhostAI(ghosts[ghost], player);
176
            switch (ghosts[ghost].direction)
177
            {
178
            case UP:
179
                moveGhost(ghosts[ghost], ghosts[ghost].x-1, ghosts[ghost].y);
180
                break;
181
            case DOWN:
182
                moveGhost(ghosts[ghost], ghosts[ghost].x+1, ghosts[ghost].y);
183
                break;
184
            case LEFT:
185
                moveGhost(ghosts[ghost], ghosts[ghost].x, ghosts[ghost].y-1);
186
                break;
187
            case RIGHT:
188
                moveGhost(ghosts[ghost], ghosts[ghost].x, ghosts[ghost].y+1);
189
                break;
190
            }
191
        }
192
        Sleep(GameSpeed);
193
    }
194
}
195

196

197
int main()
198
{
199
    gameLoop();
200
    return 0;
201
}
