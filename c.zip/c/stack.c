#include<stdio.h>
#include<stdlib.h>
#define msize 1000
#define sz 1000
int a[msize],b[sz];
int top=-1,top2=-1;
void push(int x)
{if(top==msize-1)
{printf("\nStack overflow ");
return;
}
a[++top]=x;
}

void push2(int x)
{if(top2==sz-1)
{printf("\nStack overflow ");
return;
}
b[++top2]=x;
}

void pop()
{if(top==-1)
{printf("\nError: Stack is empty!!!");
return;
}
top--;
}
void print()
{int i;
for(i=0;i<=top;i++)
{printf("\nElemten %d is = %d ",i+1,a[i]);
}
}
void main()
{
	printf("Enter the size of the array you want= ");
	int size,n,choice,i;
	
	scanf("%d",&size);
	printf("\nEnter the first element");
	scanf("%d",&n);
	push(n);
	for(i=1;i<size;i++)
{
	scanf("%d",&n);
	if(n>a[top])
		push2(n);
	else
		push(n);
}
	printf("\nYour required element is =%d ",a[top]);	
}