#include <stdio.h>
void merge(int a[],int x,int y,int z)
{
	int k,i,j,n1,n2;
	n1=y-x+1;
	n2=z-y;
	int l[x+1],R[y+1];
	for(i=0;i<n1;i++)
		l[i]=a[x+i-1];
	for(j=0;j<n2;j++)
		R[j]=a[y+j];
	l[n1]=R[n2]=10000;
	i=j=1;
	for(k=x;k<z;k++)
	{
		if(l[i]<R[j])
		{
			a[k]=l[i];
			i++;
		}
		else if(l[i]>R[i])
		{
			a[k]=R[j];
			j++;
		}
	}
}

void mergesort(int a[],int f,int b)
{int q;
if(f<b)
	{q=(f+b)/2;
mergesort(a,f,q);
mergesort(a,q+1,b);
merge(a,f,q,b);
}
}
int main()
{
	int p,r,n,i;
	scanf("%d",&n);
	int a[n];
	for( i=0;i<n;i++)
		scanf("%d",&a[i]);

	p=0;
	r=n-1;
	mergesort(a,p,r);
		for( i=0;i<n;i++)
		printf(" %d ",a[i]);
}