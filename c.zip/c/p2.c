#include<stdio.h>
int main()
{
	int a[]={1,2,3,4,5};int *p=&a[0],*q=&a[4],temp,i;
	while(p<q)
	{temp=*p;
	*p++=*q;
	*q--=temp;
	printf("\np=%d  ,q=%d",*p,*q);	}
	      for(i=0;i<5;i++)
	      {printf("\n\n=%d",a[i]);
		  }
}




