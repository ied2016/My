#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>
int main(){
    int t,i,j; 
    scanf("%d",&t);
    for(i = 0; i < t; i++){
        int n; 
        scanf("%d",&n);
     int h=1,m=1;
     if(n==0)
      printf("%d\n",1);
     else
   {  for(j=0;j<n;j++)
      {
      if(m==1)
      {h*=2;m*=-1;}
     else
      {h+=1;m*=-1;printf("\n==%d",h);}
      }
     printf("%d\n",h);
   }
    }
    return 0;
}
