#include<stdio.h>
int main()
{
	int i=4,j=1,a,b;
	while(i>=0||j<=5)
	{
		for (a=0;a<=i;a++)
		{
			printf(" ");
		}
		for (b=0;b<j;b++)
		{
			printf("*");
		}
		printf("\n");
		i--;
		j++;
	}
	
}
