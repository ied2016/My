#include<stdio.h>
#include<string.h>
char main()
{
	char a[100],*p1,*p2;
	int l,i,j;
	scanf("%s",&a);		l=strlen(a);
	p1=&a[0];
	p1++;
	p2=p1;
	p1=&a;
	for(i=0;i<l;i++)
	{
	if(*p1==*p2)
	return printf("NO");
	p1++;
	p2++;
	}
	printf("YES");
}