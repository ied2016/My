#include<stdio.h>
int main()
{
	int a,b,c,hyp[100],n,i,ind=-1;
	scanf("%d",n);
	for(a=1;a<=n;a++)
	{for(b=2;b<=n;b++)
	{
	for(c=3;c<=n;c++)
	{
	
	if((a*a+b*b)==(c*c))
	{
	hyp[++ind]=c;	
	}
}}}
for (i=0;i<=ind;i++)
{printf("%d",hyp[i]);
}
return 0;
}
