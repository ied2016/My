#include<stdio.h>
#include<string.h>
int main()
{
	int i,j,k=0,sum=0;
	char a1[80],a2[80],a3[80];
	gets(a1);
	gets(a2);
	for(i=0;i<strlen(a1);i++)
	{a3[k++]=a1[i];
	}
		for(i=0;i<strlen(a2);i++)
	{printf("%c",a2[i]);
	}
	printf("\n%d\n ",k);
	for(j=0;j<strlen(a2);j++)
	{a3[k++]=a2[j];
	}
	for(i=0;i<k;i++)
	{printf("%c",a3[i]);
	}
}
