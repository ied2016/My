#include<stdio.h>
int main()
{
    int lrg,e,sml,n;
printf("How many elements do you want to enter=");
scanf("%d",n);
scanf("\nEnter the element=%d",&e);
lrg=e;
for (i=1;i<=n;i++)
{
    scanf("\nEnter the element=%d",&e);
if (e>lrg){
    lrg=e;
}
double n1,e1,sml;
rintf("How many elements do you want to enter=");
scanf("%d",n1);
scanf("\nEnter the element=%d",&e1);
sml=e;
for (i=1;i<=n1;i++)
{
    scanf("\nEnter the element=%d",&e1);
if (e1<sml){
    sml=e1;
}
if (e1<sml)
{
    sml=e1;
}
}
printf("\nThe largest integer=%d",sml);
}
