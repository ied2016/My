 #include<stdio.h>
int water=0;
void fillwater(int ptr1,int ptr2,int sp)
{
	while(ptr1!=0 && ptr2!=0)
	{
		water+=sp;
		ptr1-=1;
		ptr2-=1;
	}
}
int main()
{
	int q=-1,*mid,n,*p1,i,*p2,prevspace=0,space=0;
	scanf("%d",&n);
	int a[n];
	p1=&a[0];
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	while(*p1==0)
	{
		p1++;
	}
	p2=p1+1;
	mid=&q;
	while(*p1!=a[n])
	{
		
		if(*p2==0)
		{
			while(*p2==0)
			{
				p2++;
				//space++;
			}
		printf("\np2=%d spaces=%d p1=%d",*p2,p2-p1-1,*p1);
		if(*mid==-1)
		{
			fillwater(*p1,*p2,p2-p1-1);
			mid=p2;
			p2++;
				printf("\n Water=%d mid=%d",water,*mid);

		}
		else
		{
			if(*mid<*p1)
			{	printf("p2=%d",*p2);
				fillwater(*mid,*p2,p2-mid-1);
					printf("\n *Water=%d",water);
				fillwater(*p1-*mid,*p2-*mid,p2-p1-1);
				mid=p2;
				p2++;
					printf("\n Water=%d  mid=%d",water,*mid);

			}
		
		else{
			p1=mid;
			fillwater(*p1,*p2,p2-p1-1);
			p2++;
		}

		}
		if(p2-&a[0]==n-1)
			p1=&a[n-1];
	}
}
	printf("\n last Water=%d",water);
}