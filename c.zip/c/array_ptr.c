#include<stdio.h>
int main()
{
	int a[10];
	char *ptr;
	scanf("%d",a);
}