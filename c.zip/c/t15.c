#include<stdio.h>
int main()
{
	char s[3];
	int s_int;
	scanf("%d",&s_int);
	scanf("%s",s);
	printf("%s %d\n",s,s);
}