#include<stdio.h>
int main()
{
int h;
char ap,m,s;
scanf("%d:%c:%c%s",&h,&m,&s,&ap);
if(ap=="PM"&&h!=12)
{h+=12;
}

printf("%d:%d:%d",h,m,s);

}
