#include<stdio.h>
int main()
{int i=0,j=0,*p,pos,n,a[200],tmp,small=0;
char s1[90],s2[45],*s="abcd";

puts(s);
}   
