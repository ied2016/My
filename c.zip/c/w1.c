#include <stdio.h>
#include <stdlib.h>  /* For exit() function */
int main()
{
   char c[1000],ch;
   int i=0,cnt=0,a[100];
   FILE *f1ptr,*f2ptr;
   f1ptr=fopen("q1.txt","w");
   f2ptr=fopen("q1.txt","r");
   
   if(f1ptr==NULL){
      printf("Error!");
      exit(1);
   }
   printf("Enter a sentence:\n");
   gets(c);
   fprintf(f1ptr,"%s",c);
      fclose(f1ptr);
      f2ptr=EOF;
      f2ptr--;
      ch=getc(f2ptr);
      printf("\nch===%c\n",ch);

   fclose(f2ptr);
   return 0;
}