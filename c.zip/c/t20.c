#include<stdio.h>
struct st{
    short          level;
    unsigned       flags;
    char           fd;
    unsigned char  hold;
    short          bsize;
    unsigned char  *buffer, *curp;
    unsigned       istemp;
    short          token;
} f;
int main()
{
	printf("size=%ld\n",sizeof(f));
}