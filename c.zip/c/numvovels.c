#include<stdio.h>
#include<string.h>
int main()
{
	int i,j,sum=0;
	char a[80],a2[80],a3[80];
	gets(a);
	for(i=0;a[i]!='\0';i++)
	{
	a[i]=tolower(a[i]);
	switch(a[i])
	{
		case 'a':
		case 'e':
		case 'i':
		case 'o':
		case 'u':sum+=1;
		
	}

	
	}
	printf("sum=%d",sum);
}
