#include<stdio.h>
int main()
{
	int a[5],i;
	int avg,sum=0;
	for (i=0;i<5;i++)
	{scanf("%d",&a[i]);
	}
		for (i=0;i<5;i++)
	{sum+=a[i];
	printf("%d %d ",sum,a[i]);
	}
	avg=sum/5;
	printf("%d %d",avg,sum);
	for(i=0;i<5;i++)
	{
		printf("\n element%d=%d,  %d",i,avg-a[i],a[i]);
	}
	
}
