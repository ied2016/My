#include<stdio.h>
int main()
{
	int a,b,c,hyp[100],n,i,ind=0;
	scanf("%d",n);
	for(a=1;a<=n;a++)
	{for(b=a+1;b<=n;b++)
	{
	for(c=b+1;c<=n;c++)
	{
	
	if(((a*a)+(b*b))==(c*c))
	{printf("%d",c);
//	hyp[ind++]=c;	
	}
}}}
//for (i=0;i<=ind;i++)
//{printf("%d",hyp[i]);
//}
return 0;
}
