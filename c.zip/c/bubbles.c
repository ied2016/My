#include<stdio.h>
int main()
{int i=0,j=0,pos,n,a[200],tmp,small=0;
printf("enter number of elements you want to add=");
scanf("%d",&n);
for(;i<n;i++)
scanf("%d",&a[i]);
for(;i<n;i++)
{for(;j++<n;)
{if(a[j]>a[j+1])
{tmp=a[j];
a[j]=a[j+1];
a[j+1]=tmp;
}
}}
for(i=0;i<n;i++)
printf("\n%d",a[i]);
}

