#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
	int size,i,j,num,t,top=-1;
	scanf("%d",&size);
	int a[size];
	char ch[10];
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{  
		scanf("%s",&ch);
	if(strcmp(ch,"push")==0){
	scanf("%d",&num);
				
						if(top==size-1)
						printf("%d\n",-1);
						else
						{
						printf("%d\n",1);
						a[++top]=num;}}
						
			else if(strcmp(ch,"isempty")==0) {
		if(top==-1)
							printf("%d\n",1);
							else
							printf("%d\n",0);}
							
		  else	if(strcmp(ch,"top")==0){if(top==-1)
							printf("%d\n",-1);
							else
							printf("%d\n",a[top]);}
			else {
			if(top==-1)
							printf("%d\n",-1);
							else
							{
							printf("%d\n",a[top]);
							top--;}}
	}

}


