#include<stdio.h>
int main()
{float f,c;
scanf("enter temperature in fahrenheit= %d",&f);
c=(f-32)*(5.0/9.0);
printf("temperature in degrees celsius=%d %d",c,f);
return 0;
}
