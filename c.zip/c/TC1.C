#include<stdio.h>
int main()
{printf("iiitd"); getchar();
return 0;
}
