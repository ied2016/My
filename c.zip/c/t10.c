#include<stdio.h>
int main()
{
	char str[20]="Samby is Pythonista";

	printf("\n%s\n",str+'j'-'a');
}