#include<stdio.h>
#include<ctype.h>
int main()
{
	char s[34];
	scanf("%s",s);
	printf("%c",s[3]);
}