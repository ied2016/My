#include<stdio.h>
#include<stdlib.h>  
void reverseWords(char *s)
{
  char *word_begin = s;
  char *temp = s; 

  while( *temp )
  {
    temp++;
    if (*temp == '\0')
    {
      reverse(word_begin, temp-1);
    }
    else if(*temp == ' ')
    {
      reverse(word_begin, temp-1);
      word_begin = temp+1;
    }
  } 
  reverse(s, temp-1);
}
 
void reverse(char *begin, char *end)
{
  char temp;
  while (begin < end)
  {
    temp = *begin;
    *begin++ = *end;
    *end-- = temp;
  }
}

int main()
{
   char c[1000],ch,a[1000];
   int i=0,cnt=0,j=0;
   FILE *f1ptr,*f2ptr;
   f1ptr=fopen("q1.txt","w");
   f2ptr=fopen("q1.txt","r");
   if(f1ptr==NULL){
      printf("Error!");
      exit(1);
   }
   printf("Enter a sentence:\n");
   gets(c);
   fprintf(f1ptr,"%s",c);
      fclose(f1ptr);

   printf("\nOutput=\n");
   while((ch=fgetc(f2ptr))!=EOF)
   {
      cnt++;
      a[i++]=ch;
   }

   
     reverseWords(a);
     printf("%s",a);
   fclose(f2ptr);
   return 0;
}