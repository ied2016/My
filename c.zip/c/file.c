#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(){
	int i=1;
	char *pout,*pname,name[100],out[1000],*fpname,fname[100]="shread_",numbers[4]={'1','2','3','4'};
	fpname=fname;
	pout=out;
	FILE *file1,*file2;
	scanf("%s",name);
	pname=name;
	file1=fopen(pname,"r");
	if (file1==NULL){
		printf("Cannot open the file ");
		exit(-1);
	}
	else{
		while ((fgets(pout,1000,file1))!=NULL){
			fname[7]=numbers[i];
			file2=fopen(fname,"w");
			fprintf(file2,pout);
			fclose(file2);
			i++;
		}
		
	}
	fclose(file1);
}