#include<stdio.h>
void insertionSort(int size, int arr[]);
void insertionSort(int size, int arr[]) {
	int i,j,k,shift=0,tmp;
	for(i=1;i<size ;i++)
	{tmp=arr[i];
	j=i-1;
	while(tmp < arr[j])
	{shift++;
		arr[j+1]=arr[j];
		j--;
	}
	arr[j+1]=tmp;
	}
}
int main()
{
	int i,j,k,sum ,a[100],n;
	scanf("%d",&n);
	scanf("%d",&sum);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
//		insertionSort(n,a);

		for(i=0;i<n;i++)
          {j=i+1;k=n-1;
          while(j<k)
          {if(a[i]+a[j]+a[k]>=sum){
     
          k--;}
          else
             {
			     printf("\n%d,%d,%d",a[i],a[j],a[k]);
          j++;}
		  }
          
		  }
}
