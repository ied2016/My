#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main()
{	int rnd=0,inp;
	  	srand(time(NULL));rnd=rand()%49;
    do{
      scanf("%d",&inp);
    	printf("\n==%d",rnd);
	}while(inp!=rnd);
	
	
	
	
	
}
