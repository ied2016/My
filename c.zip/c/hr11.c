#include<stdio.h>
//run time error for input = 8
//8 8 14 10 3 5 14 12
//output = 8 7 6 4 3 2
int  small(int a[],int size)
{int min=100000,i;
	for(i=0;i<size;i++)
	{	if(a[i]>0&&a[i]<min)
		{min=a[i];	
		}	}	return min;}
int main()
{
	int a[100000],i,j,sml,sum=0,cut=0,n;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		if(a[i]>0)
		sum+=1;		
	}	
	while(sum!=1){
		printf("%d\n",sum);
	sum=0;
	sml=small(a,n);
	printf("\nyour new array is = ");
	for(i=0;i<n;i++)
	{
		printf("%d",&a[i]);
			
	}
	for(i=0;i<n;i++)
	{	a[i]-=sml;
		if(a[i]>0)
		sum+=1;	}	
	
		printf("\nyour new array after subtraction is = ");
	for(i=0;i<n;i++)
	{
		printf("%d",&a[i]);
			
	}}
	printf("%d",1);}
