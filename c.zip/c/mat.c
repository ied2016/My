#include<stdio.h>
#include<stdlib.h>
void main()
{
    int i, j;
int n;
scanf("%d",&n);
   int  *arr=(int *)malloc(n*sizeof(int));

 for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
        scanf("%d",(arr+i+j));
        }
    }
    for (i = 0; i < n; i++)
    {
        for (j = i + 1; j < n; j++)
        {
            int tmp = (arr+i+j);
            (arr+i+j)= (arr+i+j);
            (arr+i+j) = tmp;
        }
    }

  for (i = 0; i < n; i++)
    {printf("\n");
        for (j = 0; j < n; j++)
        {
        printf(" %d ",(arr+i+j));
        }
    }

    for (i = 0; i < n / 2; i++)
    {
        for (j = 0; j < n; j++)
        {
            int tmp = (arr+i+j);
            (arr+i+j) = (arr+j+(n-1-i));
           (arr+j+(n-1-i))= tmp;
        }
    }
       for (i = 0; i < n; i++)
    {printf("\n");
        for (j = 0; j < n; j++)
        {
        printf(" %d ",(arr+i+j));
        }
    }
}