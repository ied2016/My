#include<stdio.h>
int main()
{
	int i,l,k,j,m,temp;


	scanf("%d",&l);
	int a[100],*po1,*po2;
		for(j=0;j<l;j++)
		{
			scanf("%d",&a[j]);
				printf(" %d ",a[j]);

		}a[l]=0;
		a[l+1]=0;
			for(m=0;m<=l+1;m++)
	{printf(" %d ",a[m]);
	}
		po1=&a[0];
		po2=&a[1];
		
	printf("\np1=%d ,p2=%d",*po1,*po2);
		for(m=0;m<l;m++)
	{printf(" %d ",a[i]);
	}
		for(k=0;k<l/2;k++){
		
		temp=*po1;
		*po1=*po2;
		*po2=temp;
		po1+=2;
		po2+=2;
			printf("p1=%d ,p2=%d",*po1,*po2);

		}
		
	
	for(m=0;m<l;m++)
	{printf(" %d ",a[m]);
	}
	}
	

	
