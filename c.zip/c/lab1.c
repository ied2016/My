#include <stdio.h>
struct student{
    long roll;
    char name;
    int marks;
};
void partition(int arr[],int low,int high){

    int mid;

    if(low<high){
         mid=(low+high)/2;
         partition(arr,low,mid);
         partition(arr,mid+1,high);
         mergeSort(arr,low,mid,high);
    }
}

void mergeSort(int arr[],int low,int mid,int high)
{  
    int i,m,k,l,temp[1000];
    l=low;
    i=low;
    m=mid+1;
    while((l<=mid)&&(m<=high)){

         if(arr[l]<=arr[m]){
             temp[i]=arr[l];
             l++;
         }
         else{
             temp[i]=arr[m];
             m++;
         }
         i++;
    }

    if(l>mid){
         for(k=m;k<=high;k++){
             temp[i]=arr[k];
             i++;
         }
    }
    else{
         for(k=l;k<=mid;k++){
             temp[i]=arr[k];
             i++;
         }
    }
   
    for(k=low;k<=high;k++){
         arr[k]=temp[k];
    }
}
int main()
{
    int i,n,t,j,temp,k;
    scanf("%d",&t);
        struct student s[t];
        int a[5]={5,4,3,2,1};
partiton(a,0,5);
    /*for(i=0;i<t;i++)
    {
    
        scanf("%ld %s %d",&s[i].roll,&s[i].name,&s[i].marks);
        a[i]=s[i].marks;
        }
        for(i=0;i<t;i++)
    {
        for(j=i+1;j<t;j++)
        {
            if(a[i]<a[j])
            {
                temp=a[i];
                a[i]=a[j];
                a[j]=temp;
        }
        }
    }
    

    for(i=t-1;i>=0;i--)
    {
        for(j=0;j<t;j++)
        {
            if(s[j].marks==a[i])
                printf("%ld %s %d\n",s[j].roll,s[j].name,s[j].marks);
        }
    }*/
    for(i=0;i<5;i++)
        printf(" %d ",a[i]);

}