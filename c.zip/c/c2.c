#include<stdio.h>
int main()
{float fl,c;
scanf("%f",&fl);
c=(fl-32)*(5.0/9.0);
printf("temperature in degrees celsius=%f",c);
return 0;
}
