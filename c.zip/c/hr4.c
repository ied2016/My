#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
int f(int []);
int main() {
   
   int size;
scanf("%d", &size);
int ar[size], i;
for(i = 0; i < size; i++) { 
   scanf("%d", &ar[i]); 
}

f( ar);
   
}

int f(int array []) {
	int i,j,k ,temp;
     i = array.length - 1;
    while (i > 0 && array[i - 1] >= array[i]) {
        i--;
    }

    if (i <= 0) {
        return false;
    }

     j = array.length - 1;

    while (array[j] <= array[i - 1]) {
        j--;
    }

     temp = array[i - 1];
    array[i - 1] = array[j];
    array[j] = temp;

    j = array.length - 1;

    while (i < j) {
        temp = array[i];
        array[i] = array[j];
        array[j] = temp;
        i++;
        j--;
    }

    return array;
}
