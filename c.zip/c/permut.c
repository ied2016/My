#include<stdio.h>

int main()
{char a[100],b[100],ch;
	int i,j,l1,l2;
	scanf("%s",&a);
	scanf("%s",&b);

l1=strlen(a);
l2=strlen(b);
	if(strlen(a)!=strlen(b))
	ch="NO";
	else
	for(i=0;i<l1;i++)
	{
	for(j=0;j<l2;j++)
	{
	if(a[i]!=b[j])
	ch= "NO";

	}

	}

	if(ch=="NO")
		ch="NO";
	else 
		ch="YES";
printf("%s",ch);

}