#include<stdio.h>
#include<stdlib.h>
struct node
{
	char data;
	struct node* next;
};
struct node* head1=NULL;
struct node* head2=NULL;

void push(struct node** head, char c)
{
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->data=c;
	temp->next=*head;
	*head=temp;
}

int compare(struct node* l1, struct node* l2) 
{  struct node* t1=(struct node*)malloc(sizeof(struct node));
	struct node* t2=(struct node*)malloc(sizeof(struct node));
	t1=l1;
	t2=l2;
    while (t1 && t2 && t1->data == t2->data) 
    {         
        t1 = t1->next;
        t2 = t2->next;
    }
 
    if (t1 && t2) 
        return (t1->data > t2->data)? 1: -1;
 
    if (t1 && !t2) return 1;
    if (t2 && !t1) return -1;

    return 0;
}

void print(struct node* head)
{
	while(head!=NULL)
	{printf(" %c ",head->data);
		head=head->next;
	}
}
int main()
{
	push(&head1,'a');
	push(&head1,'b');
	push(&head1,'c');

	push(&head2,'a');
	push(&head2,'b');
	push(&head2,'c');
	push(&head2,'d');	
printf("\n");
print(head1);
printf("\n");
print(head2);	
printf("\n");
int a;
a=compare(head1,head2);
printf("\n a=%d\n",a);
}